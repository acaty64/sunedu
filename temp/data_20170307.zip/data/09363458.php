<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>TAPIA NUÑEZ, LOURDES CECILIA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería Industrial - Universidad Nacional Federico Villarreal. Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Egresada de Maestría en Gestión Tecnológica Empresarial (Desarrollo de tesis)- Universidad Nacional de Ingeniería (Lima, Perú)</th></tr>
<tr><th class='der' align='left'>Título de Ingeniera Industrial -  Universidad Nacional Federico Villarreal. Lima, Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Coordinadora de Desarrollo Tecnológico, Abril 2012 a Abril 2013  NESST</th></tr>
<tr><th class = 'der' align='left'>Evaluadora externa de proyectos de innovación, Octubre 2011 a Actualidad- FONDOS CONCURSABLES FIDECOM y FINCYT / Programa de Ciencia y Tecnología</th></tr>
<tr><th class = 'der' align='left'>Docente de la facultad de Ingeniería, Septiembre 2011 a Actualidad- UNIVERSIDAD CATOLICA SEDES SAPIENTIAE</th></tr>
<tr><th class = 'der' align='left'>Evaluadora externa del primer y segundo año del Proyecto CELA Redes de Centros de Transferencia Tecnológica en Cambio Climático en Europa y América Latina, Proyecto Unión Europea. Diciembre 2011 a Enero 2012 y Diciembre 2012 a Enero 2013</th></tr>
<tr><th class = 'der' align='left'>Consultora de organizaciones en temas de transferencia tecnológica, promover, coordinar el fortalecimiento de la investigación, la innovación en el Sistema Nacional de Innovación, Instituto Nacional de Salud y el Ministerio de Medio Ambiente, Enero 2</th></tr>
<tr><th class = 'der' align='left'>Profesional Pasante Especializado, seleccionado del Perú / Parque Tecnológico Heidelberg  Alemania / Advance Biotech Cluster  ABC EU Project, European Commission, Octubre 2010 a Febrero 2011 - PARQUE TECNOLOGICO HEIDELBERG (HEIDELBERG  ALEMANIA)</th></tr>
<tr><th class = 'der' align='left'>Coordinadora de la Oficina de Transferencia Tecnológica, Julio 2008 a Marzo 2010 -  Consejo Nacional De Ciencia Tecnológica E Innovación Tecnológica (CONCYTEC).</th></tr>
<tr><th class = 'der' align='left'>Consultora Asociación de Exportadores Del Perú, febrero 2010 a diciembre 2011 -Banco Interamericano De Desarrollo  Proyecto: Requisitos Técnicos No Arancelarios Para El Acceso Al Mercado De Usa En El Sector Textil Confecciones  - ADEXPERU.</th></tr>
<tr><th class = 'der' align='left'>Consultora, julio 2007 a septiembre 2008-Banco mundial proyecto: desarrollo de proveedores-Ministerio de la Producción.</th></tr>
<tr><th class = 'der' align='left'>Consultora de negocios para PYMES sector confecciones, Marzo 2005 a Julio 2008- ADEXPERU.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
