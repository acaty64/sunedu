<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>VELIZ PAREDES, GUILLERMO RENZO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciado Tecnólogo Médico en Terapia Física y Rehabilitación por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Educación Superior con mención de Docencia e Investigación por la Universidad Peruana Cayetano Heredia, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente contratado a tiempo completo de la Escuela Profesional de Tecnología Médica de la Facultad de Ciencias de la Salud  Asociación Universidad Privada San Juan Bautista.</th></tr>
<tr><th class = 'der' align='left'>Docente encargado de los cursos de Introducción a la Fisioterapia para los alumnos de 1er ciclo, y Anatomía Funcional para los alumnos de 3er ciclo, Fisiología Articular y Biomecánica para los alumnos de 4to ciclo, Evaluación y Diagnóstico Fisioterap</th></tr>
<tr><th class = 'der' align='left'>Coordinador de Extensión Universitaria de la Escuela de Tecnología Médica.</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ciencias de la Salud  Universidad Católica Sede Sapientiae, encargado del curso de Biomecánica I para los alumnos del 3er ciclo de la carrera de Terapia Física y Rehabilitación.</th></tr>
<tr><th class = 'der' align='left'>Docente Auxiliar a tiempo completo de la Facultad de Ciencias de la Salud  Universidad Católica Sede Sapientiae, como coordinador del Internado en Terapia Física y Rehabilitación de la Facultad</th></tr>
<tr><th class = 'der' align='left'>Docente encargado de los cursos de Biomecánica I para los alumnos de 3er ciclo, Biomecánica II para los alumnos de 4to ciclo, y Fisioterapia Traumatológica y Ortopédica en Adultos para los alumnos de 6to ciclo de la carrera de Terapia Física y Rehabi</th></tr>
<tr><th class = 'der' align='left'>Docente contratado de la Escuela Profesional de Tecnología Médica de la Facultad de Ciencias de la Salud  Asociación Universidad Privada San Juan Bautista, encargado de los cursos de Introducción a la Fisioterapia para los alumnos de 1er ciclo, y An</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
