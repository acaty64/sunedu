<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>LUNA SANTOS, JUAN CARLOS</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Matemática Aplicada. Universidad Faustino Sánchez Carrión. Huacho Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Educación. Universidad Privada San Pedro de Chimbote. Perú</th></tr>
<tr><th class='der' align='left'>Licenciado en Matemática Aplicada. Universidad Faustino Sánchez Carrión. Huacho Perú.</th></tr>
<tr><th class='der' align='left'>Licenciado en Educación Secundaria en la especialidad de Matemática, Física y Computación.  Universidad Privada San Pedro de Chimbote. Perú.</th></tr>
<tr><th class='der' align='left'>Magister en Ciencias de la Gestión Educativa con mención en Pedagogía</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Catedrático a tiempo parcial. Escuela de Postgrado Universidad César Vallejo</th></tr>
<tr><th class = 'der' align='left'>Instructor contratado en Nivelación Académica. Servicio Nacional de adiestramiento en trabajo industrial  SENATI - Huacho</th></tr>
<tr><th class = 'der' align='left'>Catedrático a tiempo completo.  Escuela de Oficiales de la Fuerza Aérea del Perú.</th></tr>
<tr><th class = 'der' align='left'>Catedrático a tiempo completo. Escuela de Ingeniería Agrónoma  de la Universidad Sedes Sapiens Huacho.</th></tr>
<tr><th class = 'der' align='left'>Catedrático a tiempo parcial.  Escuela de Medicina Humana  Obstetricia  de la Universidad alas Peruanas.</th></tr>
<tr><th class = 'der' align='left'>Catedrático a tiempo parcial. Escuela de Ciencias Contables y Financieras de la Universidad Privada San Pedro Barranca.</th></tr>
<tr><th class = 'der' align='left'>Catedrático a tiempo parcial. Escuela de Ingeniería de la Universidad José Faustino Sánchez Carrión  Huacho.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
