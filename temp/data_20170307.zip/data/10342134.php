<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>QUEZADA MURGA, DANIEL</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Contabilidad por la Universidad San Martín de Porres</th></tr>
<tr><th class='der' align='left'>Contador Público por la Universidad San Martín de Porres</th></tr>
<tr><th class='der' align='left'>Magister en Administración de Negocios y Finanzas Internacionales MBA Internacional por la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente  en la Universidad Católica  Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Docente en la Universidad Privada del Norte SAC</th></tr>
<tr><th class = 'der' align='left'>Docente en el Instituto Superior tecnológico Privado el Buen Pastor</th></tr>
<tr><th class = 'der' align='left'>Corporación Benavides E.I.R.L. Empresa  dedicada a la fabricación de prendas de vestir (uniformes para empresas) como Contador General.  Responsable de la elaboración de los  estados financieros, liquidación de los impuestos, informes de costos de pr</th></tr>
<tr><th class = 'der' align='left'>Sociedad  Pomalca  Vda. de Piedra S.A Empresa industrial dedicada a la fabricación y comercialización de Alcohol industrial y Rones comerciales como Contador de Costos. Responsable de la valuación de las existencias, registro  y  preparación de los i</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
