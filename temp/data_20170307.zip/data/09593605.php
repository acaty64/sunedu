<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>NAUPARI CASTILLO, HEROINA DINA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Estudios de Doctorado en Educación por la Universidad Marcelino Champagnat.</th></tr>
<tr><th class='der' align='left'>Magister en Educación con mención Docencia y Gestión Educativa por la Universidad César Vallejo, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciada en Educación Lengua y Literatura por la Universidad de San Martin de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad de San Martin de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomatura en Formación de Auditor Interno e Implementador de Sistemas de Gestión de Calidad SGC -ISO 9001:2015 por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomatura de Segunda Especialidad en Tecnologías de la Información y Comunicación en la Educación Básica por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado en Gestión Empresarial Aplicado a la Educación. Instituto Peruano de acción empresarial. IPAE_EDYGE.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Especialista en la Unidad Central de Calidad Académica de la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Técnico Especialista  en Evaluaciones  Externas  con fines de Acreditación en base a los estándares de SINEACE. En Institutos de Educación Superior y Escuelas.</th></tr>
<tr><th class = 'der' align='left'>Docente Universitaria en Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Responsable de la coordinación  distancia convencional  del Ministerio de Educación Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Especialista de Comunicación  en Convenio con el Ministerio de Educación Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Asesorías a las Instituciones Educativas pertenecientes a las Instituciones Educativas de la UGEL _Chincha_ Revisión y Construcción de los Proyectos Curriculares de las I.E en convenio con el Fondo ítalo peruano y la Universidad Católica Sedes Sapien</th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Básica Regular en las II.EE. PNP Juan Ingunza Valdivia y Colegio Militar Leoncio Prado  Callao.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
