<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ANAYA RAYMUNDO, MARIO ANTONIO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciado en Educación Química por la Universidad Nacional de Educación Enrique Guzmán y Valle, Perú.</th></tr>
<tr><th class='der' align='left'>Ingeniero Industrial por la Universidad Nacional del Callao, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Gestión y Didáctica de Programas de Educación a Distancia por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Evaluación y Acreditación de Calidad Educativa por la Universidad César Vallejo, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente formador  capacitador en la Universidad Católica Sedes Sapientiae y el Ministerio de Educación.</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario de la Facultad de Ingeniería Ambiental de la  Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario en Universidad Privada del Norte.</th></tr>
<tr><th class = 'der' align='left'>Especialista en evaluación externa por el SINEACE y PROCALIDAD.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
