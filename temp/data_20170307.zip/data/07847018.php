<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>DUCOS CASAS, TEODORICO JESUS ADOLFO STEIN</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería Industrial por la Universidad Nacional del Callao, Perú.</th></tr>
<tr><th class='der' align='left'>Título Profesional de Ingeniero Industrial por la Universidad Nacional del Callao.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Actualizador de textos, IMMOVA EDICIONES EIRL.</th></tr>
<tr><th class = 'der' align='left'>Jefe de planta responsable de la producción, control de calidad, almacenamiento y distribución de lubricantes, NEGOCIOS MANCOCHE S.A.</th></tr>
<tr><th class = 'der' align='left'>Director gerente administrativo. MERCANTIL 2000 S.A.</th></tr>
<tr><th class = 'der' align='left'>Adjunto a gerencia técnica, ventas y supervisión de los sistemas automáticos de abre puerta de garaje y cercos eléctricos, INDUSTRIAS LASER SRL.</th></tr>
<tr><th class = 'der' align='left'>Asociado del grupo impulsor del plan de desarrollo concertado de lomas de Carabayllo. AGIDEL.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
