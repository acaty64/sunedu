<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>FERNANDEZ SUASNABAR, SELENA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciada en Psicología por la Universidad  Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Educación con Mención en Docencia e Investigación Superior  por la Universidad Peruana Cayetano Heredia, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Psicóloga encargada del área de selección olimpiadas  en la Asociación Educativa Saco Oliveros.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
