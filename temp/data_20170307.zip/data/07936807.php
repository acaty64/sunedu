<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>SIDIA CARRASCO, MIGUEL JOSE</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería de Civil. Universidad Nacional Federico Villarreal. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Título Profesional de Ingeniero Civil. Universidad Nacional Federico Villarreal. Lima. Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Especialista en tránsito y transporte, Protransporte de Lima</th></tr>
<tr><th class = 'der' align='left'>Gerente Técnico, Pait Consultores SAC</th></tr>
<tr><th class = 'der' align='left'>Especialista en tránsito, Protransporte de Lima</th></tr>
<tr><th class = 'der' align='left'>Asesor en tránsito y vialidad, Municipalidad de San Isidro</th></tr>
<tr><th class = 'der' align='left'>Asesor del área de planeamiento de transporte, Municipalidad de Lima</th></tr>
<tr><th class = 'der' align='left'>Asesor del área de ingeniería de transporte.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
