<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CRUZADO MELENDEZ, MELINA ROXANA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Tecnólogo Médico Fisioterapeuta.</th></tr>
<tr><th class='der' align='left'>Título: Licenciatura en Tecnología Médica en el área de Terapia Física y Rehabilitación. Universidad Nacional Mayor de San Marcos. Lima. Perú.</th></tr>
<tr><th class='der' align='left'>Grado de  Bachiller en Tecnología Médica en el área de Terapia Física y Rehabilitación. Universidad Nacional Mayor de San Marcos. Lima. Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado en Didáctica Universitaria.  Universidad Inca Garcilaso de la Vega. Lima- Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en curso: Políticas y Planificación en Salud.  Universidad Nacional Mayor de San Marcos. Lima. Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Fisioterapeuta en la Asociación de Osteogénesis Imperfecta del Perú. AOI Perú (2004- a la actualidad)</th></tr>
<tr><th class = 'der' align='left'>Fisioterapeuta en el Centro de Rehabilitación Chosica MINSA. Chosica  Lima. (2004-2009).</th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Superior en la Universidad Católica Sedes Sapientiae (UCSS) en los cursos   de: Evaluación y Diagnóstico Fisioterapéutico (Pre-grado, 2011-2013);  Introducción a la Fisioterapia (Pre-grado,  2010  hasta la actualidad)</th></tr>
<tr><th class = 'der' align='left'>Coordinadora Académica de la carrera profesional de Terapia Física y Rehabilitación Facultad de Ciencias de la Salud  UCSS (2012- hasta la actualidad).</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
