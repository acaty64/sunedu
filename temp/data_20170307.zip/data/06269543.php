<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>GONZALEZ SAENZ, MODESTA MARIA ADELA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Título de Abogada por la Universidad Particular San Martín de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Grado de  Bachiller en Derecho por la Universidad Particular San Martín de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado de Especialización en Justicia, Derecho y Políticas Públicas, para la Infancia y la Adolescencia por la Universidad Diego Portales, Santiago-Chile.</th></tr>
<tr><th class='der' align='left'>Diplomado de Especialización en Mediación Familiar por la Universidad Diego Portales, Santiago-Chile</th></tr>
<tr><th class='der' align='left'>Estudios concluidos de Maestría Ciencias Políticas y Gobierno por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Abogada en el Programa de Acceso a la Justicia, del Ministerio de Justicia de Chile, que incorpora la difusión de derechos, elaboración de proyectos destinados a la comunidad, prevención de conflictos, utilizando para ello formas alternativas de solu</th></tr>
<tr><th class = 'der' align='left'>Elaboración de Proyectos Sociales en el Departamento de Investigación -Oficina de Proyectos Universidad Católica Sedes Sapientiae. Lima-Perú.</th></tr>
<tr><th class = 'der' align='left'>Consultora y Administradora de Proyectos de Desarrollo, financiados por la Cooperación Internacional, en el Centro de Investigación y Desarrollo Innovador para la Regionalización CIDIR- de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Co-editora de la Serie de Investigaciones: Políticas Innovadoras para la Administración Pública, publicadas en el marco del Proyecto de Creación de una Escuela de Gestión Pública.</th></tr>
<tr><th class = 'der' align='left'>Coordinadora Académica de Programas Formativos (Diplomatura, Diplomados, Programas de Especialización que desarrolla el CIDIR</th></tr>
<tr><th class = 'der' align='left'>Docente contratada de la Universidad Católica Sedes Sapientiae, del curso Introducción al Derecho, en la Facultas de Ciencias Económicas y Comerciales. Lima Perú.</th></tr>
<tr><th class = 'der' align='left'>Docente nombrada de la Universidad Católica Sedes Sapientiae de los cursos de Introducción al Derecho y Fundamentos Cristianos de la Economía y la Empresa.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
