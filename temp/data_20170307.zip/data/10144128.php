<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>PERALTA VERA, JUAN CARLOS</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Educación - Universidad Marcelino Champagnat - Lima Perú.</th></tr>
<tr><th class='der' align='left'>Licenciatura en Educación - Universidad Marcelino Champagnat - Lima Perú.</th></tr>
<tr><th class='der' align='left'>Maestría Aprendizaje y Desarrollo Humano - Universidad San Ignacio De Loyola	 - Lima Perú.</th></tr>
<tr><th class='der' align='left'>Maestría Gestión Educacional Universidad Nacional Enrique Guzmán Y Valle  La Cantuta - Lima Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado en Formulación Y Evaluación De Proyectos Dentro Del Marco SNIP Universidad ESAN - Lima Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado Métodos y Técnicas De Investigación - Universidad Nacional Enrique Guzmán Y Valle  La Cantuta - Lima Perú.</th></tr>
<tr><th class='der' align='left'>Estudios Concluidos de Diplomado Dirección y Gestión De Instituciones Educativas - Universidad Católica Sedes Sapientiae - Lima Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Ofimática - Consorcio Educativo ABACO  EIGER - Callao Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Modificabilidad Cognitiva Estructural - The International Center For The Enhancement Of Learning Potencial - Lima Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Formación Religiosa - Instituto De Los Hermanos De Las Escuelas Cristianas - Roma Italia.</th></tr>
<tr><th class='der' align='left'>Estudios de Ingles - Universidad San Ignacio De Loyola.</th></tr>
<tr><th class='der' align='left'>Estudios de Ingles - Universidad Nacional Enrique Guzmán Y Valle  La Cantuta.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Ministerio De Educación C.E. San Juan Bautista  de la Salle  Docente.</th></tr>
<tr><th class = 'der' align='left'>Ministerio De Educación C.E. Parroquial Fe Y Alegría N° 43 Ventanilla  Docente.</th></tr>
<tr><th class = 'der' align='left'>Ministerio De Educación C.E. Parroquial Fe Y Alegría N° 43 Ventanilla  Director.</th></tr>
<tr><th class = 'der' align='left'>Ministerio De Educación - Consultoria En Educación  En La Dirección General Educación Intercultural Bilingüe. Consultor Especialista en Pedagogía Para Evaluar a los Equipos Formuladores En La Formulación Y Evaluación de Proyectos Dentro Del Marco SN</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Del Perú - Monitor - Capacitador Del Programa Nacional De Formación Y Capacitación (PRONAFCAP).</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae - Investigación Servicios Prestados  a la UCSS.</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae  Docente - Servicios Prestados a la UCSS.</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae - Docente Contratado.</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae  Docente: Seminario De Tesis I, Seminario De Tesis II en Pregrado Y Postgrado.</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae  Jefe del Departamento De Investigación De La Facultad De Ciencias De La Educación Y Humanidades.</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae  Director de la Escuela de Postgrado de La UCSS.</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae  Miembro de la Asamblea y  del Consejo Universitario.	 	</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
