<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MOISES GONZALES, NORMA ROCIO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería Civil. Universidad Nacional de San Martin. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Título Profesional de Ingeniero Civil. Universidad Científica del Perú. Lima. Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Construcción de la Planta procesadora en la estación Pesquera Ahuashiyacu. Cargo: Asistente de Residente.</th></tr>
<tr><th class = 'der' align='left'>Practicas Pre-Profesionales en la Dirección de Transportes y Comunicaciones. Cargo: Cadista.</th></tr>
<tr><th class = 'der' align='left'>Mejoramiento de estanques de la Universidad César Vallejo-Tarapoto. Cargo: Dirección Técnica y Topográfica.</th></tr>
<tr><th class = 'der' align='left'>Municipalidad Distrital de Adwajun. Cargo: Asistente de la Oficina de Desarrollo Urbano y Rural-Obras.</th></tr>
<tr><th class = 'der' align='left'>Asistente de Residente de Obra del Consorcio Selva Norte. Cargo:</th></tr>
<tr><th class = 'der' align='left'>Elaboración de Perfil Técnico Construcción de la Defensa Ribereña de la margen derecha del Rio Mayo, Centro Poblado de San Francisco, distrito de Awajun-San Martin-Perú. Cargo: Asistente de Jefe de Proyecto.</th></tr>
<tr><th class = 'der' align='left'>Elaboración de expediente Técnico Ampliación y Mejoramiento del Sistema de Agua del Centro Poblado, distrito de Awajun-San Martin-Perú. Cargo: Asistente de Jefe de Proyecto.</th></tr>
<tr><th class = 'der' align='left'>Elaboración de Perfil técnico del Centro de salud Nivel I-1 de la comunidad nativa Rio Soritor y del Alto Mayo. Distrito de Awajun-San Martin-Perú. Cargo: Asistente de Jefe de Proyecto</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
