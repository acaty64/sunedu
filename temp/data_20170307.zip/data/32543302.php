<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>PALACIOS FARFAN, PEDRO MIGUEL</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Ciencias con mención en Microbiología y Tecnología de los alimentos por la Universidad Nacional de Trujillo, Perú.</th></tr>
<tr><th class='der' align='left'>Ingeniero Químico por la Universidad Nacional de Trujillo, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería Química por la Universidad Nacional de Trujillo, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Proyectos de Inversión Público y Privado por la Universidad Nacional de Piura, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Gestión en la docencia superior y universitaria por el Instituto Interamericano de Especialización Profesional en convenio con la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Asistente de Coordinación Académica, Universidad Católica Sedes Sapientiae, Facultad de Ingeniería Agraria, Programa Académico Descentralizado Chulucanas.</th></tr>
<tr><th class = 'der' align='left'>Docente de educación superior en la Universidad Católica Sedes Sapientiae en los cursos de: Química General, Química Aplicada, Química Ambiental, Fisicoquímica, Bioquímica. Facultad de Ingeniería Agraria, Programa Académico Descentralizado Chulucanas</th></tr>
<tr><th class = 'der' align='left'>Analista de Microcréditos a las Pymes; Financiera EDYFICAR. Chulucanas.</th></tr>
<tr><th class = 'der' align='left'>Supervisor de producción de industria de pinturas, productos para textiles y cuero. Corporación Peruana de Productos Químicos (CPPQ SA), Lima.</th></tr>
<tr><th class = 'der' align='left'>Supervisor en el área de embalaje y envasado, NESTLE-PERU ex planta de Chiclayo.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
