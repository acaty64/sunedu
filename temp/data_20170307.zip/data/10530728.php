<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>BRAVO LOPEZ, NATALY</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Economista por la Universidad Nacional Agraria La Molina, Perú.</th></tr>
<tr><th class='der' align='left'>Magister en Administración de Negocios MBA por la Universidad San Ignacio de Loyola, Perú.</th></tr>
<tr><th class='der' align='left'>Magister en Administración de Negocios  MBA</th></tr>
<tr><th class='der' align='left'>Economista  UNALM</th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias Económicas  USIL</th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería Empresarial y de Sistemas  USIL</th></tr>
<tr><th class='der' align='left'>Egresado de Maestría en Ingeniería de Sistemas  UNI</th></tr>
<tr><th class='der' align='left'>Diplomas de segunda especialidad en Marketing  USIL</th></tr>
<tr><th class='der' align='left'>Diplomado en   Identidad Digital y el Derecho de Acceso a los Servicios Públicos Electrónicos Seguros  CAER  RENIEC & Ministerio de Justicia</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Facilitador de la RENIEC.</th></tr>
<tr><th class = 'der' align='left'>Jefe de Proyectos en Sub Gerencia de Ingeniería de Software de la Gerencia de Tecnología de la Información en RENIEC</th></tr>
<tr><th class = 'der' align='left'>Especialista I en  Oficina de Administración Documentaria de la Secretaría General en RENIEC</th></tr>
<tr><th class = 'der' align='left'>Administrador de Proyectos en Sub Gerencia de Ingeniería de Software de la Gerencia de Tecnología de la Información en RENIEC</th></tr>
<tr><th class = 'der' align='left'>Especialista I en  Sub Gerencia de Ingeniería de Software de la Gerencia de Tecnología de la Información en RENIEC</th></tr>
<tr><th class = 'der' align='left'>Analista Funcional Sub Gerencia de Ingeniería de Software de la Gerencia de Tecnología de la Información en RENIEC.</th></tr>
<tr><th class = 'der' align='left'>Jefe de Proyectos en Sub Gerencia de Ingeniería de Software de la Gerencia de Tecnología de la Información en RENIEC.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
