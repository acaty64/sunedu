<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ENRIQUEZ CANTO, YORDANIS</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciado en Pedagogía especialidad Biología por la Universidad de La Habana, Cuba.</th></tr>
<tr><th class='der' align='left'>Doctorado en Investigación en Bioética por la Universidad Católica del Sacro Cuore, Roma.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Responsable del Area Académica de Operaciones en la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Jefe del Departamento de Investigación de la Universidad Católica Sedes Sapientiae, Facultad de Ciencias de la Salud, en el cargo de planificación e implementación de proyectos de estudio, del perfeccionamiento docente académico, gestión y control de</th></tr>
<tr><th class = 'der' align='left'>Profesor Auxiliar de Metodología de la Investigación de la Universidad Católica Sedes Sapientiae, Facultad de Ciencias de la Salud ejerciendo docencia en Bioética en el área del inicio de la vida y Consejo Genético.</th></tr>
<tr><th class = 'der' align='left'>Peer reviewer de la Revista Persona y Bioética de la Universidad de La Sanana, Facultad de Medicina dedicándose a la revisión y evaluación de la calidad científica de manuscritos de Bioética.</th></tr>
<tr><th class = 'der' align='left'>Docente Curso Ethics in Health and Disability por la Universidad Católica del Sacro Cuore  Centro de Ateneo de Bio ética  MURINET.</th></tr>
<tr><th class = 'der' align='left'>Docente Curso monográfico por la Universidad Católica del Sacro Cuore  Centro de Ateneo de Bio ética  MURINET, Daño de procreación y derecho de no saber. Status quaestionis.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
