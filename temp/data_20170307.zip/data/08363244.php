<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>SAAVEDRA CHIU, ROXANA MARGARITA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería Económica por la Universidad Nacional de Ingeniería</th></tr>
<tr><th class='der' align='left'>Licenciado en Educación por la Univ. Nacional de Educación Enrique Guzmán y Valle</th></tr>
<tr><th class='der' align='left'>Magister en Administración de Negocios y Finanzas Internacionales por la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Asistente de Investigación Económica</th></tr>
<tr><th class = 'der' align='left'>Asistente de investigación de Mercado</th></tr>
<tr><th class = 'der' align='left'>Asistente de Proyectos.</th></tr>
<tr><th class = 'der' align='left'>Dedicada a la docencia en entidades públicas y privadas en el área de Formación General en instituciones como: ADEX, IPAE, Marina de Guerra del Perú, entre otros.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
