<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>BOLIS ., GIAN BATTISTA FAUSTO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Filosofía por la Universidad de Estudios de Cagliari, Italia.</th></tr>
<tr><th class='der' align='left'>Filósofo por la Universidad de Estudios de Cagliari, Italia.</th></tr>
<tr><th class='der' align='left'>Maestría en Educación con mención en Administración de la Educación por la Universidad Marcelino Champagnat, Perú.</th></tr>
<tr><th class='der' align='left'>Doctor en Filosofía por la Universidad Nacional de Estudios de Cagliari, Italia.</th></tr>
<tr><th class='der' align='left'>Doctorado de Investigación en Pedagogía por la Universidad Católica del Sacro Cuore de Milano.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Vicerrector Administrativo de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Responsable del proyecto: fortalecimiento del centro cultural santa risa cetpro villaregia, mediante la ampliación y equipamiento de nuevas especializaciones con la finalidad de contribuir a la formación técnica, el desarrollo de valores y reducir la</th></tr>
<tr><th class = 'der' align='left'>Responsable de la adecuada ejecución del proyecto: mejora de la Educación Intercultural Bilingüe en las escuelas de Inicial y Primaria de las comunidades indígenas de la provincia de Atalaya-Ucayali. Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Jefe del servicio: PRONAFCAP-ITEM 44. Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Jefe del servicio: Reconstruir Juntos. Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Responsable de la adecuada ejecución del proyecto de formación docente, mejora de la gestión educativa y dotación de recursos en los centros educativos públicos del cono este de Lima. Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Jefe del proyecto de PRONAFCAP- Item 40. Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Responsable de la organización de cursos de formación de docentes en las escuelas públicas italianas en las diversas especialidades. Associazione culturale Icaro, Italia.</th></tr>
<tr><th class = 'der' align='left'>Profesor Principal. Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Profesor de Antropología y Filosofía. Universidad Católica Sedes Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
