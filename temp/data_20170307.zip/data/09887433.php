<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>EGOAVIL DE LA CRUZ, CARLOS HUGO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias Agronómicas</th></tr>
<tr><th class='der' align='left'>Ingeniero Agrónomo. Universidad Nacional Agraria La Molina (UNALM), Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado en "Formulación y Evaluación de Proyectos de Inversión Pública en el Area de Recursos Naturales y Medio Ambiente". Universidad Nacional de Piura</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente Auxiliar a tiempo completo. Facultad de Ingeniería Agraria. Universidad Católica Sedes Sapientiae. Nueva Cajamarca, Rioja, San Martín, Perú.</th></tr>
<tr><th class = 'der' align='left'>Especialista en fertilización de cultivos del Laboratorio de Análisis Agrícolas de Suelos. Gobierno Regional de San Martín - Proyecto Especial Alto Mayo. San Martín, Perú.</th></tr>
<tr><th class = 'der' align='left'>Sub Gerente de Gestión y Promoción de Inversiones. Consejo Transitorio de Administración Regional de San Martín. San Martín, Perú.</th></tr>
<tr><th class = 'der' align='left'>Asesor de la Oficina de Planificación y Evaluación de Proyectos. Fundación para el Desarrollo Agrario del Alto Mayo  FUNDAAM. Moyobamba, San Martí, Perú.</th></tr>
<tr><th class = 'der' align='left'>Consultor. ONG Centro de Investigaciones y Proyectos Urbanos y Regionales  CIPUR. Lima, Perú</th></tr>
<tr><th class = 'der' align='left'>Gobierno Regional de San Martín (GRSM) - Proyecto Especial Alto Mayo (PEAM), Moyobamba - San Martín. Responsable del desarrollo y ejecución de los análisis de suelos, capacitación a agricultores sobre fertilización y manejo del recurso suelo a los pr</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
