<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>HERNANDEZ VASQUEZ, ERICK BRANDUZ</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Matemáticas. Universidad Nacional Pedro Ruiz Gallo. Lima. Perú.</th></tr>
<tr><th class='der' align='left'>Título Profesional de Licenciado en Matemáticas. Universidad Nacional Pedro Ruiz Gallo. Lima. Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Ayudante de Cátedra en el Curso Variedades Diferenciables del Departamento Académico de Matemática de la Universidad Nacional Pedro Ruiz Gallo.</th></tr>
<tr><th class = 'der' align='left'>Docente del curso de Matemática Computacional del Departamento Académico de Matemática de la Universidad Nacional Pedro Ruiz Gallo.</th></tr>
<tr><th class = 'der' align='left'>Docente del curso Estadística III de la Carrera Profesional de Computación e Informática en el Instituto de Educación Superior Tecnológico Privado Cayetano Heredia.</th></tr>
<tr><th class = 'der' align='left'>Docente de Algebra, Aritmética, Geometría, Trigonometría y Razonamiento Matemático de la Institución Educativa Particular María de los Angeles.</th></tr>
<tr><th class = 'der' align='left'>Docente de Algebra y Geometría de la Institución Educativa Particular María de los Angeles.</th></tr>
<tr><th class = 'der' align='left'>Docente de Algebra, Aritmética, Geometría, Trigonometría y Razonamiento Matemático de la Institución Educativa Particular María de los Angeles.</th></tr>
<tr><th class = 'der' align='left'>Docente de Estadística para Ingeniería Civil del Departamento de Ingeniería de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente de Algebra del Centro Preuniversitario de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente de Matemática Básica para Ingeniería Civil del Departamento de Ingeniería de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente de Algebra del Centro Preuniversitario de Rioja de la Universidad Nacional de San Martin</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
