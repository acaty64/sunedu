<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>GARCIA ROJAS, VIDAL SATURNINO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias de la Educación.</th></tr>
<tr><th class='der' align='left'>Licenciado en Educación, especialidad Matemática e Informática. Universidad Nacional de Educación Enrique Guzmán y Valle  La Cantuta.</th></tr>
<tr><th class='der' align='left'>Diplomado de especialización de Postgrado en Estadística aplicada a la Investigación Científica. En la USMP.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>CENTRO PREUNIVERSITARIO de la Universidad Nacional de Educación Enrique Guzmán y Valle  la Cantuta como Docente de Matemática</th></tr>
<tr><th class = 'der' align='left'>Facultad de Ingeniería Ambiental - Universidad Católica Sedes Sapientiae como Docente de Matemática</th></tr>
<tr><th class = 'der' align='left'>Facultad de Ciencias - Universidad Nacional de Educación Enrique Guzmán y Valle como Docente de Matemática. Práctica pre-profesional</th></tr>
<tr><th class = 'der' align='left'>Ministerio de Educación como Docente nombrado Area: Educación para el trabajo - EPT</th></tr>
<tr><th class = 'der' align='left'>Centro de Servicios Educativos para el Desarrollo - Universidad Católica Sedes Sapientiae como Especialista capacitador Areas: Gestión educativa - Matemática</th></tr>
<tr><th class = 'der' align='left'>Asociación Educativa PAIDOS  UNE como Especialista capacitador de docentes. Areas:	Matemática</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae UCSS. Facultad de Ingeniería Agraria, especialidad de Ingeniería Ambiental como Docente de las Areas: Matemática y Estadística.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
