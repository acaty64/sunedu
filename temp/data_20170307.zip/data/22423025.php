<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>DAVILA LAGUNA, RONALD FERNANDO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería Industrial por la Universidad Nacional Hermilio Valdizan, Perú.</th></tr>
<tr><th class='der' align='left'>Título Profesional de Ingeniero Industrial por la Universidad Nacional Hermilio Valdizan, Perú.</th></tr>
<tr><th class='der' align='left'>Magister en Gestión del Desarrollo Social por la Universidad Nacional Hermilio Valdizan.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Universidad César Vallejo. Programa de formación para adultos SUBE</th></tr>
<tr><th class = 'der' align='left'>Universidad César Vallejo. E.A.P. Ingeniería Industrial.</th></tr>
<tr><th class = 'der' align='left'>Universidad Alas Peruanas. Facultad de Ciencias Empresariales.</th></tr>
<tr><th class = 'der' align='left'>Universidad de Huánuco. Facultad de Ciencias Empresariales e Ingeniería.</th></tr>
<tr><th class = 'der' align='left'>Instituto de Educación Superior Tecnológico Publico Aparicio Pomares. Jefe del Area de Producción y Mantenimiento.</th></tr>
<tr><th class = 'der' align='left'>Colectivo Integral de Desarrollo  CID y Fondo empleo.</th></tr>
<tr><th class = 'der' align='left'>Programa Nacional para la Promoción de Oportunidades Laborales Vamos Perú del Ministro de Trabajo. Coordinador general de la ICE.</th></tr>
<tr><th class = 'der' align='left'>Programa de Empleo Juvenil Jóvenes a la Obra. Ministerio de Trabajo. Coordinador general ECAP. Aparicio Pomares.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
