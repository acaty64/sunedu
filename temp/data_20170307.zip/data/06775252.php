<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>HIDALGO GOMEZ, ALFONSO GREGORIO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias con Mención en Ingeniería Industrial por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Educación con especialidad en Matemática y Física por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Ingeniero Industrial por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciado en Educación con especialidad en Matemática y Física por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Ingeniería Industrial por la Universidad Ricardo Palma, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Educación con mención en Edumática y Docencia Universitaria por la Universidad Tecnológica del Perú, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docencia en la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Planeamiento y Comercialización en Nutrial S.A.C.</th></tr>
<tr><th class = 'der' align='left'>Docencia, Promoción y Coordinación de Programas a Distancia en la Universidad Nacional Mayor de San Marcos.</th></tr>
<tr><th class = 'der' align='left'>Seguridad Industrial y Almacenes por R.C.G.; S.C.R.L.</th></tr>
<tr><th class = 'der' align='left'>Supervisión Industrial por  SERCAL  S.A.</th></tr>
<tr><th class = 'der' align='left'>Docencia en la Institución Educativa IES COMPUTER.</th></tr>
<tr><th class = 'der' align='left'>Docencia en C.E.O. San Ignacio de Loyola.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
