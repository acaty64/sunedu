<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>LOPEZ BRAVO, RODOLFO ODLANIER</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Ingeniero Comercial con mención en Administración de Empresas de la Universidad  Gabriela Mistral - República de Chile.</th></tr>
<tr><th class='der' align='left'>Licenciado en Ciencias de la Administración</th></tr>
<tr><th class='der' align='left'>Magíster en Gestión Estratégica, Finanzas e Internacionalización de Empresas de la Universidad Católica Sedes Sapientiae en convenio con la Universidad de Génova  Italia.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente auxiliar de la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Director ejecutivo Compañía de las Obras  Chile</th></tr>
<tr><th class = 'der' align='left'>Director administrativo Instituto de Formación Técnica -  Infoeduc en Chile</th></tr>
<tr><th class = 'der' align='left'>Asesor financiero de proyectos en Fundación Domus en Santiago de Chile.</th></tr>
<tr><th class = 'der' align='left'>Ejecutivo financiero empresa leasing inmobiliario en Santiago de Chile</th></tr>
<tr><th class = 'der' align='left'>Coordinador de la Facultad de Ciencias Económicas y Comerciales sede</th></tr>
<tr><th class = 'der' align='left'>Nueva Cajamarca, provincia de Rioja en la Región San Martín.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
