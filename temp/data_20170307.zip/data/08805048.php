<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>PEREZ FERNANDEZ, JOSE HIGINIO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Grado de  Bachiller en Ingeniería Industrial. Universidad de Lima. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Título Profesional de Ingeniero Industrial. Universidad de Lima. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Estudios concluidos de Maestría en Teoría y Gestión Educativa. Universidad de Piura. Lima. Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Desarrollador de aplicaciones. BANPECO (hoy Banco de Comercio)</th></tr>
<tr><th class = 'der' align='left'>Analista de Sistemas  Jefe de Proyectos. La Fabril S.A. (hoy Alicorp)</th></tr>
<tr><th class = 'der' align='left'>Gerente de Logística. Industrias Nettalco.</th></tr>
<tr><th class = 'der' align='left'>Asesor de Procesos de Tecnología. Dirección General de Aeronáutica Civil  MTC.</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ingeniería de Sistemas. Universidad Científica del Sur.</th></tr>
<tr><th class = 'der' align='left'>Gerente de Proyecto. Minera Yanacocha.</th></tr>
<tr><th class = 'der' align='left'>Director Administrativo/Docente de la Facultad de Ingeniería de Sistemas. Universidad Científica del Sur.</th></tr>
<tr><th class = 'der' align='left'>Decano de la Facultad de Ingeniería/Docente Categoría Principal. Universidad Católica Sedes Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
