<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>GARCES DIAZ, VICTOR</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Título Profesional de Ingeniero Civil por la Universidad Católica Chimbote.</th></tr>
<tr><th class='der' align='left'>Estudios concluidos de Maestría en Investigación y Docencia Universitaria por la Universidad Inca Garcilaso de la Vega, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios concluidos del Doctorado en Ciencias de la Educación por la Universidad Enrique Guzmán y Valle,  Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Jefe de Mantenimiento SIDERPERU.</th></tr>
<tr><th class = 'der' align='left'>Gerente de obras Municipalidad distrital de Independencia Huaraz.</th></tr>
<tr><th class = 'der' align='left'>Gerente General de GY L CONTRATISTAS.</th></tr>
<tr><th class = 'der' align='left'>Ing. Residente Municipalidad de Nuevo. Chimbote</th></tr>
<tr><th class = 'der' align='left'>Ing. Supervisor Hospital II Independencia Huaraz.</th></tr>
<tr><th class = 'der' align='left'>Ing. Supervisor Centro Comercial los Cedros de Villa Lima</th></tr>
<tr><th class = 'der' align='left'>Miembro del Directorio de la Planta Sproisa Municipalidad de Nuevo Chimbote.</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario  en la Universidad  Privada del Norte. Lima</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario  en la Universidad Católica Sedes Sapientiae . Lima</th></tr>
<tr><th class = 'der' align='left'>Universidad. Católica Sedes Sapientiae (Coordinador del Departamento Construcción de Edificaciones 2017).</th></tr>
<tr><th class = 'der' align='left'>Universidad San Pedro Huaraz Coordinador Académico de la Escuela DE ingeniería Civil.</th></tr>
<tr><th class = 'der' align='left'>Docente del Instituto CIBERTEC UPC-Lima(Cursos Física Electrónica)</th></tr>
<tr><th class = 'der' align='left'>Docente  Universitario  en la Universidad  Nacional Santiago Antúnez de Mayolo Huaraz</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
