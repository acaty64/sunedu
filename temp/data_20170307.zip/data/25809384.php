<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>RUIZ RUIZ, GUADALUPE</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias de la Comunicación. Universidad de San Martin de Porres. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Título Profesional de Licenciada en Ciencias de la Comunicación. Universidad de San Martin de Porres. Lima. Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Investigadora periodística , asistente de producción, programa talk show MARITERE, compañía latinoamericana de radio fusión frecuencia latina, canal 2</th></tr>
<tr><th class = 'der' align='left'>Investigadora periodística , asistente de producción, programa talk show PECADO ORIGINAL, ANDINA PERIODISTICA S.A. CANAL 9</th></tr>
<tr><th class = 'der' align='left'>Coordinadora de eventos, dirección general de difusión y formación artística, INSTITUTO NACIONAL DE CULTURA INC</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
