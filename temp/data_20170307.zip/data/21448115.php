<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>BOZA OLAECHEA, MARGARITA LUISA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Grado de  Bachiller en Ingeniería Civil por la Universidad Nacional San Luis Gonzaga, Perú.</th></tr>
<tr><th class='der' align='left'>Título Profesional en Ingeniería Civil por la Universidad Nacional San Luis Gonzaga, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Ingeniería de Mecánica de Suelos. Rehabilitación y Mejoramiento de la Carretera Izuchaca Huancavelica a Nivel de Asfaltado. Cargo: Construcción Albergue Turístico Municipalidad Domingo de Capillas. Cargo: Ingeniería Asistente</th></tr>
<tr><th class = 'der' align='left'>Ingeniería Asistente Mejoramiento de la Carretera COREPAC  San Miguel.</th></tr>
<tr><th class = 'der' align='left'>Ingeniería de Mecánica de Suelos Construcción de la Represa Ninaccasa y Canal Buena Esperanza de Carguacucho.</th></tr>
<tr><th class = 'der' align='left'>Mejoramiento del Centro Educativo Inicial 346 Las Palmeras de la Urb. Palmeras. Distrito de los Olivos. Cargo: Ingeniería Residente.</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ingeniería. Universidad Católica Sedes Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
