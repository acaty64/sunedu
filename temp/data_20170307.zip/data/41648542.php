<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CASTILLO GUTIERREZ, GIANCARLO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad Católica Sedes Sapientiae, Perú</th></tr>
<tr><th class='der' align='left'>Licenciado en educación en la especialidad de Filosofía y Religión por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Religión por el Centro superior catequético Ave María, Perú.	</th></tr>
<tr><th class='der' align='left'>Egresado de Maestría en Educación con mención en Persona, Familia y Sociedad a la luz de la Doctrina Social de la Iglesia por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de educación básica regular en la I.E.P. Alfredo Salazar Southwell. Miraflores.</th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Superior en la Universidad Católica Sedes Sapientiae en los cursos de Doctrina Social de la Iglesia, Teología I, Antropología Religiosa (Pre-grado).</th></tr>
<tr><th class = 'der' align='left'>Tutor de diplomados y maestrías de la Unidad de Ciencias de la Educación de la Escuela de Postgrado de la Universidad Católica Sedes Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
