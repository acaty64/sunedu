<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>NUÑEZ MANRIQUE, ANA MARIA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Arquitectura. Universidad Ricardo Palma. Lima- Perú.</th></tr>
<tr><th class='der' align='left'>Título profesional de Arquitecta. Universidad Ricardo Palma. Lima- Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Doctrina Social de la Iglesia.  Universidad Católica Sedes Sapientiae. Lima-Perú.</th></tr>
<tr><th class='der' align='left'>Egresado de Maestría en Arquitectura con mención en Gestión Empresarial.  Universidad Nacional Federico Villarreal. Lima-Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Delegado Municipal ante el Municipio de Barranco  Colegio de Arquitectos.</th></tr>
<tr><th class = 'der' align='left'>Delegado Municipal ante el Municipio de Santiago de Surco Colegio de Arquitectos.</th></tr>
<tr><th class = 'der' align='left'>Responsable del Departamento de Proyectos Técnicos y Saneamiento Físico Legal del Obispado de Carabayllo  Diócesis de Carabayllo.</th></tr>
<tr><th class = 'der' align='left'>Consultora en saneamiento físico- legal -  Ministerio de Educación  Programa Nacional de Infraestructura Educativa.</th></tr>
<tr><th class = 'der' align='left'>Delegado Municipal ante los  Municipios de Puente Piedra, ancón, y santa Rosa-Colegio de Arquitectos.</th></tr>
<tr><th class = 'der' align='left'>Jefe de Brigada  GEOMAP Digital S..A.</th></tr>
<tr><th class = 'der' align='left'>Consultora de la Oficina de Infraestructura Educativa (OINFE)  Ministerio de Educación  Banco Interamericano de Desarrollo  (BID)</th></tr>
<tr><th class = 'der' align='left'>Asistente de la Gerencia de Proyectos  D.I.C.S.A.C.</th></tr>
<tr><th class = 'der' align='left'>Asistente de la Gerencia de Proyectos  S.& T. DIENTS.</th></tr>
<tr><th class = 'der' align='left'>Reorganización del archivo de la Gerencia de Obras y Desarrollo Urbano -  Municipalidad Santiago de Surco.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
