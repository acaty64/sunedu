<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>GUEVARA LOPEZ, HERLINDA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciada en Educación en la Especialidad Educación Secundaria  Ciencias Biológicas y Químicas por la Universidad Nacional Federico Villareal, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma Internacional en Metodología de la Investigación Cualitativa por la Universidad Nacional Hermilio Valdizán, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Educación por la Universidad de San Martín de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Doctorado en Educación por la Universidad de San Martín de Porres, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Miembro del Comité Interno de Autoevaluación y Acreditación Universitaria de la Facultad de Ciencias de la Educación Universidad de Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Miembro del Comité Editorial de la Revista Científica Studium Veritatis. Universidad de Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Jurado de titulación de Pregrado en la especialidad de Educación Secundaria-Informática.</th></tr>
<tr><th class = 'der' align='left'>Coordinador de Cursos de la Facultad de Ingeniería  de la Universidad de Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Miembro de la Comisión de Autoevaluación en el proceso de acreditación de las carreras profesionales de la Facultad de Ingeniería. UCSS Universidad de Católica Sedes Sapientiae..</th></tr>
<tr><th class = 'der' align='left'>Docente en la Facultad de Ciencias de la Educación y Humanidades.  Universidad de Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente en la Facultad de Ingeniería Geográfica. Universidad Alas Peruanas.</th></tr>
<tr><th class = 'der' align='left'>Docente en la Facultad de Ciencias Agropecuarias Peruanas.</th></tr>
<tr><th class = 'der' align='left'>Miembro de la Comisión Curricular de la Universidad Alas Peruanas.</th></tr>
<tr><th class = 'der' align='left'>Coordinadora Académica de la Sección de Postgrado en Educación. Facultad de Educación.</th></tr>
<tr><th class = 'der' align='left'>Universidad de San Martín de Porres.</th></tr>
<tr><th class = 'der' align='left'>Miembro de la Comisión de Publicaciones e Imagen Institucional de Facultad de Educación.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
