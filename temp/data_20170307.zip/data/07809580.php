<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ALAYZA ARIAS, MANUEL ENRIQUE</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Derecho por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th class='der' align='left'>Título de Abogado por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Coordinador Administrativo de la Facultad de Derecho y Ciencias Políticas por la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Sub director, Administrador y Asesor Jurídico en el Area Laboral de Misión Jurídica  y Social de Paz..</th></tr>
<tr><th class = 'der' align='left'>Apoyo en Asesoría Jurídica en el Fondo de las Naciones Unidas para la Infancia (UNICEF)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario en Derecho Laboral en la Pontificia Universidad Católica del Perú.</th></tr>
<tr><th class = 'der' align='left'>Apoyo en Asesoría Jurídica en el Arzobispado de Lima.</th></tr>
<tr><th class = 'der' align='left'>Asesor en la Dirección General en la Academia de la Magistratura.</th></tr>
<tr><th class = 'der' align='left'>Asesor en la Secretaria de Coordinación Interinstitucional por la Presidencia del Consejo de Ministros.</th></tr>
<tr><th class = 'der' align='left'>Asesor legal del Proyecto Apoyo a la Reforma del Sistema de Justicia en el Perú en el Ministerio de Justicia (Apoyo de la Unión Europea).</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
