<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CESPEDES PANDURO, JACOBA DEL PILAR</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Derecho por la Universidad Nacional Pedro Ruiz Gallo, Lambayeque, Perú.</th></tr>
<tr><th class='der' align='left'>Abogada por la Universidad Nacional Pedro Ruiz Gallo, Lambayeque, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma de Especialista en Administración de Recursos Humanos, Legislación Laboral y Previsional por el Colegio de Abogados de Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Gestión e Innovación Educativa por la Universidad Católica Sedes Sapientiae, Lima, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Fedatario - SUNAT (Superintendencia Nacional de Administración Tributaria) Intendencia Regional De Lambayeque. (1993-1994)</th></tr>
<tr><th class = 'der' align='left'>Técnico Registral - SUNARP (Superintendencia Nacional De Registros Públicos) Oficina Registral Regional  Región Nor Oriental del Marañón. (1996)</th></tr>
<tr><th class = 'der' align='left'>Coordinadora  Aplicación del examen a Docentes en el marco del concurso público para la contratación de profesores de educación básica: regular, especial, alternativa y educación técnica productiva. (2009)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitaria del curso de Derecho Laboral en la Universidad Católica Sedes Sapientiae (2010  2013)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitaria del curso Derecho Laboral para el Programa de Formación Académica de Atalaya en la Universidad Católica Sedes Sapientiae (2011)</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ciencias Económicas y Comerciales de la Universidad Católica Sedes Sapientiae en la Categoría de Auxiliar a Tiempo Completo (marzo 2013  continua)</th></tr>
<tr><th class = 'der' align='left'>Trabajador Administrativo de la Oficina de Personal y Asuntos Legales de la Universidad Católica Sedes Sapientiae. (2002  2016)</th></tr>
<tr><th class = 'der' align='left'>Jefe de la Oficina de Legal de la Universidad Católica Sedes Sapientiae (enero 2017  continua)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
