<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>GUTIERREZ BUSTAMANTE, SILVIA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias Agrarias por la Universidad San Antonio Abad del Cusco, Perú.</th></tr>
<tr><th class='der' align='left'>Ingeniero Agrónomo por la Universidad San Antonio Abad del Cusco, Perú.</th></tr>
<tr><th class='der' align='left'>Segunda Especialidad en Contaminación y Gestión Ambiental por la Universidad Nacional de San Agustín de Arequipa, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Administración  por Zegelipae, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Manejo Integrado de Plaga por la Universidad Nacional Agraria La Molina, Lima, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Expositora en el II Taller de sensibilización para el futuro Aeropuerto Internacional de Chinchero, Cuzco.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
