<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>COZ CONTRERAS, VANESA CAROLINA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller de Médico Cirujano por la Universidad Particular San Martin de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Médico Cirujano por la Universidad Particular San Martin de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Auditoria Médica Basada en evidencias - Medico Auditor por la Universidad Nacional San Luis Gonzaga, Ica, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Auditoria del Sistema de Gestión de Seguridad y Salud Ocupacional por la Universidad Nacional San Luis Gonzaga, Ica, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Salud Ocupacional y Ambiental  por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Apoyo en el tópico médico de la Institución Educativa Inicial Privada Virgen de Cocharcas.</th></tr>
<tr><th class = 'der' align='left'>Medico en el tópico de medicina en la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Medico en  campañas del laboratorio Sherfarma.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
