<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>LOPEZ BULNES, JORGE LUIS</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Biólogo  universidad Nacional Federico Villarreal</th></tr>
<tr><th class='der' align='left'>Egresado  de Segunda  Especialidad en Didáctica Universitaria. Universidad Peruana Los Andes.</th></tr>
<tr><th class='der' align='left'>Egresado de Maestría en Botánica Tropical Mención Botánica Económica Universidad Nacional Mayor De San Marcos</th></tr>
<tr><th class='der' align='left'>Magister en  Docencia y Gestión Educativa. Universidad Cesar Vallejo</th></tr>
<tr><th class='der' align='left'>Estudios de Doctorado en Medio Ambiente y Desarrollo Sostenible Universidad Nacional Federico  Villarreal.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de Prácticas de Laboratorio de Química en la Escuela Profesional de Obstetricia de la Facultad de Ciencias de la Salud de la Universidad Privada Sergio Bernales en la asignatura de Química General.</th></tr>
<tr><th class = 'der' align='left'>Docente principal  de  la asignatura de Botánica I y  II  en la facultad de Ciencias naturales y Matemática  departamento académico de Biología de la U. N. Federico Villarreal.</th></tr>
<tr><th class = 'der' align='left'>Docente principal de la unidad de ejecución curricular  Ecología y Ecosistemas de la facultad de Ingeniería, Carrera Ingeniería civil  en la universidad Peruana Los Andes.</th></tr>
<tr><th class = 'der' align='left'>Docente principal en la asignatura de Fitogeografía y Botánica Sistemática  en la facultad de Ingeniería geográfica y Ambiental  de la U. N. Federico Villarreal.</th></tr>
<tr><th class = 'der' align='left'>Docente principal  de la asignatura de Biología  en la facultad de Ciencias naturales y Matemática  escuela de Química  de la U. N. Federico Villarreal.</th></tr>
<tr><th class = 'der' align='left'>Consultor en  elaboración de línea base flora fauna para diversos instrumentos de gestión ambiental en sector</th></tr>
<tr><th class = 'der' align='left'>Docente de la asignatura   Bioquímica  en la escuela de medicina de la facultad de medicina humana de la universidad nacional Federico Villarreal.</th></tr>
<tr><th class = 'der' align='left'>Docente U CATOLICA  SEDES SAPIENTAE  Tarma</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
