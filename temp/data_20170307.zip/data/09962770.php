<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>YARLEQUE VILCHEZ, LUIS ENRIQUE</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Ingeniero Industrial Universidad Nacional de Piura</th></tr>
<tr><th class='der' align='left'>Licenciado en Ingeniería Industrial  por la Universidad Nacional de Piura.</th></tr>
<tr><th class='der' align='left'>Licenciado en Matemática física y computación. Universidad San pedro de Chimbote.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Practicas pre profesionales en la planta de procesamiento de productos lácteos de la Universidad Nacional de Piura</th></tr>
<tr><th class = 'der' align='left'>Apoyo en laboratorio de control de calidad en los análisis físicos químicos y organolépticos de leche, yogurt, manjar blanco, natilla, queso, algarrobina, mermelada, néctares.</th></tr>
<tr><th class = 'der' align='left'>Apoyo en la planta de frutas y lácteos</th></tr>
<tr><th class = 'der' align='left'>Apoyo en la elaboración de organigramas de producción</th></tr>
<tr><th class = 'der' align='left'>Docente en educación secundaria en el área de matemática en academias preuniversitarias y militares</th></tr>
<tr><th class = 'der' align='left'>Participó en el centro preuniversitario de la Universidad Católica Sedes Sapientiae de la Diócesis de Chulucanas</th></tr>
<tr><th class = 'der' align='left'>He laborado en la Universidad Católica Sedes Sapientiae programa Chulucanas como docente universitario desde el año 2012 hasta el 2016-II</th></tr>
<tr><th class = 'der' align='left'>He  laborado en la I.E. parroquial Santísima Cruz</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
