<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>BLAS MONTENEGRO, LUZ PETRONILA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Ecología y Gestión Ambiental por la Universidad Ricardo Palma, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Psicología con mención en Problemas de Aprendizaje por la Universidad Ricardo Palma, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma de Estudios en Metodología de la enseñanza en Comprensión Lectora y Producción Escrita por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma de Estudios en Psicopedagogía en Lectura y Escritura por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciada en Educación Primaria por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de pregrado, Coordinadora Académica (2012-continúa) en la carrera profesional de Ingeniería Ambiental de la Facultad de Ingeniería Agraria de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente capacitadora de docentes, docente en el Programa de Educación Básica Intercultural (EBI)  NOPOKI, Supervisora Académica en el Programa de Educación Básica Intercultural (EBI)  NOPOKI, Atalaya, Ucayali; Monitora del Programa Nacional de Form</th></tr>
<tr><th class = 'der' align='left'>Integrante del equipo de Coordinación Administrativa Académica, asesora para sustentación de tesinas y miembro del Jurado en las exposiciones de Licenciatura en Escuela de Posgrado de la Universidad Católica Sedes Sapientiae (2007-2008)</th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Básica Regular en San Ignacio del Cono Norte (Comas), San Antonio de Padua (Jesús María) y San Miguel Arcángel Puente Piedra (2002-2006)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
