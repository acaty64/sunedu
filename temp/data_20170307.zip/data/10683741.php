<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>FIGUEROA ANAMARIA, JORGE HUGO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Economista por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Economía por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Especialización en Monitoreo y Evaluación de Proyectos Sociales por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios inconclusos de Maestría en Gerencia Social por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ciencias Económicas y Comerciales en las siguientes asignaturas: Microeconomía Básica, Macroeconomía (2012 a la actualidad). Docente de la Facultad de Ingeniería Agraria en las asignaturas: Economía General y Economía y Sost</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ciencias de la Salud en la asignatura: Formulación y Evaluación de Proyectos (2012 al 2016).</th></tr>
<tr><th class = 'der' align='left'>Coordinador General de la Oficina Beca 18, en convenio con el PRONABEC (2015 a la actualidad).</th></tr>
<tr><th class = 'der' align='left'>Coordinador Responsable del Programa Beca 18, en convenio con el PRONABEC (2013 y 2014).</th></tr>
<tr><th class = 'der' align='left'>Jefe de la Oficina de Proyectos (2013 y 2014)</th></tr>
<tr><th class = 'der' align='left'>Jefe de la Oficina de Planificación y Control de Gestión en la Universidad Católica Sedes Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
