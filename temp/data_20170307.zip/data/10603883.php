<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>DIAZ VARGAS, SELENI ADILIA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciada  en   Educación Especialidad  en  Filosofía y  Religión por la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class='der' align='left'>Estudios concluidos en la Maestría de Educación especialidad Persona Familia y Sociedad a la luz de la Doctrina Social de la Iglesia por la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Profesora de Antropología  Religiosa por la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Jurado del escrutinio para los alumnos del IV ciclo de pregrado de la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Coordinadora  Editorial: supervisión de textos, diseño, etc. de las publicaciones del Fondo Editorial de la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Asistente de la Facultad de Ingeniería de la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Asistente de la Facultad de Ciencias de la Educación Universidad Católica Sedes Sapientiae Responsable de la Proyección y extensión de la Facultad Coordinación de la revista y el suplemento de la Facultad. Coordinación y elaboración del Boletín de la</th></tr>
<tr><th class = 'der' align='left'>Monitoreo de las actividades culturales de la Facultad.</th></tr>
<tr><th class = 'der' align='left'>Profesora de Inglés Instituto SISE</th></tr>
<tr><th class = 'der' align='left'>Profesora de Inglés en la l.E.P. San Benito de Palermo</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
