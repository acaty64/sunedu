<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>TACUNAN BONIFACIO, SANTIAGO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Maestría en Educación con mención en Persona, Familia, Sociedad a la luz de la Doctrina Social de la Iglesia. Organizado por la Universidad Católica Sedes Sapientiae (Egresado con presentación de tesis aprobada). 2012-2014</th></tr>
<tr><th class='der' align='left'>Licenciado en Historia por la Universidad Nacional Mayor de San Marcos, con la tesis Historia del distrito de Comas. Desde sus antecedentes prehispánicos hasta sus primeros años de fundación. Lima (sobresaliente y con mención en publicación).( 2000</th></tr>
<tr><th class='der' align='left'>Bachiller en Historia por la Universidad Nacional Mayor de San Marcos.(1999)</th></tr>
<tr><th class='der' align='left'>Diplomado en Doctrina Social de la Iglesia. Organizado por la Universidad Católica Sedes Sapientiae  entre julio y diciembre (2010)</th></tr>
<tr><th class='der' align='left'>Diplomado en Gestión Municipal de los Programas Sociales. Organizado por la Escuela Mayor de Gestión Municipal y la Universidad Católica Sedes Sapientiae, realizado entre julio y noviembre.( 2006)</th></tr>
<tr><th class='der' align='left'>Diplomado en Seguridad y Defensa Nacional. Organizado por la Universidad Católica Sedes Sapientiae y el Ministerio de Defensa del Perú (Resolución Nº 149-CG-UCSS-2005) durante el semestre académico II del año lectivo (2005)</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Jefe de Educación y Cultura de la Municipalidad Distrital de Los Olivos. (2016-2017)</th></tr>
<tr><th class = 'der' align='left'>Asistente Profesional de la Dirección de Planeamiento Educativo de la Municipalidad de Los Olivos. Labor que desempeñó desde marzo del 2006 hasta febrero del 2007.</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ciencias de Educación y Humanidades de la Universidad Católica Sedes Sapientiae. (2007  2017 )</th></tr>
<tr><th class = 'der' align='left'>Investigador Asociado al Centro de Estudio del Patrimonio Cultural (CEPAC) de Lima Norte de la Universidad Católica Sedes Sapientiae. (2007-2014)</th></tr>
<tr><th class = 'der' align='left'>Coordinador del Centro de Investigaciones de la Facultad de Ciencias de la Educación y Humanidades de la Universidad Católica Sedes Sapientiae. (2013).</th></tr>
<tr><th class = 'der' align='left'>Docente en el Instituto Pedagógico Privado Paulo Freire (Asociación de Desarrollo Educativo Peruano Alemana) D. S. Nº 002492. Labor que desempeñó durante el trimestre de marzo a mayo en los grados de educación inicial y primaria. (2004)</th></tr>
<tr><th class = 'der' align='left'>Investigador del Seminario de Historia Rural Andina de la Universidad Nacional Mayor de San Marcos. ( 1998-2015)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
