<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>LAFOSSE MASIAS, JORGE LUIS</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Maestría en Doctrina Social de la Iglesia por la Pontificia Università Lateranense; Italia.</th></tr>
<tr><th class='der' align='left'>Diplomado Ejecutivo e Tributación Empresarial por Am Bussines, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado en Derecho de la Empresa por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciado en Derecho y Ciencias Políticas por la Universidad Latinoamericana de Ciencia y Tecnología, Panamá.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Abogado Junior Estudio Marsano S.A.</th></tr>
<tr><th class = 'der' align='left'>Abogado Junior Estudio Jiménez & Quintana S.R.L</th></tr>
<tr><th class = 'der' align='left'>Asesor Legal de la Diócesis de Carabayllo</th></tr>
<tr><th class = 'der' align='left'>Docente Auxiliar  UCSS</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
