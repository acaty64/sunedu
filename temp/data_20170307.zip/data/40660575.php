<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>HERRERA CONCHA, RENAN ALBERTO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Grado de  Bachiller en Derecho. Universidad de Lima. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Título Profesional de Abogado. Universidad de Lima. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Grado de Magister. Master en Derecho Empresarial. Universidad de Lima. Lima. Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Jefe del Equipo de Investigación Tribunal Administrativo de Reclamos de la SUNASS</th></tr>
<tr><th class = 'der' align='left'>Jefe del Area Legal y de Recursos Humanos a Nivel Corporativo.</th></tr>
<tr><th class = 'der' align='left'>Oficial de Cumplimiento y Consultor Interno en Derecho Empresarial y Gestión Estratégica del Factor Humano</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ingeniería de la Universidad Católica Sedes Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
