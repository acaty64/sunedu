<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>VILLEGAS FERNANDEZ, YURY JOSELINA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Ingeniero de Industrias Alimentarias por la Universidad Nacional Agraria La Molina, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Educación con mención en Evaluación y Acreditación de la Calidad de la Educación por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomada en Sistemas Integrados de Gestión por la Universidad Peruana de Ciencias Aplicadas, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente en la Facultad de Ingeniería de la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class = 'der' align='left'>Miembro del equipo de acreditación de la Facultad de Ingeniería de la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class = 'der' align='left'>Jefe de Estándares y Autoevaluación en Dirección de Aseguramiento de la Calidad de la Universidad Peruana de Ciencias Aplicadas, Perú.</th></tr>
<tr><th class = 'der' align='left'>Jefe de Calidad Universitaria en la Universidad Científica del Sur, Perú.</th></tr>
<tr><th class = 'der' align='left'>Especialista en formulación del Sistema de Gestión de Calidad y Planes de Mejora en la Oficina Central de Calidad Universitaria de la Universidad Nacional de Ingeniería, Perú.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
