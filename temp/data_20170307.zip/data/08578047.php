<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ARIAS MARCOS, ADA GABRIELA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Educación. Universidad Particular San Martín de Porres</th></tr>
<tr><th class='der' align='left'>Licenciada en Educación especialidad Lengua y Literatura por la Universidad de San Martin de Porres.</th></tr>
<tr><th class='der' align='left'>Magister en Docencia Universitaria. Escuela de postgrado UNE Enrique Guzmán y Valle</th></tr>
<tr><th class='der' align='left'>Doctorado en Ciencias de la Educación. Escuela de postgrado UNE Enrique Guzmán y Valle</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de Comunicación Efectiva en la Escuela Nacional de Administradores Públicos  SERVIR</th></tr>
<tr><th class = 'der' align='left'>Docente contratado de Lengua, Redacción, Metodología del Estudio Universitario  en la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Docente contratada Comunicación Efectiva y Técnicas de Redacción en la Escuela de Postgrado de la Universidad Continental</th></tr>
<tr><th class = 'der' align='left'>Capacitadora Contratada en Redacción Empresarial e Institucional en la Presidencia del Consejo de Ministros</th></tr>
<tr><th class = 'der' align='left'>Docente Contratado de Lengua, Redacción General y Empresarial, Ortografía y Redacción en la Universidad Jaime Bausate y Mesa</th></tr>
<tr><th class = 'der' align='left'>Coordinadora Académica de Maestría en la Escuela de Postgrado de la Universidad Continental. Lima. Perú</th></tr>
<tr><th class = 'der' align='left'>Coordinadora de Curso de Comunicación en la Universidad César Vallejo</th></tr>
<tr><th class = 'der' align='left'>Docente de especialidad en la Escuela Nacional de Administradores Públicos. Lima. Perú.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
