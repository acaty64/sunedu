<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>VELASQUEZ ESPINOZA, MONICA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Biología. Universidad Nacional Federico Villarreal (Lima-Perú).</th></tr>
<tr><th class='der' align='left'>Licenciado en Biología. Universidad Nacional Federico Villarreal (Lima-Perú)</th></tr>
<tr><th class='der' align='left'>Diplomado en Gestión ambiental y Evaluación de Impacto Ambiental. Universidad Nacional Federico Villarreal y el Centro de Estudios Superiores y  actualización Profesional (CESAP).</th></tr>
<tr><th class='der' align='left'>Diplomado de Elaboración y Evaluación de Estudios de Impacto Ambiental. Escuela de Postgrado de la  Universidad Nacional de Trujillo y el  Centro Latinoamericano de Posgrado y entrenamiento profesional CELAEP.</th></tr>
<tr><th class='der' align='left'>Magister Scientiae en Ecología Aplicada. Universidad Nacional Agraria La Molina (Lima-Perú).</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente tiempo Parcial, del Curso de Procesos Biológicos. Universidad Peruana de Ciencias Aplicadas</th></tr>
<tr><th class = 'der' align='left'>Consultor ambiental especialista en Biología. Empresa Consultora Ambiental Pacific Protección Integral de Recursos (PIR) S.A.C.</th></tr>
<tr><th class = 'der' align='left'>Consultor ambiental externo especialista en Botánica. Consultoras ambientales: Environmental and Safety Projects S.A.C (ENVIPRO SAC), Consultora Ecología y tecnología Ambiental  S.AC (ECOTEC),  J. Cesar Ingenieros y Consultores S.A.C (JCI),  Empresa</th></tr>
<tr><th class = 'der' align='left'>Especialista de Medio Ambiente. Empresa Consultora Ecotrans Dayto S.A.C.</th></tr>
<tr><th class = 'der' align='left'>Investigador principal. Herbario Magdalena Pavlich Universidad Peruana Cayetano Heredia</th></tr>
<tr><th class = 'der' align='left'>Investigador principal. Laboratorio de palinología y paleobotánica- Universidad Peruana Cayetano Heredia</th></tr>
<tr><th class = 'der' align='left'>Docente tiempo parcial de la Carrera de Ingeniería Ambiental de la Facultad de Ingeniería Agraria. Universidad Católica Sedes Sapientiae. Lima. Perú.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
