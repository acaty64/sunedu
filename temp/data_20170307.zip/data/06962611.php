<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CASTRO MEDINA, MAXIMILIANA IRENE</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Geógrafo por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Magister en Ciencias Forestales por la Universidad Nacional de la Amazonía Peruana, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado en Gestión Pública por la Universidad San Martin de Porres, Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Profesor de  la Facultad de Ingeniería Agraria- Escuela de Ingeniería Ambiental en Sedes Tarma y Lima. Docente de los cursos: 1) Geografía Ambiental y Recursos Naturales; 2) Cartografía y Teledetección; 3) Gestión Ambiental Urbana y Ciudades Sostenib</th></tr>
<tr><th class = 'der' align='left'>Especialista en Ordenamiento Territorial y Gestión del Territorio, Prestación de Servicios Profesionales en la Dirección de Ordenamiento Territorial en el Cargo de Especialista en Ordenamiento Territorial, DGOT del MINAM. Municipalidad Provincial de</th></tr>
<tr><th class = 'der' align='left'>Especialista en Acondicionamiento Territorial en la Gerencia de Acondicionamiento Territorial y Catastro. Municipalidad Provincial de Maynas.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
