<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ZEVALLOS DE LAS CASAS, LUISA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Grado de  Bachiller en Educación. Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciatura en Educación Secundaria. Especialidad- Inglés. Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma a nivel Maestría Docencia en el nivel Superior. Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma a nivel Maestría en Técnicas de Investigación Científica en Educación. Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Magister en Educación. Mención: Docencia en el Nivel Superior. Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de Inglés. Facultad de Educación. Especialidad Lengua Inglesa. Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente del Programa de Idiomas Extranjeros de la  Escuela de Post Grado. Universidad Nacional Mayor de San Marcos.</th></tr>
<tr><th class = 'der' align='left'>Coordinadora del Programa de Idiomas Extranjeros de la  Escuela de Post Grado. Universidad Nacional Mayor de San Marcos.</th></tr>
<tr><th class = 'der' align='left'>Facultad de Administración. Docente de Inglés en los niveles Básico  Pre Intermedio - Avanzado. Especialidad: Turismo. Universidad Nacional Federico Villarreal.</th></tr>
<tr><th class = 'der' align='left'>Coordinadora de la carrera de Lengua Inglesa. Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Docente Ordinario en la categoría de Auxiliar. Metodología de la Enseñanza del Idioma Inglés. Universidad Católica Sedes Sapientiae. Resolución Nº 001  CG  UCSS- 2006</th></tr>
<tr><th class = 'der' align='left'>Resolución Nº 013  CG  UCSS- 2009 Ratificación: Docente Ordinario en la categoría de Auxiliar. Metodología de la Enseñanza del Idioma Inglés. Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Profesora de Didáctica del Inglés I y II y Cultura y civilización en los Países del Habla Inglesa en la Facultad de Educación. Programa de Licenciatura en Educación para Profesores sin título Pedagógico en Lengua Extranjera Universidad Nacional Mayor</th></tr>
<tr><th class = 'der' align='left'>Coordinadora de la carrera profesional de Lengua Inglesa. Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente Capacitador. Empowering your English Skills Centro de Servicios Educativos Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Consultora Académica del Idioma Inglés. Richmond Publishing Santillana.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
