<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>DIAZ PARDAVE, MIGUEL ANGEL</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias en la especialidad de Ingeniería Civil por la Universidad Nacional de Ingeniería, Perú.</th></tr>
<tr><th class='der' align='left'>Título Profesional de Ingeniero Civil por la Universidad Nacional de Ingeniería,  Perú.</th></tr>
<tr><th class='der' align='left'>Magister en Ingeniería por la Universidad Nacional Autónoma de México.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Conocimiento de trabajar con el programa para diseños geotécnicos. FLAC</th></tr>
<tr><th class = 'der' align='left'>Conocimiento de trabajar con el programa para diseño de estructuras. SAP.</th></tr>
<tr><th class = 'der' align='left'>Conocimiento de trabajar con el programa para base de datos. Macros con Excel.</th></tr>
<tr><th class = 'der' align='left'>Conocimiento de trabajar con el programa para proyectos.</th></tr>
<tr><th class = 'der' align='left'>Administración de proyectos con PROJECT. Plaxis. Conocimiento de trabajar con el programa para diseños geotécnicos.</th></tr>
<tr><th class = 'der' align='left'>GeoStudio 2007. Conocimiento de trabajar con el programa para proyectos.</th></tr>
<tr><th class = 'der' align='left'>ARG GIS 9.0. Conocimiento de trabajar con el programa de proyectos. .</th></tr>
<tr><th class = 'der' align='left'>Zer Geosystem Perú S.A.C. Ingeniería Geotecnica. Ingeniero de proyectos.</th></tr>
<tr><th class = 'der' align='left'>Instituto de Ingeniería. Universidad Nacional Autónoma de México.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
