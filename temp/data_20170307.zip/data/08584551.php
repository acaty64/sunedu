<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>BARNETT GUILLEN, LIDA ESTHER</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería Administrativa por la Universidad Inca Garcilaso de la Vega, Perú.</th></tr>
<tr><th class='der' align='left'>Ingeniero Administrativo por la Universidad Inca Garcilaso de la Vega, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado en Formación de Auditor Interno e Implementador de Gestión de la Calidad por la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class='der' align='left'>Diplomado en Gestión para la Innovación en PYMES Industriales de la madera y el mueble por la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Ingeniería Industrial con mención en Gestión de Operaciones y Productividad por la Universidad Nacional Federico Villareal.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Administración de Negocios y  Finanzas Internacionales  MBA Internacional por la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Directora Ejecutiva del Centro de Apoyo al Sector Empresarial- CEASE/UCSS.</th></tr>
<tr><th class = 'der' align='left'>Docente  Universitario. Universidad Católica Sedes Sapientiae. Dictando los cursos de: Gestión de la Calidad, Sistema de Información Empresarial,  Introducción a las Ciencias Económicas y Administrativas. (Facultad de Ciencias Económicas y Comerciale</th></tr>
<tr><th class = 'der' align='left'>Consultor - Asesora Empresarial.</th></tr>
<tr><th class = 'der' align='left'>Jefe del Area de Capacitación CEASE-UCSS.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
