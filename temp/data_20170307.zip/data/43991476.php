<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>AZCONA AVALOS, GUISELLA IVONNE</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Maestría en Educación con mención en Docencia y Gestión Educativa.</th></tr>
<tr><th class='der' align='left'>Universidad César Vallejo. Lima Norte, Perú.</th></tr>
<tr><th class='der' align='left'>Docente de Educación Secundaria. Título en la Especialidad: Filosofía y Religión. Universidad Católica Sedes Sapientiae. Lima. Perú.</th></tr>
<tr><th class='der' align='left'>Grado de Bachiller en Educación. Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class='der' align='left'>Diplomado en Docencia Universitaria. Universidad Nacional de Trujillo.</th></tr>
<tr><th class='der' align='left'>Diplomado en Gestión y Calidad Educativa. Universidad Nacional de Educación Enrique Guzmán y Valle. Chosica, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Profesora de educación primaria y secundaria. Programa de apoyo social de CESED y la Diócesis de Carabayllo de la Universidad Católica Sedes Sapientiae. (2007-2009).</th></tr>
<tr><th class = 'der' align='left'>Biblioteca Central de la Universidad Católica Sedes Sapientiae. Practicante/voluntariado. Servicio personalizado al usuario y apoyo en la organización del área de hemeroteca. (2008-2011).</th></tr>
<tr><th class = 'der' align='left'>Biblioteca Andrés Aziani de la Universidad Católica Sedes Sapientiae. Personal administrativo. Servicio personalizado al usuario en el manejo de los libros de la especialidad de filosofía y teología, así como el cuidado y registro del material bibl</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae  Sede Atalaya Nopoki. Docente universitaria. Dictado de los siguientes cursos: Metodología del estudio universitario, Didáctica general, Didáctica a la Educación Intercultural Bilingüe, Teoría de la educación,</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
