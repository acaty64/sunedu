<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>GONZALES CONTRERAS, NORMA DE LOS MILAGROS</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciada en Psicología por la Universidad Señor de Sipán, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Psicología por la Universidad Señor de Sipán, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Ciencias de la Educación con mención en Psicopedagogía por la Universidad Nacional San Martín, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Tutora de jóvenes pertenecientes al programa de Beca 18 en la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class = 'der' align='left'>Coordinadora en la Facultad de Psicología de la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class = 'der' align='left'>Coordinadora del programa de Beca 18 de la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class = 'der' align='left'>Asesora de Practicantes de Psicología en la Municipalidad  Distrital de Nueva Cajamarca, Perú.</th></tr>
<tr><th class = 'der' align='left'>Psicóloga en la Institución Educativa María Montessori 00004, Perú.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
