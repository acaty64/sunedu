<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>DE LA ROSA VALVERDE, PEDRO LUIS ENRIQUE</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Contador Público por la Universidad de San Martin de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Finanzas Internacionales por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Programa de Especialización para Ejecutivos Escuela de Administración de Negocios para Graduados  ESAN.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Consultor asociado, consultoría financiera, contable, tributaria y laboral; expositor en eventos a nivel empresarial e institutos superiores en impacto estratégico en SAC Asesores y Consultores.</th></tr>
<tr><th class = 'der' align='left'>Centro de Apoyo al Sector Empresarial (CEASE): Responsable/Coordinador del Rubro Servicios Contable a empresas (Actualmente)</th></tr>
<tr><th class = 'der' align='left'>Consultor y Asesor de empresas en las especialidades de finanzas, contabilidad, tributación y laboral	(Actualmente)</th></tr>
<tr><th class = 'der' align='left'>Docente Nombrado de la Facultad de Ciencias Económicas y Comerciales de UCSS  (Actualmente)</th></tr>
<tr><th class = 'der' align='left'>Analista de Riesgos. Banco Internacional  del Perú- INTERBANK	.</th></tr>
<tr><th class = 'der' align='left'>	Analista de Riesgos. FINANCIERA PERUANA S.A.  PORFIN.</th></tr>
<tr><th class = 'der' align='left'>Jefe Administrativo y Financiero de Cooperativa de Servicios Educacionales divina trinidad promotora del Holy Trinity School						</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
