<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>VILLACORTA BERTOLOTTO, LUIS FERNANDO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciado en Administración UNMSM</th></tr>
<tr><th class='der' align='left'>Licenciado en Educación Universidad Nacional de Educación Enrique Guzmán y Valle</th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias UNMSM</th></tr>
<tr><th class='der' align='left'>Bachiller en Educación Universidad Nacional de Educación Enrique Guzmán y Valle</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Experiencia de 27 años en el sector Financiero desempeñando cargos de gerencia en 4 Bancos en el área de Créditos y Riesgos.</th></tr>
<tr><th class = 'der' align='left'>Jefe del Departamento de Prevención en la Unidad de Inteligencia Financiera del Perú- UIF Perú.</th></tr>
<tr><th class = 'der' align='left'>Actualmente se desempeña como docente universitario</th></tr>
<tr><th class = 'der' align='left'>Consultor free lance.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
