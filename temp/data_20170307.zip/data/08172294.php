<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>VELASQUEZ RODRIGUEZ, NORMA CONSTANZA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Economía</th></tr>
<tr><th class='der' align='left'>Economista</th></tr>
<tr><th class='der' align='left'>Diplomas de segunda especialidad	Gerencia de Proyectos</th></tr>
<tr><th class='der' align='left'>Doctora en Economía</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Profesora Visitante Universitá Degli Studi di Trento- Departamento de Economía y Negocios</th></tr>
<tr><th class = 'der' align='left'>Directora del Programa de Formación Continua de  la Facultad de Ciencias Económicas y Comerciales</th></tr>
<tr><th class = 'der' align='left'>Directora de la Carrera de Economía de la Facultad de Ciencias Económicas y Comerciales de la Universidad Católica Sedes Sapientiae	</th></tr>
<tr><th class = 'der' align='left'>Consultora de la Empresa EMAPE</th></tr>
<tr><th class = 'der' align='left'>Consultora para la Organización Internacional para las Migraciones -Paraguay.</th></tr>
<tr><th class = 'der' align='left'>Consultora en el diseño de encuestas y estudios en migraciones para el Programa Juventud Empleo y Migración de Naciones Unidas</th></tr>
<tr><th class = 'der' align='left'>Consultora Internacional del Proyecto Migrandina de la Organización Internacional del Trabajo.</th></tr>
<tr><th class = 'der' align='left'>Consultora en la implementación de metodologías para la gestión de inversiones en 24 gobiernos locales del Perú.. International Finance Corporation. World Bank Group.</th></tr>
<tr><th class = 'der' align='left'>Investigadora principal en la temática del Mercado de trabajo del Proyecto ELOISE Unión Europea</th></tr>
<tr><th class = 'der' align='left'>Investigadora principal del Observatorio Socio Económico Laboral de Lima Norte</th></tr>
<tr><th class = 'der' align='left'>Directora del Programa de Formación Continua de  la Facultad de Ciencias Económicas y Comerciales</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
