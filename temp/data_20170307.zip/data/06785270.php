<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ARAUZO RAMIREZ, GIOVANA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciada en Administración   por la Universidad San Martín de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomatura de Auditor Interno e Implementador de Sistemas de Gestión de Calidad ISO 9001-2015</th></tr>
<tr><th class='der' align='left'>Diplomado en Coaching  y Consultoría por la Universidad Ricardo Palma, Perú. 		</th></tr>
<tr><th class='der' align='left'>Diplomado en Gestión de Empresas Turísticas por la Universidad Católica Sedes Sapientiae, Perú.			</th></tr>
<tr><th class='der' align='left'>Diplomado de Didáctica y Capacitación en las nuevas tecnologías informáticas (IT) del aula real al aula virtual por EUROCOLUNIVEL- Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Gestión e Innovación Educativa por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Jefe de la Oficina de Grados y Títulos - UCSS</th></tr>
<tr><th class = 'der' align='left'>Coordinadora de Grados y Títulos   - UCSS</th></tr>
<tr><th class = 'der' align='left'>Asistente de la Decana de la Facultad Ciencias Económicas y Comerciales - UCSS</th></tr>
<tr><th class = 'der' align='left'>Asistente de la Coordinación Académica  de la Facultad Ciencias Económicas y Comerciales - UCSS</th></tr>
<tr><th class = 'der' align='left'>Secretaría de la Facultad  Ciencias  Económicas y  Comerciales  UCSS.</th></tr>
<tr><th class = 'der' align='left'>Asistente del Coordinador de la Oficina del Centro Preuniversitario y  Oficina de Admisión  UCSS.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
