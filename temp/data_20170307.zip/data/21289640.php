<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ARIAS RIMARI, ELIANA MARIA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciada en Educación Secundaria: Filosofía y Religión por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Filosofía de la Educación en el Contexto de la Emergencia Educativa por la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Superior en la Universidad Católica Sedes Sapientiae (UCSS) en los cursos de Introducción a la Ciencias Educativas, Educación Desarrollo y Comunidad, Doctrina Social de la Iglesia, Seminario de Literatura.</th></tr>
<tr><th class = 'der' align='left'>Labor administrativa en la Facultad de Ciencias de la Educación y Humanidades, Coordinadora Académica de la Facultad de Educación de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Responsable administrativo en el Area de UCSSVirtual 2014-2016</th></tr>
<tr><th class = 'der' align='left'>Tutora virtual pregrado.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
