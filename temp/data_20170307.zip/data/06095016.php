<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ALFARO PALACIOS DE HUAITA, EDITH BETTY</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Docente de Educación Secundaria con Título en la Especialidad: Biología y Química por la Escuela Normal Superior Mixta de La Victoria, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma de Segunda Especialidad en Formación Magisterial por la Pontificia Universidad Católica del Perú, Lima- Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Educación de la Creatividad por el Instituto Pedagógico Latinoamericano y Caribeño- IPLAC (Cuba). Derrama Magisterial (Perú).</th></tr>
<tr><th class='der' align='left'>Maestría en Gestión de la Educación por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de educación básica regular en las II.EE. Carlos Wiesse (Comas), Rosa de Santa María (Breña) y Sagrados Corazones Belén San Isidro.</th></tr>
<tr><th class = 'der' align='left'>Docente capacitadora de docentes en servicio para los programas de Formación docente del Ministerio de Educación, a través de Educa, CISE- PUCP.</th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Superior en la Universidad Católica Sedes Sapientiae (UCSS) en los cursos de Ciencias Naturales, Ecología y Educación, Seminario de Tesis II (Pre-grado)</th></tr>
<tr><th class = 'der' align='left'>Coordinadora Académica de la Facultad de Educación de la UCSS.</th></tr>
<tr><th class = 'der' align='left'>Jefe de la Unidad Central de Calidad Académica y Acreditación.</th></tr>
<tr><th class = 'der' align='left'>Docente de posgrado en la Pontificia Universidad Católica del Perú.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
