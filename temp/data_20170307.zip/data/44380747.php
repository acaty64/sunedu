<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>RAMOS PEREZ, ERICK WILLIAMS</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Educación Secundaria Especialidad de Informática. Universidad Católica Sedes Sapientiae. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Título Profesional de Licenciado en Educación Secundaria Especialidad de Informática. Universidad Católica Sedes Sapientiae. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Estudios cursando en Maestría en Gestión de Tecnologías de Información. Universidad César Vallejo.  Lima. Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de Matemática, en I.E.P. Sebastián Goyeneche y Barreda</th></tr>
<tr><th class = 'der' align='left'>Docente de computación e Informática, en I.E. Estado Unidos</th></tr>
<tr><th class = 'der' align='left'>Docente de Robótica , en I.E. Consorcio Educativo Ingeniería</th></tr>
<tr><th class = 'der' align='left'>Docente de Robótica , en I.E. Melgar Millenium</th></tr>
<tr><th class = 'der' align='left'>Docente de Computación e Informática, en I.E.P. San Vicente Ferrer</th></tr>
<tr><th class = 'der' align='left'>Capacitación de aulas virtuales a docentes, Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Docente en Universidad Católica Sedes Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
