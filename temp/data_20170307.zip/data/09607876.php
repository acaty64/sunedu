<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MASGO LARA, LUIS ALBERTO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciado en Educación Secundaria  con especialidad en Matemática por la Pontificia Universidad Católica del Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Doctorado en Ciencias de la Educación. Egresado 2013- II. Universidad Nacional de Educación Enrique Guzmán y Valle.</th></tr>
<tr><th class='der' align='left'>Grado: Bachiller en Ingeniería Civil por la Universidad Nacional Federico Villareal (2001)</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Coordinador del área de matemáticas en Universidad Católica Sedes Sapientiae año: 2004 hasta la actualidad.</th></tr>
<tr><th class = 'der' align='left'>Profesor del curso: matemática básica.  Universidad de Piura - anexo Lima. Facultad de Derecho</th></tr>
<tr><th class = 'der' align='left'>Fecha: actualmente</th></tr>
<tr><th class = 'der' align='left'>Profesor del curso: Matemática básica (algebra-geometría) Universidad de Piura-anexo Lima. facultad de ingeniería industrial. (2011-2016)</th></tr>
<tr><th class = 'der' align='left'>Profesor del curso: matemática I  (para alumnos de beca 18) Universidad Católica Sedes Sapientiae (mayo 2015 hasta agosto 2015).</th></tr>
<tr><th class = 'der' align='left'>Profesor del curso: Razonamiento Matemático. Universidad Nacional Agraria la Molina (centro preuniversitario) (año: 2015-I hasta la actualidad)</th></tr>
<tr><th class = 'der' align='left'>Profesor del curso: trigonometría. Universidad Nacional Agraria la Molina (centro preuniversitario) (año: 2015-I hasta la actualidad)</th></tr>
<tr><th class = 'der' align='left'>Profesor del curso: análisis matemático I Universidad Católica Sedes Sapientiae.( año 2009 hasta la actualidad)</th></tr>
<tr><th class = 'der' align='left'>Jefe de práctica del curso: matemáticas I. Pontificia Universidad Católica del Perú, (2013-I hasta 2014-I )</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
