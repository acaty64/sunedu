<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>GONZALES CALLE, FREDY ABELARDO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciado en Ciencias Militares por la Escuela Militar Del Perú "Coronel Francisco Bolognesi",  Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Jefe del Departamento Académico de Ingeniería Electrónica y Sistemas en el ICTE</th></tr>
<tr><th class = 'der' align='left'>Analista de Sistemas en el Centro de Informática del Ejército</th></tr>
<tr><th class = 'der' align='left'>Jefe de Sistemas del Comando Conjunto de las Fuerzas Armadas</th></tr>
<tr><th class = 'der' align='left'>Jefe de Sistemas del Hospital Militar Central</th></tr>
<tr><th class = 'der' align='left'>Jefe de Sistemas del Servicio de Intendencia del Ejército</th></tr>
<tr><th class = 'der' align='left'>Jefe de Sistemas del Comando Logístico del Ejército</th></tr>
<tr><th class = 'der' align='left'>Jefe de Sistemas del Ejercito (CINFE)</th></tr>
<tr><th class = 'der' align='left'>Jefe de Sistemas del Comando Conjunto de las FFAA.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
