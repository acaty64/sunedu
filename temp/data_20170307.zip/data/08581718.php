<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ELESCANO CORDOVA, WILFREDO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Computación por la Universidad Nacional Mayor de San Marcos, Perú</th></tr>
<tr><th class='der' align='left'>Licenciado en Computación por la Universidad Nacional Mayor de San Marcos, Perú</th></tr>
<tr><th class='der' align='left'>Diploma en Informática Educativa por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Ingeniería de Sistemas por la Universidad Alas Peruanas, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Apoyo en control docente en la Universidad Católica Sedes Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
