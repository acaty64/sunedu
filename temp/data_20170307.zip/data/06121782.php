<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>LASTARRIA ZAPATA, JOSE ALEJANDRO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad Inca Garcilaso de la Vega, Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Profesor en Educación Secundaria en Filosofía y Ciencias Sociales por la Universidad Inca Garcilaso de la Vega, Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Gestión Estratégica Educativa por la Universidad Nacional Pedro Ruiz Gallo, Lambayeque, Perú.</th></tr>
<tr><th class='der' align='left'>Doctorado en Ciencias de la Educación por la Universidad Nacional Enrique Guzmán y Valle, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Trabajador de la Oficina de personal de la UGEL 04.</th></tr>
<tr><th class = 'der' align='left'>Docente Capacitador del Centro de Servicios Educativos para el Desarrollo (CESED) de la UCSS.</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario de pregrado y postgrado de la UCSS.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
