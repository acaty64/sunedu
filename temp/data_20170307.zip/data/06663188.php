<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>VILCA DELGADO, WILLIAMS SHANE</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciado en Educación. Especialidades: Matemática, Física y Educación Religiosa por la Universidad Marcelino Champagnat, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad Marcelino Champagnat, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Didáctica de la Física por la Universidad de Ciencias Aplicadas UPC, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Educación Universitaria por la Universidad de Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría  en Educación, con mención en Educación Matemática por la Universidad Nacional de Educación Enrique Guzmán y Valle, La Cantuta, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente contratado a tiempo completo de la Escuela Profesional de Tecnología Médica de la Facultad de Ciencias de la Salud  Asociación Universidad Privada San Juan Bautista.</th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Básica Regular en:Colegio San Ignacio de Recalde ,Colegio San  Luis Maristas .</th></tr>
<tr><th class = 'der' align='left'>Docente en la Universidad Católica Sedes Sapientiae  Facultad de Ciencias de la Educación y Humanidades; Facultad de Derecho y Ciencias Políticas y en la Universidad Científica del Sur   Matemática, Física.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
