<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>SOTO CANALES, PEDRO PASCUAL</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad Particular Marcelino Champagnat, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciado en Educación en las especialidades de Ciencias Históricos Sociales y Ciencias de la Religión por la Universidad Particular Marcelino Champagnat, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Historia con mención: Historia económica por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma de Docencia Universitaria por la Universidad Nacional de Educación Enrique Guzmán y Valle y el Instituto de Desarrollo Gerencial, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Seguridad y Defensa Nacional por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente en: Institución Educativa 2027 José María Arguedas, SMP.  (1993 - 2017); Escuela de Formación de Catequistas de la Vicaria VIII	 (2000 - 2015); Universidad Católica Sedes Sapientiae, Los Olivos. (2000 - 2017); Facultad de Teología Redempto</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
