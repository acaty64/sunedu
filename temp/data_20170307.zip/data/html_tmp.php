<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align="center" cellpadding="0" cellspacing="0">
<thead>
<tr>
<th colspan='5'>
PLANA DOCENTE 2016<br/>UNIVERSIDAD CATÓLICA SEDES SAPIENTIAE                       
</th>
</tr>
<tr>
<th class='subtit'>Reg.</th>
<th class='subtit'>Apellidos y Nombres</th>
<th class='subtit'>País</th>
<th class='subtit'>Categoría</th>
<th class='subtit'>Dedicación</th>
</tr>
</thead>
<tbody>
<tr><td>1</td> <td align='left'><a href='43374968.php'>ACHO RIOS, NIMIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>2</td> <td align='left'><a href='10198993.php'>ACOSTA QUISPE, PAUL HENRY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>3</td> <td align='left'><a href='06740033.php'>ACUÑA BERROSPI, ALEX</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>4</td> <td align='left'><a href='22502265.php'>AGUILAR LAGUNA, ASTRID</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>5</td> <td align='left'><a href='32987729.php'>AGUILAR PAREDES, ERNESTO DARWIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>6</td> <td align='left'><a href='00838529.php'>AGUILAR RUIZ, EZSEQUIEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>7</td> <td align='left'><a href='40377484.php'>AGUIRRE QUINTANILLA, MERLE MILAGROS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>8</td> <td align='left'><a href='07143360.php'>ALARCON MORE, MODESTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>9</td> <td align='left'><a href='07809580.php'>ALAYZA ARIAS, MANUEL ENRIQUE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>10</td> <td align='left'><a href='43881278.php'>ALBARRAN MEDINA, ELVIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>11</td> <td align='left'><a href='18067237.php'>ALBITRES INFANTES, JHONNY JAVIER</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>12</td> <td align='left'><a href='41349511.php'>ALBUJAR DE LA CRUZ, MARIA MALENA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>13</td> <td align='left'><a href='27074721.php'>ALCANTARA BOZA, FRANCISCO ALEJANDRO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>14</td> <td align='left'><a href='32899961.php'>ALEGRE CALDERON, LUIS ENRIQUE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>15</td> <td align='left'><a href='06095016.php'>ALFARO PALACIOS DE HUAITA, EDITH BETTY</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>16</td> <td align='left'><a href='19850381.php'>ALIAGA ROTA, LUIS ANTONIO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>17</td> <td align='left'><a href='09638521.php'>ALVA PALOMARES, GLADIA MARIBEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>18</td> <td align='left'><a href='17831799.php'>ALVA PRETEL, ROSSIO DEL PILAR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>19</td> <td align='left'><a href='10680956.php'>ALVARADO VIZCARDO, BETSY ROCIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>20</td> <td align='left'><a href='41185035.php'>AMBROSIO GARCIA, GIULLIANA PATRICIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>21</td> <td align='left'><a href='41809938.php'>AMBULAY BRICEÑO, JOHNNY PERCY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>22</td> <td align='left'><a href='09763452.php'>ANAYA RAYMUNDO, MARIO ANTONIO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>23</td> <td align='left'><a href='43925029.php'>ANCAJIMA TIMANA, JUAN CARLOS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>24</td> <td align='left'><a href='42457051.php'>ANDIA VILCAPOMA, DAVID HERNAN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>25</td> <td align='left'><a href='40706670.php'>ANGULO VALDIVIA, RAFAEL MARTIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>26</td> <td align='left'><a href='22406535.php'>ANTONIO BASILIO, DORILA TEODOSIA</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>27</td> <td align='left'><a href='25552563.php'>AQUISSE TORRES, TEODORO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>28</td> <td align='left'><a href='07197659.php'>ARANIBAR RIVERO, RUTH MILAGROS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>29</td> <td align='left'><a href='10283796.php'>ARASHIRO TAMASHIRO, ANA CECILIA</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>30</td> <td align='left'><a href='06785270.php'>ARAUZO RAMIREZ, GIOVANA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>31</td> <td align='left'><a href='07739006.php'>ARELLANO CABO, MARIETTA ZORAIDA SOCORRO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>32</td> <td align='left'><a href='08578047.php'>ARIAS MARCOS, ADA GABRIELA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>33</td> <td align='left'><a href='10585743.php'>ARIAS PALOMINO, MARCO ANTONIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>34</td> <td align='left'><a href='21289640.php'>ARIAS RIMARI, ELIANA MARIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>35</td> <td align='left'><a href='44105190.php'>ARRUNATEGUI SALDARRIAGA, SILVER ANDRES</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>36</td> <td align='left'><a href='08569906.php'>ASPILCUETA PEREZ, CRISTOBAL URIEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>37</td> <td align='left'><a href='07501770.php'>AYALA CALDERON, KRISTHIAN OLIVER</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>38</td> <td align='left'><a href='02848481.php'>AYALA DIAZ, MARCOS AQUILES</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>39</td> <td align='left'><a href='06783487.php'>AYUDANTE RELAIZA, ELIZABETH</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>40</td> <td align='left'><a href='43991476.php'>AZCONA AVALOS, GUISELLA IVONNE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>41</td> <td align='left'><a href='42109759.php'>AZULA DIAZ, HENRY EDILBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>42</td> <td align='left'><a href='09853135.php'>BALLENA DOMINGUEZ, VICTOR GIOVANNY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>43</td> <td align='left'><a href='09549434.php'>BALTODANO DIAZ, RAUL IVAN</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>44</td> <td align='left'><a href='20006543.php'>BALVIN EGAS, EFRAIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>45</td> <td align='left'><a href='08584551.php'>BARNETT GUILLEN, LIDA ESTHER</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>46</td> <td align='left'><a href='10621491.php'>BASTO MUÑOZ, ROSA LILIANA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>47</td> <td align='left'><a href='40611601.php'>BASUALDO LOPEZ, ELIAS IVAN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>48</td> <td align='left'><a href='00160971.php'>BECERRA GARCIA, DANIEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>49</td> <td align='left'><a href='08271469.php'>BECERRA PALOMINO, CARLOS ENRIQUE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>50</td> <td align='left'><a href='000105841.php'>BENITO RODRIGUEZ, JOSE ANTONIO</td> <td>ESPAÑA</td> <td>Ordinario Principal</td> <td>Tiempo Parcial</td> </tr>
<tr><td>51</td> <td align='left'><a href='09854795.php'>BERMUDEZ TAPIA, MANUEL ALEXIS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>52</td> <td align='left'><a href='000332855.php'>BIDINOST ., PAOLO</td> <td>ITALIA</td> <td>Ordinario Principal</td> <td>Dedicacion Exclusiva</td> </tr>
<tr><td>53</td> <td align='left'><a href='25629280.php'>BIO GAIDOLFI, CARLA MARIA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>54</td> <td align='left'><a href='25746345.php'>BIO GAIDOLFI, FAUSTO MICHELE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>55</td> <td align='left'><a href='07796524.php'>BLAS MONTENEGRO, LUZ PETRONILA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>56</td> <td align='left'><a href='000044710.php'>BOLIS ., GIAN BATTISTA FAUSTO</td> <td>ITALIA</td> <td>Ordinario Principal</td> <td>Dedicacion Exclusiva</td> </tr>
<tr><td>57</td> <td align='left'><a href='21448115.php'>BOZA OLAECHEA, MARGARITA LUISA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>58</td> <td align='left'><a href='10530728.php'>BRAVO LOPEZ, NATALY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>59</td> <td align='left'><a href='08080775.php'>BRAVO SAENZ, WALTER ALEJANDRO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>60</td> <td align='left'><a href='000367365.php'>BRIOZZO PEREYRA, MARIA TERESA</td> <td>ITALIA</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>61</td> <td align='left'><a href='40723640.php'>BUENDIA ROMERO, CESAR ANTONIO</td> <td>ESPAÑA</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>62</td> <td align='left'><a href='07747856.php'>BURGA GUTIERREZ, ROSA MARIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>63</td> <td align='left'><a href='40067119.php'>BURGOS BASTIDAS, ANGIE ROMY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>64</td> <td align='left'><a href='15746875.php'>CABALLERO CANTU, JOSE JEREMIAS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>65</td> <td align='left'><a href='09869377.php'>CABANILLAS ROJAS, WILLIAM EUGENIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>66</td> <td align='left'><a href='08947396.php'>CABELLO TORRES, RITA JAQUELINE</td> <td>ESPAÑA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>67</td> <td align='left'><a href='06456480.php'>CACERES URBINA, HILDA YOLANDA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>68</td> <td align='left'><a href='19857956.php'>CALIXTO ALIAGA, SILVIO GUSTAVO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>69</td> <td align='left'><a href='29587019.php'>CALLE CHEJE, YURI HOLSIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>70</td> <td align='left'><a href='08667250.php'>CAMARENA ARESTEGUI, JHON JHONY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>71</td> <td align='left'><a href='42658184.php'>CAMINO RIVERA, CRISTIAN ENMANUEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>72</td> <td align='left'><a href='80278308.php'>CAPUÑAY GONZALES, MARIA LIDIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>73</td> <td align='left'><a href='04304833.php'>CARDENAS CABEZAS, JESUS MEDALIT</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>74</td> <td align='left'><a href='08665105.php'>CARDENAS LEDESMA, BLUIDSON PABLO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>75</td> <td align='left'><a href='10735921.php'>CARRASCAL VIZARRETA, URSULA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>76</td> <td align='left'><a href='09982771.php'>CARRASCO LOPEZ, ILIANOV PABLO</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>77</td> <td align='left'><a href='09339841.php'>CARREÑO MARTINEZ, JUAN ELIAS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>78</td> <td align='left'><a href='15612175.php'>CARREÑO ROLDAN, ALBERTO DANILO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>79</td> <td align='left'><a href='15744138.php'>CASTAÑEDA CHIRRE, ELVIRA TEOFILA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>80</td> <td align='left'><a href='06188898.php'>CASTAÑEDA RAMIREZ, CESAR WALTER</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>81</td> <td align='left'><a href='00163075.php'>CASTILLA CRUZ, HILARIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>82</td> <td align='left'><a href='41648542.php'>CASTILLO GUTIERREZ, GIANCARLO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>83</td> <td align='left'><a href='08124577.php'>CASTILLO PICHEN, SEGUNDO CESAR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>84</td> <td align='left'><a href='15601765.php'>CASTRO BARTOLOME, HECTOR JORGE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>85</td> <td align='left'><a href='06962611.php'>CASTRO MEDINA, MAXIMILIANA IRENE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>86</td> <td align='left'><a href='45473955.php'>CECILIANO CAMONES, SHIRLEY KARINA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>87</td> <td align='left'><a href='10207235.php'>CERON SALAZAR, NORMA JULIETA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>88</td> <td align='left'><a href='17615559.php'>CESPEDES PANDURO, BERNARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>89</td> <td align='left'><a href='17561750.php'>CESPEDES PANDURO, JACOBA DEL PILAR</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>90</td> <td align='left'><a href='17634166.php'>CESPEDES PANDURO, SUGEIT EMPERATRIZ</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>91</td> <td align='left'><a href='08500622.php'>CHAVEZ BARCES, MARIA ELENA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>92</td> <td align='left'><a href='09883255.php'>CHAVEZ MEDRANO, VICTOR RICARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>93</td> <td align='left'><a href='09893536.php'>CHAVEZ NORABUENA, KARINA JUDITH</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>94</td> <td align='left'><a href='09140700.php'>CHAVEZ PRADO, ANGELICA MARITZA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>95</td> <td align='left'><a href='08470274.php'>CHAVEZ VEGA, CARLOS</td> <td>ARGENTINA</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>96</td> <td align='left'><a href='08185119.php'>CHINCHA ALVAREZ, ANA MARIA NINOSHKA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>97</td> <td align='left'><a href='03317072.php'>CHIROQUE FLORES, VICTOR MANUEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>98</td> <td align='left'><a href='40664123.php'>CHIROQUE VELASQUEZ, GRISEL VIOLETA</td> <td>CHILE</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>99</td> <td align='left'><a href='06157624.php'>CHONG CENTURION, ERNESTO GALVARINO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>100</td> <td align='left'><a href='02434440.php'>CHURA GOMEZ, CESAR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>101</td> <td align='left'><a href='09673277.php'>CISNEROS AYALA, CLAUDIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>102</td> <td align='left'><a href='08732585.php'>CJAHUA HUANACHI, ZITA SILVIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>103</td> <td align='left'><a href='40343126.php'>CLAROS SANTIAGO, CARLOS EDUARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>104</td> <td align='left'><a href='41376156.php'>COLAN VALLADARES, CESAR EDUARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>105</td> <td align='left'><a href='08042573.php'>COLLAZOS GUTIERREZ, ADELMA ELIZABETH</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>106</td> <td align='left'><a href='000420096.php'>CONTINI ., GIULIANA</td> <td>ITALIA</td> <td>Ordinario Principal</td> <td>Dedicacion Exclusiva</td> </tr>
<tr><td>107</td> <td align='left'><a href='07743259.php'>CONTRERAS FLORES, WALTER PEDRO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>108</td> <td align='left'><a href='09983907.php'>CORAL YGNACIO, MARCO ANTONIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>109</td> <td align='left'><a href='16647035.php'>CORDOVA SALCEDO, FELIMON DOMINGO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>110</td> <td align='left'><a href='21444290.php'>CORONADO SANTILLAN, LUIS AUGUSTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>111</td> <td align='left'><a href='21060243.php'>CORONEL QUINTEROS, EDITH MARIA</td> <td>BOLIVIA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>112</td> <td align='left'><a href='08569923.php'>CORTEZ MONDRAGON, CESAR SEGUNDO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>113</td> <td align='left'><a href='10063247.php'>COSTA RODRIGUEZ, JORGE EDUARDO</td> <td>ITALIA</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>114</td> <td align='left'><a href='40580884.php'>COZ CONTRERAS, SOFIA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>115</td> <td align='left'><a href='06807083.php'>COZ CONTRERAS, VANESA CAROLINA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>116</td> <td align='left'><a href='08780148.php'>CRISTOBAL VELASQUEZ, DORIS HILDA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>117</td> <td align='left'><a href='06660409.php'>CRUZ ACUÑA, EDGAR ODON</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>118</td> <td align='left'><a href='40113161.php'>CRUZADO MELENDEZ, MELINA ROXANA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>119</td> <td align='left'><a href='41414387.php'>DAVALOS ARCA, JOSEPH KENNETH</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>120</td> <td align='left'><a href='22423025.php'>DAVILA LAGUNA, RONALD FERNANDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>121</td> <td align='left'><a href='08519098.php'>DAVILA TAPIA, JOSE VICENTE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>122</td> <td align='left'><a href='07681903.php'>DE LA CRUZ CAMACO, DANTE PEDRO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>123</td> <td align='left'><a href='08707499.php'>DE LA ROSA VALVERDE, CECILIA MELCHORA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>124</td> <td align='left'><a href='08737456.php'>DE LA ROSA VALVERDE, PEDRO LUIS ENRIQUE</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>125</td> <td align='left'><a href='07760676.php'>DEL BUSTO BRETONECHE, RAFAEL MARTIN</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>126</td> <td align='left'><a href='07764635.php'>DEL BUSTO BRETONECHE, RAUL ENRIQUE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>127</td> <td align='left'><a href='07876526.php'>DEL CAMPO GAYTAN, TEOBALDO JULIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>128</td> <td align='left'><a href='41296093.php'>DELGADO HEREDIA, ELIAS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>129</td> <td align='left'><a href='10738430.php'>DIAZ DIAZ, LILIANA</td> <td>ESPAÑA</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>130</td> <td align='left'><a href='10301350.php'>DIAZ GERVASI, GIOVANI MARTIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>131</td> <td align='left'><a href='15693637.php'>DIAZ NONATO, MIGUEL ALCIDES</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>132</td> <td align='left'><a href='40074376.php'>DIAZ PARDAVE, MIGUEL ANGEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>133</td> <td align='left'><a href='10603883.php'>DIAZ VARGAS, SELENI ADILIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>134</td> <td align='left'><a href='07149775.php'>DOMINGUEZ JARA, ALICIO VICTOR</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>135</td> <td align='left'><a href='07847018.php'>DUCOS CASAS, TEODORICO JESUS ADOLFO ST</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>136</td> <td align='left'><a href='15607816.php'>ECHEGARAY ROMERO, HECTOR ORLANDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>137</td> <td align='left'><a href='09887433.php'>EGOAVIL DE LA CRUZ, CARLOS HUGO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>138</td> <td align='left'><a href='08581718.php'>ELESCANO CORDOVA, WILFREDO CLEMENTE</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>139</td> <td align='left'><a href='10000717.php'>ENCISO ZAVALA, FAUSTA ISABEL</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>140</td> <td align='left'><a href='80224089.php'>ENRIQUE CORDOVA, ELBERT</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>141</td> <td align='left'><a href='29533833.php'>ENRIQUEZ CACERES, MANUEL IGNACIO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Parcial</td> </tr>
<tr><td>142</td> <td align='left'><a href='001067402.php'>ENRIQUEZ CANTO, YORDANIS</td> <td>ITALIA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>143</td> <td align='left'><a href='44369968.php'>ERAZO CAMACHO, MILTON ROYER</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>144</td> <td align='left'><a href='18170287.php'>ESPINOLA MARIÑOS, WILDER ALEX</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>145</td> <td align='left'><a href='08042574.php'>ESPINOZA ALATA, REYNALDO VICTOR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>146</td> <td align='left'><a href='21134423.php'>ESTARES PORRAS, OMAR EDUARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>147</td> <td align='left'><a href='32544407.php'>FARFAN ZEGARRA, HAROLD MARTIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>148</td> <td align='left'><a href='32543625.php'>FERNANDEZ CARDOZA, JANET DEL ROSARIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>149</td> <td align='left'><a href='09600036.php'>FERNANDEZ CONDORI, ROXANA CARLA</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>150</td> <td align='left'><a href='42153498.php'>FERNANDEZ CRUZ, EMILIANO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>151</td> <td align='left'><a href='40962158.php'>FERNANDEZ MONTEMAYOR, VERONICA INES</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>152</td> <td align='left'><a href='21133103.php'>FERNANDEZ SUASNABAR, SELENA CELESTE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>153</td> <td align='left'><a href='10683741.php'>FIGUEROA ANAMARIA, JORGE HUGO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>154</td> <td align='left'><a href='08612078.php'>FLORES BALLESTEROS, TEODORO EMILIO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>155</td> <td align='left'><a href='08039505.php'>FLORES MORALES, JORGE ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>156</td> <td align='left'><a href='09854418.php'>FLORES ORTEGA, YESSIKA GRAYA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>157</td> <td align='left'><a href='06859230.php'>FLORES PALOMINO, FLORESMILO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>158</td> <td align='left'><a href='17611959.php'>FONSECA RIVERA, IRMA CAROLINA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>159</td> <td align='left'><a href='41291740.php'>FRANCO DEL CASTILLO, GLORIA NADIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>160</td> <td align='left'><a href='07708918.php'>FUENTES SUPANTA DE FUKUNAGA, NORMA</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>161</td> <td align='left'><a href='40660826.php'>GAGO RODRIGO, KATIA ELVA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>162</td> <td align='left'><a href='09607929.php'>GALINDO GONZALES, TANIA DEL CARMEN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>163</td> <td align='left'><a href='43253292.php'>GAMARRA CUEVA, ALEXANDER</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>164</td> <td align='left'><a href='000834605.php'>GAMBATESA ., RUGGIERO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>165</td> <td align='left'><a href='32860015.php'>GARCES DIAZ, VICTOR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>166</td> <td align='left'><a href='10818578.php'>GARCIA MASIAS, JESSICA VANESSA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>167</td> <td align='left'><a href='07722412.php'>GARCIA REGAL, RAUL FRANCISCO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>168</td> <td align='left'><a href='09781789.php'>GARCIA ROJAS, VIDAL SATURNINO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>169</td> <td align='left'><a href='06914150.php'>GARCIA ROJAS, YRMA DORIS</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>170</td> <td align='left'><a href='15727139.php'>GARCIA SUSANO, MARITZA GIOVANA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>171</td> <td align='left'><a href='05256191.php'>GARCIA TRIGOZO, JOSE ABEL</td> <td>ITALIA</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>172</td> <td align='left'><a href='06889871.php'>GARCIA VILCAPOMA, GLADYS HORTENCIA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>173</td> <td align='left'><a href='09635561.php'>GASTELLO MATHEWS, WILLY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>174</td> <td align='left'><a href='10117155.php'>GOMERO ESPINOZA, CLARA ROSIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>175</td> <td align='left'><a href='09630967.php'>GONZAGA ESPINOZA, MARIA NELLY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>176</td> <td align='left'><a href='10683679.php'>GONZALES ANAMPA, LUIS OMAR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>177</td> <td align='left'><a href='43667732.php'>GONZALES CALLE, FREDY ABELARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>178</td> <td align='left'><a href='47017231.php'>GONZALES CONTRERAS, NORMA DE LOS MILAGROS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>179</td> <td align='left'><a href='00165739.php'>GONZALES COTRINA, JULIO CESAR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>180</td> <td align='left'><a href='21135050.php'>GONZALES QUISPE, HUMBERTO FERNANDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>181</td> <td align='left'><a href='09486797.php'>GONZALEZ FARFAN, MARIA EUGENIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>182</td> <td align='left'><a href='06269543.php'>GONZALEZ SAENZ, MODESTA MARIA ADELA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>183</td> <td align='left'><a href='25426710.php'>GOYBURU MOLINA DE GOMEZ, MARLENE ESTHER</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Parcial</td> </tr>
<tr><td>184</td> <td align='left'><a href='00860188.php'>GRANDEZ PORTOCARRERO, AUGUSTO MARINO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>185</td> <td align='left'><a href='07556886.php'>GUEVARA LOPEZ, HERLINDA ESTELA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>186</td> <td align='left'><a href='10284099.php'>GUTIERREZ ASCARZA, LUZ YOLANDA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>187</td> <td align='left'><a href='10280181.php'>GUTIERREZ AZCARZA, DORIS EDITH</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>188</td> <td align='left'><a href='23946287.php'>GUTIERREZ BUSTAMANTE, SILVIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>189</td> <td align='left'><a href='08798497.php'>GUTIERREZ CASTILLO, MARIO ANTONIO</td> <td>PERÚ</td> <td>Ordinario Principal</td> <td>Dedicacion Exclusiva</td> </tr>
<tr><td>190</td> <td align='left'><a href='06957981.php'>GUTIERREZ PUSARI, JUSTINIANO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>191</td> <td align='left'><a href='10727756.php'>HERNANDEZ PINO, GIOVANA LOURDES</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>192</td> <td align='left'><a href='44008733.php'>HERNANDEZ VASQUEZ, ERICK BRANDUZ</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>193</td> <td align='left'><a href='40660575.php'>HERRERA CONCHA, RENAN ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>194</td> <td align='left'><a href='06775252.php'>HIDALGO GOMEZ, ALFONSO GREGORIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>195</td> <td align='left'><a href='09905355.php'>HUAMAN GUTIERREZ, JOSE MANUEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>196</td> <td align='left'><a href='10454580.php'>HUAMAN GUTIERREZ, OSCAR GUSTAVO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>197</td> <td align='left'><a href='44127158.php'>HUAPAYA PARDAVE, RICHARD JOAO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>198</td> <td align='left'><a href='16170336.php'>HUIMAN SANDOVAL, JOSE ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>199</td> <td align='left'><a href='42643059.php'>HURTADO MERINO, ALBERTO ZACARIAS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>200</td> <td align='left'><a href='10735796.php'>IBERICO CHAVEZ, ROLANDO RAMIRO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>201</td> <td align='left'><a href='46532718.php'>IMAN MORAN, ANGHELA MIRELLA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>202</td> <td align='left'><a href='08646807.php'>INCA BAZAN, FERNANDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>203</td> <td align='left'><a href='08396132.php'>INFANTES SANTILLAN, EDUARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>204</td> <td align='left'><a href='43089939.php'>IZQUIERDO HERNANDEZ, DENIS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>205</td> <td align='left'><a href='07589826.php'>JARA ASENCIOS DE MENDOZA, IRMA VICTORIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>206</td> <td align='left'><a href='09304104.php'>KCOMT CHUCAN DE MUJICA, OLINDA ROXANA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>207</td> <td align='left'><a href='09626330.php'>KUONG MERIK, MIGUEL ANGEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>208</td> <td align='left'><a href='15736641.php'>LA ROSA BENEDICTO, CARLOS GIOVANI</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>209</td> <td align='left'><a href='07961578.php'>LA ROSA BOTONERO, JAVIER</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>210</td> <td align='left'><a href='02689556.php'>LABAN ELERA, VICTOR TEODORO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>211</td> <td align='left'><a href='40376829.php'>LAFOSSE MASIAS, JORGE LUIS</td> <td>ITALIA</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>212</td> <td align='left'><a href='42548764.php'>LAGOS LIBERATO, DAVID</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>213</td> <td align='left'><a href='41494750.php'>LALUPU VALLADOLID, JOSE HUMBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>214</td> <td align='left'><a href='40438250.php'>LARCO AGUILAR, AMADA VICTORIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>215</td> <td align='left'><a href='06121782.php'>LASTARRIA ZAPATA, JOSE ALEJANDRO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>216</td> <td align='left'><a href='42362708.php'>LAURENCIO LUNA, MANUEL ISMAEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>217</td> <td align='left'><a href='10734053.php'>LECETA GOBITZ, ROSSINA ALDA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>218</td> <td align='left'><a href='41658689.php'>LEONARDO RAMOS, MILAGROS ELISA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>219</td> <td align='left'><a href='000754989.php'>LEYTON CARDENAS, CARLOS ALBERTO</td> <td>COLOMBIA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>220</td> <td align='left'><a href='07924964.php'>LIMONCHI CANALES, ITALO ALDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>221</td> <td align='left'><a href='07282807.php'>LINO QUICAÑA, HECTOR JOSE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>222</td> <td align='left'><a href='03110339.php'>LIZANO CARMEN, LAZARO ELIAS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>223</td> <td align='left'><a href='21087618.php'>LOBATO CALDERON, GODOFREDO ROMAN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>224</td> <td align='left'><a href='06674117.php'>LOPEZ AVILES, NESTOR MANUEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>225</td> <td align='left'><a href='000380761.php'>LOPEZ BRAVO, RODOLFO ODLANIER</td> <td>CHILE</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>226</td> <td align='left'><a href='08153969.php'>LOPEZ BULNES, JORGE LUIS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>227</td> <td align='left'><a href='08584920.php'>LOPEZ DEL MAR, JOEL BENIGNO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>228</td> <td align='left'><a href='00373720.php'>LOPEZ REQUENA, JUAN EDUARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>229</td> <td align='left'><a href='09639954.php'>LUNA MIRANDA, RAUL</td> <td>ITALIA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>230</td> <td align='left'><a href='10157753.php'>LUNA RAMIREZ, EDITH NORMA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>231</td> <td align='left'><a href='15723552.php'>LUNA SANTOS, JUAN CARLOS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>232</td> <td align='left'><a href='09392792.php'>LUY MONTEJO, CARLOS AUGUSTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>233</td> <td align='left'><a href='15612229.php'>MACEDO BARRERA, EUFEMIO MAGNO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>234</td> <td align='left'><a href='000057480.php'>MAGGI ., GUIDO EUGENIO MARIO</td> <td>ITALIA</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>235</td> <td align='left'><a href='06217919.php'>MAGUIÑA MENDOZA, MARIO ARTURO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>236</td> <td align='left'><a href='08740729.php'>MANRIQUE PINO, OSCAR</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>237</td> <td align='left'><a href='25620629.php'>MARQUINA MAUNY, WILFREDO JAVIER</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>238</td> <td align='left'><a href='43272586.php'>MAS CARO, NIXON LUIS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>239</td> <td align='left'><a href='25739572.php'>MASCELLARO LUPERDI, GIANCARLO ENZO PASCQUALE</td> <td>ITALIA</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>240</td> <td align='left'><a href='09607876.php'>MASGO LARA, LUIS ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>241</td> <td align='left'><a href='09697998.php'>MATHEUS ROMERO, JORGE HERNANDO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Parcial</td> </tr>
<tr><td>242</td> <td align='left'><a href='10613109.php'>MATTA SANTIVAÑEZ, KARINA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>243</td> <td align='left'><a href='40935708.php'>MAZA CHUMPITAZ, ANGELA GIOVANA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>244</td> <td align='left'><a href='32983656.php'>MEDINA INFANTE, MAGALY BETZABE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>245</td> <td align='left'><a href='40517760.php'>MEDINA PEREZ, MARIA YOVANI</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>246</td> <td align='left'><a href='25791096.php'>MEDINA SIRLOPU, MARTHA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>247</td> <td align='left'><a href='25634361.php'>MELGAREJO SALAZAR, MARGARITA GLADYS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>248</td> <td align='left'><a href='23978854.php'>MENDOZA CABALLERO, WILFREDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>249</td> <td align='left'><a href='08308467.php'>MENDOZA NAVARRO, AIDA LUZ</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>250</td> <td align='left'><a href='10246770.php'>MENENDEZ MUERAS, ROSA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>251</td> <td align='left'><a href='01051153.php'>MERA NAVAL, HUGO JAIME</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>252</td> <td align='left'><a href='07969037.php'>MERINO ZEVALLOS, CARLOS ANTONIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>253</td> <td align='left'><a href='23842285.php'>MESTAS VALERO, ROGER MANUEL</td> <td>BRASIL</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>254</td> <td align='left'><a href='00838777.php'>MINGA SARMIENTO, ROLANDO NOLVERTHY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>255</td> <td align='left'><a href='25697416.php'>MITTA CURAY, EVER RAMIRO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>256</td> <td align='left'><a href='40894989.php'>MOISES GONZALES, NORMA ROCIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>257</td> <td align='left'><a href='03688780.php'>MONDRAGON LIMA, MARITZA ELIZABETH</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>258</td> <td align='left'><a href='10271073.php'>MONTERROSO CORONADO, CESAR ANTONIO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>259</td> <td align='left'><a href='08633219.php'>MONTES VILLANUEVA, NILDA DORIS</td> <td>BRASIL</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>260</td> <td align='left'><a href='09994755.php'>MONTOYA SALDAÑA, SILVIA MARIANA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>261</td> <td align='left'><a href='02841777.php'>MONTOYA TEJADA, WILSON EDUARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>262</td> <td align='left'><a href='21521372.php'>MOQUILLAZA CASTILLA, JORGE LUIS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>263</td> <td align='left'><a href='16717938.php'>MORA CUMPA, LUIS ENRIQUE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>264</td> <td align='left'><a href='42007303.php'>MORALES ROJAS, WILLIAM ANTONY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>265</td> <td align='left'><a href='40064308.php'>MORALES VASQUEZ, CESAR ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>266</td> <td align='left'><a href='08500743.php'>MORENO CUEVA, MAXIMO ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>267</td> <td align='left'><a href='21133559.php'>MORENO PALOMINO, JEAN PAUL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>268</td> <td align='left'><a href='19870721.php'>MUCHA MONTOYA, RUTH HAYDEE</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>269</td> <td align='left'><a href='20662522.php'>MUNIVE JAUREGUI, HONORIO ELOY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>270</td> <td align='left'><a href='23851049.php'>MUÑIZ PAUCARMAYTA, ABEL ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>271</td> <td align='left'><a href='08269783.php'>MUÑOZ MARTICORENA, WILLIAM AMADEO</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>272</td> <td align='left'><a href='15761830.php'>MUÑOZ QUICHIZ, JAVIER ANGEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>273</td> <td align='left'><a href='09738114.php'>MUÑOZ TORRE, HERLINDA MARLENI</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>274</td> <td align='left'><a href='10230085.php'>MURILLO PONTE, RICARDO VICTOR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>275</td> <td align='left'><a href='09593605.php'>NAUPARI CASTILLO, HEROINA DINA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>276</td> <td align='left'><a href='06145294.php'>NAVARRO GUERRERO, TITO RICARDO</td> <td>CHILE</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>277</td> <td align='left'><a href='41438407.php'>NAVARRO LINARES, JANINA DEL ROCIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>278</td> <td align='left'><a href='07517476.php'>NAVARRO MONTEAGUDO, CARMEN CECILIA</td> <td>ITALIA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>279</td> <td align='left'><a href='07626510.php'>NAVARRO VILCHEZ, IGOR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>280</td> <td align='left'><a href='09952010.php'>NEYRA DE LA ROSA, LUIS</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>281</td> <td align='left'><a href='09936559.php'>NEYRA DE LA ROSA, NILDRE GERALDINE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>282</td> <td align='left'><a href='06902484.php'>NOLAZCO VICENTE, LUIS ARTURO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>283</td> <td align='left'><a href='09377701.php'>NUÑEZ MANRIQUE, ANA MARIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>284</td> <td align='left'><a href='08820367.php'>NUÑEZ SOTO, LUIS GUILLERMO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>285</td> <td align='left'><a href='41110999.php'>OLIVA NAVARRO, JORGE ALEJANDRO</td> <td>ITALIA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>286</td> <td align='left'><a href='07729635.php'>OLIVARES LLONA, EDUARDO EDMUNDO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>287</td> <td align='left'><a href='08763051.php'>ORE RIVAS, RAUL JAVIER</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>288</td> <td align='left'><a href='08095469.php'>ORTIZ DUCLOS, JUAN CARLOS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>289</td> <td align='left'><a href='08801690.php'>OTSU NAVARRETE, GRACIELA RAQUEL</td> <td>ITALIA</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>290</td> <td align='left'><a href='41670439.php'>OVALLE FERNANDEZ, ALEXIS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>291</td> <td align='left'><a href='41786787.php'>PACAYA DIAZ, DARINKA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>292</td> <td align='left'><a href='000080198.php'>PACCOSI ., GIOVANNI</td> <td>ITALIA</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>293</td> <td align='left'><a href='06851633.php'>PACCOTAIPE ESPINOZA, SALOME</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>294</td> <td align='left'><a href='15760945.php'>PACIFICO SOTO, CARLOS DELFIN</td> <td>ARGENTINA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>295</td> <td align='left'><a href='32543302.php'>PALACIOS FARFAN, PEDRO MIGUEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>296</td> <td align='left'><a href='03376528.php'>PALOMINO VALDEZ, MARIA ISABEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>297</td> <td align='left'><a href='40010019.php'>PANIZZA RICHERO, LINO MARIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>298</td> <td align='left'><a href='15859960.php'>PAREDES AGUIRRE, FREDY ROMAN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>299</td> <td align='left'><a href='08677518.php'>PAREDES SERRANO, MARIA SALOME</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>300</td> <td align='left'><a href='07735674.php'>PAREJA FERNANDEZ, ANA CECILIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>301</td> <td align='left'><a href='40511186.php'>PASCUAL MENDOZA, EDISSON PEDRO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>302</td> <td align='left'><a href='000812857.php'>PASTEN MONARDEZ, JUAN IGNACIO</td> <td>CHILE</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>303</td> <td align='left'><a href='42750570.php'>PASTRANA BANDAN, JESSICA MIRIAM</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>304</td> <td align='left'><a href='21814639.php'>PECEROS ARIAS, IRMA ROXANA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>305</td> <td align='left'><a href='10144128.php'>PERALTA VERA, JUAN CARLOS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>306</td> <td align='left'><a href='41925884.php'>PERALTA VILLANUEVA, JENNY MAGALY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>307</td> <td align='left'><a href='08661070.php'>PEREYRA ROMERO, FLOR DE MARIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>308</td> <td align='left'><a href='09843721.php'>PEREZ ESTRELLA, EPIFANIA EULOGIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>309</td> <td align='left'><a href='08805048.php'>PEREZ FERNANDEZ, JOSE HIGINIO</td> <td>PERÚ</td> <td>Ordinario Principal</td> <td>Tiempo Completo</td> </tr>
<tr><td>310</td> <td align='left'><a href='40292729.php'>PEREZ PEREZ, ITALA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>311</td> <td align='left'><a href='25777787.php'>PEREZ RODRIGUEZ, RUTH EVELY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>312</td> <td align='left'><a href='01323959.php'>PINAZO HERENCIA, RENE ALFREDO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>313</td> <td align='left'><a href='07119662.php'>PINEDA LEON, ROBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>314</td> <td align='left'><a href='01152072.php'>PINEDO CANTA, JUAN JOSE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>315</td> <td align='left'><a href='21564297.php'>PINEDO FERNANDEZ, MARINA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>316</td> <td align='left'><a href='07671136.php'>PINTO TORPOCO, ALBERTO DONALD</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>317</td> <td align='left'><a href='21086869.php'>PIZARRO PUENTE, ARTURO LEONEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>318</td> <td align='left'><a href='09435661.php'>POLO PUELLES, JOSE MARTIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>319</td> <td align='left'><a href='08268827.php'>PONCE VEGA, LUIS ALBERTO</td> <td>ESTADOS UNIDOS</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>320</td> <td align='left'><a href='05295151.php'>POQUIOMA RODRIGUEZ, ANGEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>321</td> <td align='left'><a href='44081022.php'>PORRAS CARDENAS, OSCAR DANIEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>322</td> <td align='left'><a href='25478348.php'>POZO CCASANI, ZOSIMO REGULO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>323</td> <td align='left'><a href='08460860.php'>PRIVAT MARAVI, LUZ MERCEDES</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>324</td> <td align='left'><a href='09451560.php'>PUERTAS PORRAS, MARIA ELIZABETH</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>325</td> <td align='left'><a href='08070278.php'>QUEVEDO DIOSES, VICTOR ENRIQUE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>326</td> <td align='left'><a href='10342134.php'>QUEZADA MURGA, DANIEL</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>327</td> <td align='left'><a href='06650975.php'>QUINTEROS CAMACHO, NORMA LUZ</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>328</td> <td align='left'><a href='33240483.php'>QUIÑONES CORDOVA, BIDELMINA MARUJA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>329</td> <td align='left'><a href='08703120.php'>QUIROZ AVILES, LUIS NAPOLEON</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>330</td> <td align='left'><a href='10183687.php'>RAMIREZ ARELLANO, MIGUEL ANGEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>331</td> <td align='left'><a href='40053375.php'>RAMOS NIÑO NEIRA, ANA MARIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>332</td> <td align='left'><a href='44380747.php'>RAMOS PEREZ, ERICK WILLIAMS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>333</td> <td align='left'><a href='43437043.php'>RAMOS ROMERO, MIGUEL FERNANDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>334</td> <td align='left'><a href='09739932.php'>RAMOS TORREJON, REYNA TEODOSIA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Parcial</td> </tr>
<tr><td>335</td> <td align='left'><a href='15678673.php'>RESPICIO LOPEZ, LUIS ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>336</td> <td align='left'><a href='08528049.php'>RIOS CUELLAR, HUMBERTO MOISES</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>337</td> <td align='left'><a href='09799606.php'>RIOS MANRIQUE, ELVIS ROLDAN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>338</td> <td align='left'><a href='09994223.php'>RIOS VARGAS, JORGE MARCELL</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>339</td> <td align='left'><a href='17896043.php'>RIVERA CALLE, HUMBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>340</td> <td align='left'><a href='06613176.php'>RIVERA ROMERO, DAVID SOSIMO</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>341</td> <td align='left'><a href='41729686.php'>RODAS MARTINEZ, RICARDO SALOMON</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>342</td> <td align='left'><a href='10236949.php'>RODRIGUEZ ALVITES, ALINA PATRICIA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Parcial</td> </tr>
<tr><td>343</td> <td align='left'><a href='10551660.php'>RODRIGUEZ CASTILLO, EDITH</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>344</td> <td align='left'><a href='06801095.php'>RODRIGUEZ ENCALADA, JOSE ALEJANDRO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Parcial</td> </tr>
<tr><td>345</td> <td align='left'><a href='18222946.php'>RODRIGUEZ ESPINOZA, RONALD FERNANDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>346</td> <td align='left'><a href='07821253.php'>RODRIGUEZ ITURRI, ROGER RAFAEL ESTANISLAO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>347</td> <td align='left'><a href='15739966.php'>RODRIGUEZ NUÑEZ, JOSE LUIS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>348</td> <td align='left'><a href='31652355.php'>RODRIGUEZ PEREZ, LUIS EDUARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>349</td> <td align='left'><a href='02808952.php'>RODRIGUEZ SANDOVAL, JOSE MARTIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>350</td> <td align='left'><a href='10725778.php'>ROJAS ARAMBURU, MAGALLY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>351</td> <td align='left'><a href='00821693.php'>ROJAS YGLESIAS, EDUARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>352</td> <td align='left'><a href='40949739.php'>ROMERO LEYTON, CLAUDIA LISSETH</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>353</td> <td align='left'><a href='07522448.php'>ROSALES PACHECO, ALDO HORACIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>354</td> <td align='left'><a href='25655141.php'>RUBIO APONTE, JULIO CESAR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>355</td> <td align='left'><a href='03367079.php'>RUIDIAS JUAREZ, MARINA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>356</td> <td align='left'><a href='10150044.php'>RUIZ CCANCCE, JOSE VICTOR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>357</td> <td align='left'><a href='03376948.php'>RUIZ ESPINOZA, DORIS VIOLETA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>358</td> <td align='left'><a href='09729256.php'>RUIZ JANGE, BERTHA MARCELINA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>359</td> <td align='left'><a href='06960251.php'>RUIZ JANJE, ALEJANDRO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>360</td> <td align='left'><a href='40661636.php'>RUIZ RAFAEL, JORGE LUIS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>361</td> <td align='left'><a href='25809384.php'>RUIZ RUIZ, GUADALUPE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>362</td> <td align='left'><a href='00818283.php'>RUIZ VALLES, RUBEN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>363</td> <td align='left'><a href='08363244.php'>SAAVEDRA CHIU, ROXANA MARGARITA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>364</td> <td align='left'><a href='42915862.php'>SAAVEDRA MUÑOZ, NESTOR</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>365</td> <td align='left'><a href='15609778.php'>SALAS RAMIREZ, CARLOS MANUEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>366</td> <td align='left'><a href='08195765.php'>SALAZAR RIOS, ROBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>367</td> <td align='left'><a href='26952199.php'>SANCHEZ ACOSTA, JUAN SANTIAGO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>368</td> <td align='left'><a href='08203119.php'>SANCHEZ ARAUJO, JUAN BAUTISTA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>369</td> <td align='left'><a href='42135945.php'>SANCHEZ DIAZ, JHON</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>370</td> <td align='left'><a href='10352458.php'>SANCHEZ SEGOVIA, KARLA ROCCIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>371</td> <td align='left'><a href='40484791.php'>SANCHEZ TORRES, HEIDI ISABEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>372</td> <td align='left'><a href='09273004.php'>SANCHEZ VILCARINO, JORGE DEMETRIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>373</td> <td align='left'><a href='08181918.php'>SANDOVAL LOZANO, GIOVANI</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>374</td> <td align='left'><a href='08180998.php'>SANDOVAL LOZANO, SERGIO ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>375</td> <td align='left'><a href='08031444.php'>SEMINARIO OLORTIGUE, PABLO HUGO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>376</td> <td align='left'><a href='08017508.php'>SEMINARIO OLORTIGUE, RAUL MARTIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>377</td> <td align='left'><a href='001242418.php'>SFREGOLA ., CARMELA</td> <td>ITALIA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>378</td> <td align='left'><a href='42258333.php'>SICCHA VALDERRAMA, TERESA MILAGROS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>379</td> <td align='left'><a href='07936807.php'>SIDIA CARRASCO, MIGUEL JOSE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>380</td> <td align='left'><a href='08229291.php'>SOLARI DE LA FUENTE, LUIS MARIA SANTIAGO EDUAR</td> <td>PERÚ</td> <td>Ordinario Principal</td> <td>Dedicacion Exclusiva</td> </tr>
<tr><td>381</td> <td align='left'><a href='26601922.php'>SOLIS CESPEDES, PEDRO ANIBAL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>382</td> <td align='left'><a href='09452164.php'>SOTO CANALES, PEDRO PASCUAL</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>383</td> <td align='left'><a href='40536407.php'>SOTO CCOICCA, KAROL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>384</td> <td align='left'><a href='29538510.php'>SOTO COCHON, CARLINA ROXANA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>385</td> <td align='left'><a href='21076557.php'>SOTO PORRAS, JESUS GERARDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>386</td> <td align='left'><a href='09886713.php'>SUELDO VEGA, GREMY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>387</td> <td align='left'><a href='09978369.php'>TACUNAN BONIFACIO, SANTIAGO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>388</td> <td align='left'><a href='09732261.php'>TAIPE AYLAS, MARIA DEL CARMEN</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Parcial</td> </tr>
<tr><td>389</td> <td align='left'><a href='09363458.php'>TAPIA NUÑEZ, LOURDES CECILIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>390</td> <td align='left'><a href='45829609.php'>TARRILLO VILLEGAS, ANA MARIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>391</td> <td align='left'><a href='43252024.php'>TEJADA FARFAN, ANDREA GIULIANA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>392</td> <td align='left'><a href='07757302.php'>TEJADA RIVAS, ROBERTO ANTONIO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>393</td> <td align='left'><a href='10177764.php'>TELLO BENITES, JESSICA VICTORIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>394</td> <td align='left'><a href='06282789.php'>TELLO MARZOL, JACQUELINE ANGELICA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>395</td> <td align='left'><a href='15605059.php'>TELLO PANDAL, NILO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>396</td> <td align='left'><a href='07585542.php'>TENORIO MENDEZ, WALTER ORLANDO</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>397</td> <td align='left'><a href='21082550.php'>TIRADO PUCUHUAYLA, JUAN ANTONIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>398</td> <td align='left'><a href='09639466.php'>TOLENTINO ZAPATA, JUAN MANUEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>399</td> <td align='left'><a href='07786573.php'>TORO DEXTRE, ELISEO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>400</td> <td align='left'><a href='42824306.php'>TREJO SARE, JENNY EVELYN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>401</td> <td align='left'><a href='10140056.php'>TRUJILLO CHAVEZ, DELSY MARIELA</td> <td>ALEMANIA</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>402</td> <td align='left'><a href='03568079.php'>TUME CHINCHAY, LUIS FELIPE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>403</td> <td align='left'><a href='03494013.php'>TUME RUIZ, JUAN MANUEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>404</td> <td align='left'><a href='02860918.php'>UBILLUS SILVA, RUBEN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>405</td> <td align='left'><a href='17970143.php'>UCAÑAN LEYTON, ROGER EUGENIO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>406</td> <td align='left'><a href='08600005.php'>URBANO CHAVEZ, ANGELICA EULALIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>407</td> <td align='left'><a href='10272670.php'>URIBE PORRAS, CARLOS ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>408</td> <td align='left'><a href='21796501.php'>VALDIVIA ARENAS, CARMEN ROSA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>409</td> <td align='left'><a href='07424538.php'>VALDIVIA TORRES, AUGUSTO GILTTER</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>410</td> <td align='left'><a href='09223783.php'>VALDIVIA ZUÑIGA, MARIBEL EMILIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>411</td> <td align='left'><a href='01046752.php'>VARGAS ROJAS, JUAN ORLANDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>412</td> <td align='left'><a href='00129361.php'>VASQUEZ BALAREZO, JOVITA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>413</td> <td align='left'><a href='40348999.php'>VASQUEZ CASTAÑEDA, MARIA LUISA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>414</td> <td align='left'><a href='16562688.php'>VASQUEZ MEDINA, PEDRO JAMES</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>415</td> <td align='left'><a href='09442181.php'>VASSALLO FERNANDEZ, LUIGI EDGARDO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>416</td> <td align='left'><a href='08607374.php'>VEGA BALDEON, AGUSTIN HEBERT</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>417</td> <td align='left'><a href='10684755.php'>VEJARANO INGAR, MANUEL JESUS</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>418</td> <td align='left'><a href='07238797.php'>VELARDE FLORES, RUBEN ANTONIO</td> <td>ITALIA</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>419</td> <td align='left'><a href='42071960.php'>VELASQUEZ ESPINOZA, MONICA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>420</td> <td align='left'><a href='08172294.php'>VELASQUEZ RODRIGUEZ, NORMA CONSTANZA</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>421</td> <td align='left'><a href='10400322.php'>VELASQUEZ ROSAS DE CUTIMBO, JULIA GLADYS</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>422</td> <td align='left'><a href='40715884.php'>VELIZ PAREDES, GUILLERMO RENZO</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>423</td> <td align='left'><a href='41283752.php'>VENEGAS CAMPOS, MIRIAM ISABEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>424</td> <td align='left'><a href='08725896.php'>VERGARA PALACIOS, GLADYS ELIDA</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Parcial</td> </tr>
<tr><td>425</td> <td align='left'><a href='10777769.php'>VERGARA TRUJILLO, JULIO DOUGLAS</td> <td>ITALIA</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>426</td> <td align='left'><a href='07503079.php'>VICUÑA ORIHUELA, CARMELA EMPERATRIZ</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>427</td> <td align='left'><a href='06240042.php'>VIDAL ROJAS, MARIANELLA IVY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>428</td> <td align='left'><a href='06663188.php'>VILCA DELGADO, WILLIAMS SHANE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>429</td> <td align='left'><a href='10796076.php'>VILCAPUMA VINCES, PATRICIA BERNARDA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>430</td> <td align='left'><a href='03383213.php'>VILCHERREZ VILELA, DARWIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>431</td> <td align='left'><a href='08459715.php'>VILLA MOROCHO, CESAR AUGUSTO</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>432</td> <td align='left'><a href='07942626.php'>VILLACORTA BERTOLOTTO, LUIS FERNANDO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>433</td> <td align='left'><a href='25609588.php'>VILLACORTA SANTAMATO, LUIS ANDRES</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>434</td> <td align='left'><a href='80543304.php'>VILLALOBOS VILLEGAS, WILTON</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>435</td> <td align='left'><a href='46606605.php'>VILLANUEVA HUAMAN, FRANCISCO MIGUEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>436</td> <td align='left'><a href='40971221.php'>VILLEGAS FERNANDEZ, YURY JOSELINA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>437</td> <td align='left'><a href='000923632.php'>VOTO ., CARMINE</td> <td>ITALIA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>438</td> <td align='left'><a href='41707058.php'>YAFAC CASTILLO, CARLA VALERIE</td> <td>ITALIA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>439</td> <td align='left'><a href='09962770.php'>YARLEQUE VILCHEZ, LUIS ENRIQUE</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>440</td> <td align='left'><a href='09971583.php'>YARLEQUE VILCHEZ, NORMA MARIBEL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>441</td> <td align='left'><a href='06058263.php'>YASUDA GOICOCHEA, WALTER EDWIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>442</td> <td align='left'><a href='06148522.php'>YSEKI SALAZAR, SANDRA PATRICIA</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>443</td> <td align='left'><a href='10265508.php'>ZAMBRANO ANGULO, VICTOR HUGO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>444</td> <td align='left'><a href='06164675.php'>ZAMBRANO GOICOCHEA, JUAN ANTONIO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>445</td> <td align='left'><a href='40051853.php'>ZANETTI GRANDEZ, NICOLAS ALBERTO MARTIN</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>446</td> <td align='left'><a href='16727294.php'>ZAPATA CORRALES, FELIX ALBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>447</td> <td align='left'><a href='32102213.php'>ZAPATA ROQUE, JOSE CARLOS</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>448</td> <td align='left'><a href='41301023.php'>ZARATE AGUILAR, KARIN BELINDA</td> <td>ITALIA</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>449</td> <td align='left'><a href='08098554.php'>ZARATE HERMOZA, JESUS ROBERTO</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
<tr><td>450</td> <td align='left'><a href='09533788.php'>ZARATE ROMAN, MARISA CONSUELO</td> <td>PERÚ</td> <td>Ordinario Asociado</td> <td>Tiempo Completo</td> </tr>
<tr><td>451</td> <td align='left'><a href='10650280.php'>ZAVALETA ARTEAGA, MAGALI KATTY</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Completo</td> </tr>
<tr><td>452</td> <td align='left'><a href='06118755.php'>ZEVALLOS DE LAS CASAS, LUISA INES</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Completo</td> </tr>
<tr><td>453</td> <td align='left'><a href='41340477.php'>ZUÑIGA ALVARADO DE LA ROSA, NELIZA KELI</td> <td>PERÚ</td> <td>Ordinario Auxiliar</td> <td>Tiempo Parcial</td> </tr>
<tr><td>454</td> <td align='left'><a href='05343430.php'>ZUÑIGA EURIBE, ARTURO PAUL</td> <td>PERÚ</td> <td>Contratado</td> <td>Tiempo Parcial</td> </tr>
</tbody>
</table>
</body>
</html>
