<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MEDINA SIRLOPU, MARTHA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Derecho Corporativo: Planeamiento Corporativo y Desarrollo Jurídico Empresarial por la Universidad de San Martín de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Derecho de Familia por la Universidad Peruana Cayetano Heredia, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría con mención en Derecho Civil por la Universidad Inca Garcilaso de la Vega, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente Universitaria de la asignatura de Derecho Empresarial, Derecho Laboral, Derecho empresarial en la Universidad Privada del Norte</th></tr>
<tr><th class = 'der' align='left'>Responsable del área de derecho de la Facultad de Ciencias Económicas y Comerciales de la Universidad Católica Sedes Sapientiae, dentro de las labores que desarrollo son elaboración de sílabos, separatas, tutoría de los cursos de derecho para los alu</th></tr>
<tr><th class = 'der' align='left'>Docente Universitaria de las asignaturas de: Introducción al Derecho, Derecho Laboral,  Derecho Comercial, Relaciones Laborales, Derecho Tributario, Racionalización Administrativa  en la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Docente en CIBERTEC,  coordinadora de los cursos de Introducción al Derecho  (2014-2) y Legislación e Inserción Laboral ( virtual ) 2014-2</th></tr>
<tr><th class = 'der' align='left'>Docente Universitaria  del Diplomado en Tributación en el curso de Aspectos Generales de la Tributación en el Perú y Análisis del Código Tributario en el área de Posgrado de la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Asistente de Cátedra de las asignaturas de: Formación Profesional y Práctica de Derecho Procesal Civil en la Universidad San Martin de Porres.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
