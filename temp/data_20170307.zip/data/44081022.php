<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>PORRAS CARDENAS, OSCAR DANIEL</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias Zootecnia por la Universidad Nacional Agraria La Molina, Perú.</th></tr>
<tr><th class='der' align='left'>Título: Ingeniero Zootecnista por la Universidad Nacional Agraria La Molina, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Formación Básica de Facilitadores en Metodología CEFE por la Universidad San Martin de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Planificación de Proyectos de Desarrollo Rural y Gestión Ambiental  por la Universidad Politécnica de Madrid, España.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Coordinador Académico de la Facultad de Ingeniería Agraria  Nueva Cajamarca. Universidad Católica Sedes Sapientiae. San Martín. Perú.( 2015 a la fecha)</th></tr>
<tr><th class = 'der' align='left'>Coordinador de Campo, Proyecto Productivo Agropecuario. Facultad de Ingeniería Agraria. Universidad Católica Sedes Sapientiae. Cusco. Perú (2013  2014 )</th></tr>
<tr><th class = 'der' align='left'>Gestor de Proyectos. Facultad de zootecnia. Universidad Nacional Agraria La Molina. Perú. (2010  2013)</th></tr>
<tr><th class = 'der' align='left'>Elaboración de planes de negocios y estudios de pre factibilidad en Ayacucho. Coordinador de proyectos ganaderos en Junín y San Martín. (2010  2013)</th></tr>
<tr><th class = 'der' align='left'>Administrador de Granja. Granja de Ovinos y Camélidos Rigoberto Calle Escobar. Universidad Nacional Agraria La Molina. Perú. (2009  2010)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
