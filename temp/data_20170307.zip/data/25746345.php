<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>BIO GAIDOLFI, FAUSTO MICHELE</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias Administrativas, por la Facultad de Ciencias Administrativas de la Universidad de Lima (1990-1995).</th></tr>
<tr><th class='der' align='left'>Licenciado en Administración de Empresas por la Escuela de Negocios de la Universidad de Lima, con la calificación máxima (sobresaliente)  noviembre 2015.</th></tr>
<tr><th class='der' align='left'>Primer Puesto del MBA Internacional con especialización en Finanzas por la Universidad Católica Sedes Sapientiae (UCSS)  Año 2016.</th></tr>
<tr><th class='der' align='left'>Primer Puesto del Máster en Administración Pública, por la Universidad Católica Sedes Sapientiae (UCSS)  Año 2012</th></tr>
<tr><th class='der' align='left'>Primer Puesto del Máster en Public Governance (Gobernabilidad), por la Universidad del Sacro Cuore di Milano (Italia)  Año 2011.</th></tr>
<tr><th class='der' align='left'>Primer Puesto del Postgrado en Técnica Arbitral, por la Universidad San Martín de Porres (USMP)  Año 2010.</th></tr>
<tr><th class='der' align='left'>Primer Puesto del Postgrado en Contrataciones Estatales, por la Universidad Católica Sedes Sapientiae  Año 2009.</th></tr>
<tr><th class='der' align='left'>Segundo Puesto del Postgrado en Gestión Pública y Desarrollo Económico Local, por la Universidad Católica Sedes Sapientiae (UCSS)  Año 2008.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Jefe de la Oficina de Administración de SIMA IQUITOS SRLTDA. (Febrero del 2006 a Octubre del 2007)</th></tr>
<tr><th class = 'der' align='left'>trabajo en la Oficina de Supervisión de Contratos, encargada de la supervisión integral de los proyectos ejecutados por SIMA  PERU S.A (noviembre del 2009)</th></tr>
<tr><th class = 'der' align='left'>Gerencia del Proyecto Puente PACHITEA, proyecto de infraestructura vial que se convierte en el puente más grande fabricado en el Perú. (febrero del 2015)</th></tr>
<tr><th class = 'der' align='left'>Participación en la gerencia  para los siguientes proyectos: Puente Raymondi (La Libertad-Cajamarca-Ancash),Puente Mantaro (Junín),Construcción del Buque Escuela a Vela Unión          para la Marina de Guerra del Perú, Puente Ocopa (Junín) ,Puente</th></tr>
<tr><th class = 'der' align='left'>Construcción de Remolcadores y Atuneros para Perú, Chile, Panamá, Colombia, México, Corea. etc.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
