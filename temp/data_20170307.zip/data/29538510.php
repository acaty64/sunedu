<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>SOTO COCHON, CARLINA ROXANA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciada en Nutrición Humana por la Universidad Nacional San Agustín (UNSA)</th></tr>
<tr><th class='der' align='left'>Maestría de Gestión y Docencia en Alimentación y Nutrición por la Universidad Peruana de Ciencias Aplicadas (UPC)</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Encargada de brindar atención, intervención y seguimiento nutricional con la finalidad de optimizar la salud de los pacientes hospitalizados a través de la terapia nutricional temprana y oportuna en las diferentes patologías.</th></tr>
<tr><th class = 'der' align='left'>Jefa del Servicio de Nutrición del Hospital II-Pucallpa.</th></tr>
<tr><th class = 'der' align='left'>Tutora de Internado Clínico de la Carrera de Nutrición y Dietética; Docente de Prácticas Clínicas de Dietoterapia del Adulto; Docente de Prácticas Clínicas de Soporte Nutricional Farmacológico Universidad Peruana de Ciencias Aplicadas  UPC Cargo:</th></tr>
<tr><th class = 'der' align='left'>Docente del Curso de Fisiopatología y Dietoterapia del Niño; Docente del Curso de Soporte Nutricional Farmacológico Universidad Católica Sedes Sapientiae UCSS Cargo:</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
