<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MONTES VILLANUEVA, NILDA DORIS</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Estadística por la Facultad de Ciencias Matemáticas de la Universidad Nacional Mayor de San Marcos, Lima - Perú.</th></tr>
<tr><th class='der' align='left'>Magíster en Estadística por el Instituto de Matemática, Estadística y Computación Científica de la Universidad Estadual de Campinas (IMECC-UNICAMP), Sao Paulo - Brasil.</th></tr>
<tr><th class='der' align='left'>Doctora en Alimentos y Nutrición, Sub-área Consumo y Calidad, por la Facultad de Ingeniería de Alimentos de la Universidad Estadual de Campinas (FEA-UNICAMP), Sao Paulo - Brasil.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Asesora estadística de proyectos de investigación del Instituto de Tecnología de Alimentos (ITAL), Campinas- Sao Paulo, Brasil.</th></tr>
<tr><th class = 'der' align='left'>Docente a tiempo parcial en la Unidad de Postgrado del Dpto. de Alimentos de la Facultad de Ciencias Farmacéuticas de la Universidad de Sao Paulo, Brasil.</th></tr>
<tr><th class = 'der' align='left'>Docente a tiempo parcial en el programa de maestría en Ciencias en Gerencia de Empresas Agropecuarias y Pesqueras de la Universidad Nacional del Santa- UNS.</th></tr>
<tr><th class = 'der' align='left'>Docente de cursos online de la Académie Accor Brasil.</th></tr>
<tr><th class = 'der' align='left'>Docente e Investigadora Principal a tiempo completo en CENTRUM Católica, Centro de Negocios de la Pontificia Universidad Católica del Perú.</th></tr>
<tr><th class = 'der' align='left'>Docente y tutora de Diplomados en Formulación de Proyectos de Inversión Pública con Enfoque de Desarrollo Humano e Infancia y del Programa de especialización en Planeamiento Estratégico, Programación y Ejecución Presupuestal de la Pontificia Universi</th></tr>
<tr><th class = 'der' align='left'>Docente a tiempo completo de la Facultad de Ingeniería Agraria. Universidad Católica Sedes Sapientiae. Lima. Perú.</th></tr>
<tr><th class = 'der' align='left'>Directora de Investigación de la Facultad de Ingeniería Agraria. Universidad Católica Sedes Sapientiae. Lima. Perú.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
