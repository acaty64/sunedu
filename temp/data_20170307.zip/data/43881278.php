<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ALBARRAN MEDINA, ELVIA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Economista  por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado en Formulación y Evaluación de Proyectos de Inversión Pública SNIP por la Universidad ESAN, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Gerencia Social por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Especialista de la oficina de Proyectos de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Asistente del área interna del Observatorio para el Desarrollo Territorial (ODT) de la Universidad Católica Sedes Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
