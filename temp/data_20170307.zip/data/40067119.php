<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>BURGOS BASTIDAS, ANGIE ROMY</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bióloga. Universidad Nacional Federico Villarreal. Perú</th></tr>
<tr><th class='der' align='left'>Magister en Scientiae Ecología Aplicada por la Universidad Nacional Agraria La Molina.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de la carrera de Ingeniería Ambiental. Facultad de Ingeniería Agraria. Universidad Católica Sedes Sapientiae. Lima. Perú</th></tr>
<tr><th class = 'der' align='left'>Consultora Ambiental. Monitoreos Biológicos y elaboración de informes técnicos en proyectos de energía limpia. Consultora Pacific PIR. Lima. Perú</th></tr>
<tr><th class = 'der' align='left'>Investigadora y tesista del Centro Internacional de la Papa. Area de Entomología. CIP  Lima, Perú.</th></tr>
<tr><th class = 'der' align='left'>Investigadora del Proyecto Red de Polinizadores del Perú. Proyecto ejecutado con la Inter American Biodiversity Information Network (IABIN) y la Organización de Estados Americanos (OEA).</th></tr>
<tr><th class = 'der' align='left'>Consultora Ambiental.  Trabajo de campo y gabinete. Programa de Monitoreo de Biodiversidad Entomológica en Camisea (Cusco). Perú.</th></tr>
<tr><th class = 'der' align='left'>Docente de la Carrera de Ingeniería Ambiental de la Universidad Católica Sedes Sapientiae. Perú.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
