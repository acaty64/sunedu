<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CRUZ ACUÑA, EDGAR ODON</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>BACHILLER en Sagrada Teología  por la  Facultad de Teología Pontificia y Civil de Lima.</th></tr>
<tr><th class='der' align='left'>LICENCIADO en Sagrada Teología por la  Facultad de Teología Pontificia y Civil de Lima.</th></tr>
<tr><th class='der' align='left'>MAGISTER en Sagrada Teología por la  Facultad de Teología Pontificia y Civil de Lima.</th></tr>
<tr><th class='der' align='left'>BACHILLER en Derecho por la  Pontificia Universidad Católica del Perú.</th></tr>
<tr><th class='der' align='left'>TITULO de Abogado por la  Pontificia Universidad Católica del Perú.</th></tr>
<tr><th class='der' align='left'>EGRESADO de la Maestría en Filosofía   por la  Pontificia Universidad Católica del Perú</th></tr>
<tr><th class='der' align='left'>Estudiante de la Maestría en Bioética y Bioderecho por  la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Secretario Académico de la Facultad de Derecho  en la  Universidad Católica Sedes Sapientiae (2015 a la fecha)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario  en la Universidad Católica Sedes Sapientiae (2004 a la fecha)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario en la  Pontificia Universidad Católica del Perú. (1996,1998, 2008,2012).</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario en la Facultad de Teología Pontificia y Civil de Lima (2002)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario en la  Universidad Marcelino Champagnat (2005-2011)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario en la  Universidad Femenina del Sagrado Corazón.(2010-2015)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario en el ESTUDIANTADO FILOSOFICO TEOLOGICO MARELLIANUM</th></tr>
<tr><th class = 'der' align='left'>(2006-2010)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
