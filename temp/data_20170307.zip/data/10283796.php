<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ARASHIRO TAMASHIRO, ANA CECILIA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Magister en Administración de Negocios y Finanzas Internacionales - MBA Internacional por la Universidad Católica Sedes Sapientiae, Perú</th></tr>
<tr><th class='der' align='left'>Master en Gestión Estratégica, Finanzas e Internacionalización de Empresas por la Universitá Degli Studi di Genova, Italia.</th></tr>
<tr><th class='der' align='left'>Título Profesional de Contador Público por la Universidad de Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias Contables por la Universidad de Lima, Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente ordinario de la Facultad de Ciencias Económicas y Comerciales en la cátedra de Contabilidad Básica I. Categoría asociado. Universidad Católica Sedes Sapientiae. (Dic/2011  Actualidad )</th></tr>
<tr><th class = 'der' align='left'>Jefe de Departamento Académico de la Facultad de Ciencias Económicas y Comerciales. Universidad Católica Sedes Sapientiae. (Nov/2006  Actualidad )</th></tr>
<tr><th class = 'der' align='left'>Docente ordinario de la Facultad de Ciencias Económicas y Comerciales en la cátedra de Contabilidad Básica I. Categoría auxiliar. Universidad Católica Sedes Sapientiae.( Ago /2004  Nov/2011)</th></tr>
<tr><th class = 'der' align='left'>Directora Ejecutiva. Centro de Apoyo al Sector Empresarial de la Universidad Católica Sedes Sapientiae (Jul/2003 - Set/2006)</th></tr>
<tr><th class = 'der' align='left'>Responsable del Departamento de Economía y Asuntos Administrativos. Universidad Católica Sedes Sapientiae. (Feb/2000 - Jun/2003).</th></tr>
<tr><th class = 'der' align='left'>Contadora de afiliadas encargadas del negocio inmobiliario del grupo. COSAPI ORGANIZACION EMPRESARIAL S.A.( Marzo /1996  Set/1999)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
