<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>LAURENCIO LUNA, MANUEL ISMAEL</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería Civil por la Universidad Nacional de Ingeniería, Perú</th></tr>
<tr><th class='der' align='left'>Título Profesional de Ingeniero Civil por la Universidad Nacional de Ingeniería, Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Proyecto: Obras de Reparación Rehabilitación del Hospital Civico XI RPNP  Arequipa. Cargo: Asistente Ingeniería Civil.</th></tr>
<tr><th class = 'der' align='left'>Empresa: Obispado de Carabayllo. Proyecto: Asistente Ingeniería Civil. Cargo: Asistente Ingeniería Civil.</th></tr>
<tr><th class = 'der' align='left'>Empresa: Consorcio Vilma Luna  Manuel Laurencio. Proyecto: Construcción del Muelle para el centro de Entrenamiento Pesquero subsede - Ilo. Cargo: Asistente Ingeniería Civil</th></tr>
<tr><th class = 'der' align='left'>Empresa: PERGOLA SAC. Cargo: Asistente Ingeniería Civil en Area de Obras  Metrados y Presupuestos.</th></tr>
<tr><th class = 'der' align='left'>Empresa: Obispado de Carabayllo. Cargo: Asistente Ingeniería Civil.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
