<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ALBUJAR DE LA CRUZ, MARIA MALENA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Economía por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Economista por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Docencia para la Formación y la Capacitación por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Gestión Pública por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Seguridad y Defensa Nacional por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Economía y Gestión de los Procesos de Globalización de las Empresas por la Università Degli Studi di Genova - Universidad Católica Sedes Sapientiae, Génova, Italia.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Administración Pública por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Public Governance and Management por la Università Cattolica del Sacro Cuore, Milán, Italia.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ciencias Económicas y Comerciales, en las siguientes asignaturas: Introducción a las Ciencias Económicas y Administrativas, Economía, Administración I, Administración II, Microeconomía, Macroeconomía, Fundamentos de Marketin</th></tr>
<tr><th class = 'der' align='left'>Coordinadora Académica del Programa Educativo en comunidades nativas Matsigenkas y asháninkas del Bajo Urubamba, en convenio con la empresa Pluspetrol Perú Corporation S.A en la Oficina de Relaciones Comunitarias (2012 a la actualidad).</th></tr>
<tr><th class = 'der' align='left'>Tutora de los estudiantes matsigenkas en el Programa de Formación Magisterial Intercultural Bilingüe Nopoki, Universidad Católica Sedes Sapientiae Atalaya - Ucayali. (2013 a la actualidad).</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
