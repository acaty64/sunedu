<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>DE LA CRUZ CAMACO, DANTE PEDRO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Educación Secundaria en la especialidad de Matemática y Física  por la Universidad Nacional Enrique Guzmán. (2013)</th></tr>
<tr><th class='der' align='left'>Licenciado en Educación en la especialidad de Matemática y Física  por la Universidad  Nacional Enrique Guzmán. (2014)</th></tr>
<tr><th class='der' align='left'>Magister en Evaluación y Acreditación de la Calidad Educativa por la Universidad  Nacional Enrique Guzmán.</th></tr>
<tr><th class='der' align='left'>Estudios Concluidos del Doctorado en Ciencias de la Educación por la Universidad  Nacional Enrique Guzmán.</th></tr>
<tr><th class='der' align='left'>Estudios  de Segunda especialidad en Estadística y e investigación Científica Universidad Nacional Federico Villarreal, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente capacitador  en el área de Matemática en convenio con MINEDU (2010)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario en Investigación del  programa de maestría  Huari- (2015)</th></tr>
<tr><th class = 'der' align='left'>Docente capacitador  del Programa de Formación para Directores, Subdirectores en Convenio MINEDU- UCSS. (2015)</th></tr>
<tr><th class = 'der' align='left'>Especialista de Educación  del Programa  de Jornada Escolar Completa convenio MINEDU- UCSS (2015)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario  de estadística, Matemática I, Matemática Financiera  en la Universidad  Privada SISE (2016)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario de Matemática I, Física I en la Universidad Católica Sedes Sapientiae(2016)</th></tr>
<tr><th class = 'der' align='left'>Coordinador pedagógico del Programa de Capacitación  a Directores y Subdirectores en Convenio con el MINEDU  UCSS (2016)</th></tr>
<tr><th class = 'der' align='left'>Docente capacitador  del Programa de Formación de Directores y Subdirectores en convenio con MINEDU  UCSS (2016  2017)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
