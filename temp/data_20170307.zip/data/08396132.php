<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>INFANTES SANTILLAN, EDUARDO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Título Profesional de Licenciado en Psicología. Universidad Inca Garcilaso de la Vega. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Estudios concluidos en Maestría. Maestría en Docencia en Educación Superior. Universidad Científica del Sur.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Instituto Nacional de S Mental: Honorio Delgado  Hideyo Noguchi San Martin de Porres. Practicas Pre Profesionales de Internado, en el Departamento de Farmaco.</th></tr>
<tr><th class = 'der' align='left'>Prácticas Pre Profesionales en Psicoterapia Sistémica como Terapeuta y Coterapeuta en el servicio social a la Comunidad  para la Pareja (IOP).</th></tr>
<tr><th class = 'der' align='left'>Encargado de Recursos Humanos en Evaluación, Capacitación y Selección de Personal en  BRANFICLEAN S.A. Limpieza Industrial. Grupo BRANFISA.</th></tr>
<tr><th class = 'der' align='left'>Encargado del Area de Intervención Psicosocial. Defensoría Municipal del Niño y del Adolescente.</th></tr>
<tr><th class = 'der' align='left'>Ministerio de Educación. Centro de Atención a la Comunidad Educativa. (CAEP). Area de Atención Personalizada.</th></tr>
<tr><th class = 'der' align='left'>Profesor Responsable de Tutoría de Aula. Instituto Superior Particular  CEPEBAN.</th></tr>
<tr><th class = 'der' align='left'>Docente en Educación Técnica Superior. Asociación Cultural Sudamericana SISE Franquicia.</th></tr>
<tr><th class = 'der' align='left'>Asociación Cultural Latinoamericana, Instituto Peruano de Sistemas SISE</th></tr>
<tr><th class = 'der' align='left'>Docente a tiempo completo  en Universidad Científica del Sur.</th></tr>
<tr><th class = 'der' align='left'>Capacitador  Consultor Externo Ministerio de Agricultura (MINAG).</th></tr>
<tr><th class = 'der' align='left'>Presidencia del Consejo de Ministros. Revisión de Planes de Desarrollo de Capacidades Sectoriales, Regionales y Locales.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
