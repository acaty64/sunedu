<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MAGGI ., GUIDO EUGENIO MARIO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciado en Economía por la Universidad Católica del Sacro Cuore de Milán, Italia</th></tr>
<tr><th class='der' align='left'>Contador Público por la Universidad de Trento de Milán, Italia</th></tr>
<tr><th class='der' align='left'>Bachiller en Economía por la Universidad Católica del Sacro Cuore  de Milán, Italia.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Presidente. Observatorio para el desarrollo territorial (ODT) de la Universidad Católica Sedes Sapientiae. Los Olivos.</th></tr>
<tr><th class = 'der' align='left'>Vicepresidente. Centro de Apoyo al Sector Empresarial (CEASE) de la Universidad Católica Sedes Sapientiae. Los olivos.</th></tr>
<tr><th class = 'der' align='left'>Coordinador administrativo. Proyecto gestión escolar con liderazgo pedagógico por la Universidad Católica Sedes Sapientiae. Los Olivos.</th></tr>
<tr><th class = 'der' align='left'>Representante de la UCSS en la Mesa de Trabajo Intersectorial de Gestión Migratoria. Ministerio de Relaciones Exteriores.</th></tr>
<tr><th class = 'der' align='left'>Coordinador General. Programa de Especialización Sindical y Relaciones Laborales de la UCSS.</th></tr>
<tr><th class = 'der' align='left'>Coordinador principal. Estudio de Empleabilidad de los Egresados (UCSS). Jefe de equipo técnico. Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Jefe de proyecto. INTELIGENT ZIA PERFECT FOR IMPROVING.</th></tr>
<tr><th class = 'der' align='left'>Coordinador General. Centro Guamán Poma de Ayala.</th></tr>
<tr><th class = 'der' align='left'>Director de proyectos. Instituto Tecnológico Superior El Buen Pastor.</th></tr>
<tr><th class = 'der' align='left'>Miembro del grupo Latinoamericano por la Administración Pública (GLAP).</th></tr>
<tr><th class = 'der' align='left'>Miembro del comité organizador del V Encuentro latinoamericano de estudios transfronterizos y desarrollo de capacidades humanas. Universidad Nacional Autónoma de México (UNAM).</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
