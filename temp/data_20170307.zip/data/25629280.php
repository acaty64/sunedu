<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>BIO GAIDOLFI, CARLA MARIA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Derecho y Ciencias Políticas por la Universidad de Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Derecho del Trabajo por el Colegio de Abogados de Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Persona, Familia y Sociedad a la Luz de la Doctrina Social de la Iglesia por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ciencias Económicas y Comerciales de la  Universidad Católica Sedes Sapientiae en la Categoría de Auxiliar a Tiempo Completo desde enero del  2006.</th></tr>
<tr><th class = 'der' align='left'>Jefe de la Oficina de Personal y Asuntos Legales de la Universidad Católica Sedes Sapientiae desde Octubre del 2002 hasta Diciembre del 2016.</th></tr>
<tr><th class = 'der' align='left'>Secretario General de la Universidad Católica Sedes Sapientiae desde Junio del 2015 hasta la fecha.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
