<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CRISTOBAL VELASQUEZ, DORIS HILDA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Docente de Educación Secundaria especialidad Ciencias Naturales por el Instituto Pedagógico Nacional de Monterrico, Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad Ricardo Palma, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciada en Educación Secundaría especialidad Ciencias Naturales por el Instituto Pedagógico Nacional de Monterrico, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Neuropedagogía por la Universidad San Pablo, Arequipa, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Coaching Educativo, por la Universidad San Pablo, Arequipa, Perú</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Neurociencia y Educación por la Universidad Antonio Ruiz de Montoya, Lima, Perú</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Psicopedagogía por la Universidad Marcelino Champagnat, Lima, Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de Secundaria del curso de Ciencias Naturales, Colegio Nacional República de Chile (1985-1986)</th></tr>
<tr><th class = 'der' align='left'>Docente de Secundaria de los cursos de Ciencias Naturales, Química, Biología y Religión. CEP PALESTRA, especializado en Problemas de Aprendizaje (1986 -1992)</th></tr>
<tr><th class = 'der' align='left'>Docente de Secundaria en el Area de Ciencias Naturales CEP JUAN JACOBO ROUSSEAU. (1994-1999)</th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Superior en la Universidad Católica Sedes Sapientiae (UCSS) en los cursos Anatomía y Fisiología Humana, Biología Humana; Evaluación del Aprendizaje; Neuropsicología, Neuropedagogía, Psicología del Aprendizaje; Psicología del Desa</th></tr>
<tr><th class = 'der' align='left'>Coordinadora General de Tutoría del Programa Beca 18 en la Universidad Católica Sedes Sapientiae (UCSS) (2014  continua)</th></tr>
<tr><th class = 'der' align='left'>Ponente en la Conferencia de Cierre del Programa de Formación del Proyecto Mejoramiento de los procesos de Enseñanza y Aprendizaje en Comprensión Lectora y Matemática de los estudiantes de II Ciclo de Nivel Inicial de las Instituciones Educativas Pú</th></tr>
<tr><th class = 'der' align='left'>Tutora del programa de Formación en Neuroeducación modalidad a distancia-Brainbox ® (2014.)</th></tr>
<tr><th class = 'der' align='left'>Tutora virtual en el diplomado de Neuropedagogía modalidad a distancia de Cerebrum  (2013)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
