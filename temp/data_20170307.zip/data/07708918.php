<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>FUENTES SUPANTA DE FUKUNAGA, NORMA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Profesora de Educación Secundaria Especialidad Matemática  Universidad Nacional Mayor de San Marcos</th></tr>
<tr><th class='der' align='left'>Título de segunda Especialización en Administración Publica ESAP</th></tr>
<tr><th class='der' align='left'>Diplomado en Formación de auditor Interno e implementación  de Sistemas de Gestión de Calidad SGC  ISO  9001 por la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class='der' align='left'>Diplomado de Especialización  en Asesoría  de Tesis octubre por la Universidad San Martin de Porres</th></tr>
<tr><th class='der' align='left'>Diplomado a distancia La ciencia en tu escuela Academia Mexicana de Ciencias y participación en el distrito Federal de Méjico en representación del Perú</th></tr>
<tr><th class='der' align='left'>Maestría en educación  por la Universidad San Martin de Porres</th></tr>
<tr><th class='der' align='left'>Estudios de Doctorado en educación por la Universidad San Martin de Porres</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de Matemática y jefe de Control Docente  de la Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Docente de Matemáticas y jefe  de servicios académicos  de la Facultad de Medicina Humana  de U.S.M.P</th></tr>
<tr><th class = 'der' align='left'>Docente de Estadística de la Universidad Inca Garcilaso de la Vega</th></tr>
<tr><th class = 'der' align='left'>Directora del C. N. de Mujeres Miguel Grau</th></tr>
<tr><th class = 'der' align='left'>Jefe de Oficina de Grados y Títulos de UCSS</th></tr>
<tr><th class = 'der' align='left'>Participación como Par Observador Internacional  en la Evaluación Externa de la Carrera de Ingeniería de Universidad de Santiago de Chile  Agencia QUALITAS</th></tr>
<tr><th class = 'der' align='left'>Participación en procesos de Evaluación Externa de Universidades  como evaluador Externo con la agencia AECEDU.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
