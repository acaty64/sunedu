<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MORENO PALOMINO, JEAN PAUL</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Magister en Economía, Contabilidad y Administración con mención en Finanzas por la Universidad Nacional Daniel Alcides Carrión, Perú</th></tr>
<tr><th class='der' align='left'>Economista por la Universidad Nacional Daniel Alcides Carrión, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Economía por la Universidad Nacional Daniel Alcides Carrión, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Doctorado en Economía por la Universidad Inca Garcilaso de la Vega, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado en Banca y Finanzas por el Instituto de Formación Bancaria.</th></tr>
<tr><th class='der' align='left'>Diplomado en Modernización de la Gestión y Administración Pública Parlamentaria por la Universidad Ricardo Palma.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente en el curso de Economía General en la Especialidad de Hotelería y Turismo de la Universidad del Centro del Perú.</th></tr>
<tr><th class = 'der' align='left'>Docente en el curso de Microeconomía en la Especialidad de Hotelería y Turismo de la Universidad del Centro del Perú.</th></tr>
<tr><th class = 'der' align='left'>Docente en el curso de Planificación Estratégica en la Especialidad de Ingeniería de Sistemas e Informática de la Universidad Peruana de Integración Global.</th></tr>
<tr><th class = 'der' align='left'>Docente en el curso de Desarrollo Organizacional en la Especialidad de Ingeniería de Sistemas e Informática de la Universidad Peruana de Integración Global.</th></tr>
<tr><th class = 'der' align='left'>Docente en el curso de Formulación y Evaluación de Proyectos en la Especialidad de Ingeniería Civil de la Universidad Peruana de Integración Global.</th></tr>
<tr><th class = 'der' align='left'>Docente en el curso de Ingeniería Económica en la Especialidad de Ingeniería de Sistemas e Informática de la Universidad Peruana de Integración Global.</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ingeniería y Facultad de Ingeniería Agraria desde el año 2015 hasta la actualidad de la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
