<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MONTERROSO CORONADO, CESAR ANTONIO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Economía por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad Nacional de Educación Enrique Guzmán y Valle. Lima. Perú</th></tr>
<tr><th class='der' align='left'>Economista por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciado en Educación por la Universidad Nacional de Educación Enrique Guzmán y Valle, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma de Segunda Especialidad en Formación Magisterial por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Finanzas por la Universidad del Pacífico, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Administración de Negocios y Finanzas Internacionales por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Magister Universitario en Gestión Estratégica, Finanzas e Internacionalización de la Empresa por la Universitá degli Studi, Génova, Italia.</th></tr>
<tr><th class='der' align='left'>Estudios en Doctorado en Gestión Económica Global por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente del Instituto CERTUS.</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ciencias Económicas y  Comerciales de la Universidad Católica Sedes Sapientiae en la materias: Macroeconomía Básica, Regulación Económica, Historia del Pensamiento Económico, Entorno Económico de los Negocios, Economía, Semi</th></tr>
<tr><th class = 'der' align='left'>Expositor en los Cursos de Econometría Aplicada, Grossman Capital Markets.</th></tr>
<tr><th class = 'der' align='left'>Expositor Métodos Cuantitativos CFA-I. Grossman Capital Markets.</th></tr>
<tr><th class = 'der' align='left'>Tutor de la Facultad de Ciencias Económicas y Comerciales en la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Superior en la Universidad Católica Sedes Sapientiae en los cursos de Ciencias Naturales, Ecología y Educación, Seminario de Tesis II.</th></tr>
<tr><th class = 'der' align='left'>Coordinador del Area de Economía Intermedia de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Coordinador de la Carrera Profesional de Economía de la Universidad Católica Sedes Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
