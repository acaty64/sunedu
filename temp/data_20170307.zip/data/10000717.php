<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ENCISO ZAVALA, FAUSTA ISABEL</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Contadora por la Pontificia Universidad Católica del Perú, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Educación por la Universidad Nacional Federico Villarreal, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciatura en Contabilidad por la Universidad Nacional Federico Villarreal, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Tributación por la Universidad de Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Negocios Internacionales por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Superior en la Universidad Católica Sedes Sapientiae (UCSS) en los cursos   de Contabilidad 1 (Pre-grado)  2 semestres</th></tr>
<tr><th class = 'der' align='left'>Contadora General.  Universidad Católica Sedes Sapientiae del 01 de Marzo 2003 a la fecha</th></tr>
<tr><th class = 'der' align='left'>Contadora. Associazione Volontari Per Il Servizio Internazionale A.V.S.I Ent. Inst.Cooperacion Técnica  ENIEX Desde 2003 al 2010</th></tr>
<tr><th class = 'der' align='left'>Team Leader Perú  Proyecto PMI Acounting ITALIA  UCSS De Enero 2009 a Diciembre 2013 (Contabilidad de pequeñas empresas Italianas por Internet)</th></tr>
<tr><th class = 'der' align='left'>Coordinadora Distrital.  ONPE Oficina Nacional de Procesos Electorales ODPE CANTA. De Agosto a Noviembre 2002</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
