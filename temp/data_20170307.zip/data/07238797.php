<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>VELARDE FLORES, RUBEN ANTONIO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias  Economía por la Universidad Nacional Agraria La Molina, Perú.</th></tr>
<tr><th class='der' align='left'>Título de Economista por la Universidad Nacional Agraria, Perú.</th></tr>
<tr><th class='der' align='left'>Magister en Administración de Negocios y Finanzas Internacionales por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Master en Gestión estratégica, Finanzas e Internacionalización de las empresas por la Universitá Degli Studi di Genova, Italia.</th></tr>
<tr><th class='der' align='left'>Egresado de la Maestría en Administración por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Marketing y Negocios Internacionales por la Universidad Nacional Federico Villarreal, Perú</th></tr>
<tr><th class='der' align='left'>Egresado del Doctorado en Administración por la Universidad Nacional Federico Villarreal, Lima- Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ciencias Administrativas, Escuela de Negocios Internacionales por la Universidad Nacional Mayor de San Marcos.</th></tr>
<tr><th class = 'der' align='left'>Coordinador Académico de la Escuela de Negocios Internacionales</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Economía y Ciencias de  la Empresa por la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Universidad Privada del Norte. Docente de la Facultad de Negocios.</th></tr>
<tr><th class = 'der' align='left'>IPAE  Escuela de Empresarios. Docente.</th></tr>
<tr><th class = 'der' align='left'>Andes Norte SAC. Gerente comercial.</th></tr>
<tr><th class = 'der' align='left'>Agropecuaria de Negocios. Gerente General.</th></tr>
<tr><th class = 'der' align='left'>Empresa Nacional de Comercialización de Insumos (ENCI). Gerente comercial.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
