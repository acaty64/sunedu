<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CONTINI ., GIULIANA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Título en Letras Modernas por la Universidad Católica del Sacro Cuore de Milán, Italia.</th></tr>
<tr><th class='der' align='left'>Título en Literatura Italiana e Historia por la Universidad Católica del Sacro Cuore de Milán, Italia.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Decana de la Facultad de Ciencias de la Educación y Humanidades de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente principal, con las Cátedras de Seminario de Literatura, Literatura Moderna, Hitos del arte universal y Antropología Religiosa.</th></tr>
<tr><th class = 'der' align='left'>Profesor auxiliar asociado para dar clases de Literatura Italiana:Dante, en su tiempo,El deseo de Absoluto en el Arte y la literatura, Los hitos del Renacimiento Italiano.</th></tr>
<tr><th class = 'der' align='left'>Docente permanente en la materia de Literatura en el I.T.I.S.D.Scano de Cagliari, Cerdeña.</th></tr>
<tr><th class = 'der' align='left'>Profesora visitante en la Pontificia Católica de Chile, dando clases en Literatura Italiana.</th></tr>
<tr><th class = 'der' align='left'>Profesora Asistente en la Facultad de Derecho de la Universidad de Chile.</th></tr>
<tr><th class = 'der' align='left'>Docente principal en la Facultad de Ciencias de la  Educación de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Directora  de la Revista Riesgo de Educador de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Directora del Suplemento Riesgo de Educar.</th></tr>
<tr><th class = 'der' align='left'>Directora del boletín. Pensar la educación.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
