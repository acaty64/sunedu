<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>PASTEN MONARDEZ, JUAN IGNACIO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Ingeniero Agrónomo por la Pontificia Universidad Católica de Valparaíso. Chile</th></tr>
<tr><th class='der' align='left'>Mención Fruticultura.</th></tr>
<tr><th class='der' align='left'>Diplomado en Gestión Estratégica y Estudio de Organizaciones Asociativas por la Universidad de Chile, Santiago, Chile.</th></tr>
<tr><th class='der' align='left'>Magister en Gestión de Agro negocios y Alimentos por la Universidad del Pacífico, Lima, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Decano de la Facultad de Ingeniería Agraria. Universidad Católica Sedes Sapientiae. Lima. Perú.</th></tr>
<tr><th class = 'der' align='left'>Director de Proyectos Productivos. Facultad de Ingeniería Agraria. Universidad Católica Sedes Sapientiae. Lima. Perú</th></tr>
<tr><th class = 'der' align='left'>Jefe Técnico I&D. Stoller de Chile S.A. Multinacional Norteamericana. Dedicada a la investigación, desarrollo y comercialización de fertilizantes nutricionales y hormonales.</th></tr>
<tr><th class = 'der' align='left'>Director Ejecutivo. Asociación Gremial Compañía de las Obras (CDO)  Chile. Filial de la CDO Italia. Realización del 3er Meeting Latinoamericano de la Compañía de las Obras. Santiago de Chile.</th></tr>
<tr><th class = 'der' align='left'>Asesor Técnico. Instituto de Desarrollo Agropecuario (INDAP). Ministerio de Agricultura de Chile. Asesoría Técnica a pequeños agricultores. Municipalidad de Vicuña. IV Región. Chile</th></tr>
<tr><th class = 'der' align='left'>Fundación para la Superación de la Pobreza. Programa Servicio País. Ilustre Municipalidad de Palmilla. Provincia de Colchagua. VI Región. Chile. Línea de acción: Desarrollo Económico Local y Fomento Productivo.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
