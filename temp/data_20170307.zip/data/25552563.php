<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>AQUISSE TORRES, TEODORO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Título  Licenciado en Educación, especialidad  Matemática  física Universidad Nacional Federico Villarreal</th></tr>
<tr><th class='der' align='left'>Grado Magister en didáctica de la educación superior y gestión educativa (en proceso de revisión para la sustentación) Universidad Alas Peruanas.</th></tr>
<tr><th class='der' align='left'>Diploma de segunda especialidad en Formación Magisterial Pontificia Universidad Católica del Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en enseñanza de las Matemáticas  estudio concluidos Pontificia Universidad Católica del Perú.</th></tr>
<tr><th class='der' align='left'>Doctorado en Educación     estudio concluidos  Universidad de Educación Enrique Guzmán y Valle.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Profesor de matemática y física en el Colegio Privado Henri Menard.</th></tr>
<tr><th class = 'der' align='left'>Director del Colegio Privado  Henri Menard.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
