<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MENENDEZ MUERAS, ROSA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería de Computación y Sistemas. Universidad de San Martin de Porres.</th></tr>
<tr><th class='der' align='left'>Título Profesional de Ingeniero de Computación y Sistemas. Universidad de San Martin de Porres.</th></tr>
<tr><th class='der' align='left'>Grado de Magister en Administración y Dirección de Empresas. Universidad Alas Peruanas.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Analista Comercial. SEDAPAL</th></tr>
<tr><th class = 'der' align='left'>Analista Programador de Sistemas. Universidad Particular de San Martín de Porres</th></tr>
<tr><th class = 'der' align='left'>Analista de sistemas. Universidad Mayor de San Marcos</th></tr>
<tr><th class = 'der' align='left'>Sistemas. OSITRAN</th></tr>
<tr><th class = 'der' align='left'>Sistemas. SUNAT</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
