<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CORDOVA SALCEDO, FELIMON DOMINGO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ingeniería Civil por la Universidad Nacional Pedro Ruiz Gallo, Perú.</th></tr>
<tr><th class='der' align='left'>Título Profesional de Ingeniería Civil por la Universidad Nacional Pedro Ruiz Gallo, Perú.</th></tr>
<tr><th class='der' align='left'>Magister en Ciencias de la Educación con mención en Docencia Universitaria por la Universidad Nacional de Educación E.G.V.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Topógrafo. Empresa: Compañía Consorcio Drenaje Ferreñafe.</th></tr>
<tr><th class = 'der' align='left'>Topógrafo. Empresa: Corporación Constructora CORMAG S.A..</th></tr>
<tr><th class = 'der' align='left'>Ingeniero Residente. Empresa: Ingenieros Consultores Andina S.R.L.</th></tr>
<tr><th class = 'der' align='left'>Ingeniero Residente. Empresa: CORDELAM.</th></tr>
<tr><th class = 'der' align='left'>Docente. Instituto: Instituto Superior Tecnológico Privado José Santos Chocano.</th></tr>
<tr><th class = 'der' align='left'>Docente. Instituto: Instituto Publico José Pardo.</th></tr>
<tr><th class = 'der' align='left'>Ingeniero Residente. Empresa: GEO Construcciones S.A. Ingeniero Residente. Empresa: Doble L Construcciones S.R.L.</th></tr>
<tr><th class = 'der' align='left'>Ingeniero Residente. Empresa: B y C Contratistas Generales.</th></tr>
<tr><th class = 'der' align='left'>Ingeniero Residente. Empresa: CARGIL S.R.L.</th></tr>
<tr><th class = 'der' align='left'>Ingeniero Residente. Empresa: Cesar Augusto Rivera.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
