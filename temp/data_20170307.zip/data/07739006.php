<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>ARELLANO CABO, MARIETTA ZORAIDA SOCORRO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Título: N°22286 Profesora de Educación Inicial.</th></tr>
<tr><th class='der' align='left'>Diplomas de segunda especialidad: Gestión / Desarrollo Infantil Temprano / Currículo, otros.</th></tr>
<tr><th class='der' align='left'>Maestría concluida.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Directora de IEI pública (6 años) De Instituciones Privadas (7 años)</th></tr>
<tr><th class = 'der' align='left'>Directora de USE N° 10 Huaral (2 años)</th></tr>
<tr><th class = 'der' align='left'>Coordinadora del Programas de Capacitación IESPPEI  UPCH  INTEGRADEM  UNMSM  SIGED  CESED, Otros</th></tr>
<tr><th class = 'der' align='left'>Coordinadora de PRODHECA  IESPPEI  Centro de Estimulación Temprana IESPPEI.</th></tr>
<tr><th class = 'der' align='left'>Asesora de tesis IESPPEI (2006 a  la fecha)  UCSS (2014- 2015)</th></tr>
<tr><th class = 'der' align='left'>Jefe Del Programa Académico de Educación Inicial IESPPEI (2006 a la fecha)</th></tr>
<tr><th class = 'der' align='left'>Docente en la especialidad de Educación Inicial IESPPEI ( 22 años)</th></tr>
<tr><th class = 'der' align='left'>Docente en la carrera de Educación Inicial Universidad Católica Sedes Sapientiae (2011 a la fecha)</th></tr>
<tr><th class = 'der' align='left'>Miembro del Comité de Calidad UCSS- Carrera de Educación Inicial 2013 a la fecha</th></tr>
<tr><th class = 'der' align='left'>Capacitadora  Monitora. Acompañante pedagógica, Tutora virtual, Formador Tutor - Programas Nacionales MINEDU: PLANCAD, PRONAFCAP, JEC, DIPLOMADO A DIRECTORES REGION JUNIN  Sede Huancayo.</th></tr>
<tr><th class = 'der' align='left'>Formador Tutor  Diplomado y Segunda Especialidad en Gestión Escolar con Liderazgo Pedagógico del Programa Nacional de Formación y Capacitación para Directores Y Sub-Directores de Instituciones Educativas Públicas - Item 10 Y 11 - Regiones: Junín (2</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
