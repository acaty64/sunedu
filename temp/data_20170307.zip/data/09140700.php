<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CHAVEZ PRADO, ANGELICA MARITZA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciada en Turismo y Hotelería por la Universidad San Martín de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Turismo y Hotelería por la Universidad San Martín De Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Filosofía y Religión por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Secretaria ejecutiva en la Facultad de Ciencias de la Comunicación en las diversas áreas académicas como decanato, departamento académico, grados y títulos, oficina de registros académicos y la oficina del instituto de investigación en la Universidad</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
