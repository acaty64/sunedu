<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MENDOZA CABALLERO, WILFREDO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias Biológicas por la Universidad Nacional de San Antonio Abad del Cusco, Perú.</th></tr>
<tr><th class='der' align='left'>Biólogo por la Universidad de San Antonio Abad del Cusco, Perú.</th></tr>
<tr><th class='der' align='left'>Especialización en Sistemática de Plantas Tropicales por la Universidad de Costa Rica y la Organización para Estudios Tropicales-OET, Costa Rica.</th></tr>
<tr><th class='der' align='left'>Especialización en Sistemática Filogenética por la Universidad de Panamá y la Red Latinoamericana de Botánica, Panamá.</th></tr>
<tr><th class='der' align='left'>Maestría en Botánica Tropical con Mención en Taxonomía Sistemática Evolutiva por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Asesor en temas ambientales en flora y vegetación. En diferentes consultoras ambientales de Lima y Ministerio de Medio Ambiente.  Lima. Perú</th></tr>
<tr><th class = 'der' align='left'>Coordinador de Vegetación en el Programa de Monitoreo y Biodiversidad de Camisea.</th></tr>
<tr><th class = 'der' align='left'>Investigador Asociado del Museo de Historia Natural de San Marcos. Dedicada a la investigación de la flora de Perú, casi en todos los departamentos del Perú.</th></tr>
<tr><th class = 'der' align='left'>Secretario de la Facultad de Ingeniería Agraria. Universidad Católica Sedes Sapientiae. Lima. Perú.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
