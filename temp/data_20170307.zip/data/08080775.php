<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>BRAVO SAENZ, WALTER ALEJANDRO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Título Profesional en Contabilidad por la Universidad Inca Garcilaso de la Vega.</th></tr>
<tr><th class='der' align='left'>Título de Contador Público  por la Universidad Inca Garcilaso de la Vega</th></tr>
<tr><th class='der' align='left'>Grado de Bachiller en Contabilidad por la Universidad Inca Garcilaso de la Vega</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría y Doctorado concluidos (Grado de Maestro en proceso)</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Coordinador académico ISTP CESCA</th></tr>
<tr><th class = 'der' align='left'>Director CETPRO CESCA</th></tr>
<tr><th class = 'der' align='left'>Director Gerente Global Books EIRL</th></tr>
<tr><th class = 'der' align='left'>Docente contratado Universidad Católica Sedes Sapientiae UCSS</th></tr>
<tr><th class = 'der' align='left'>Docente contratado Universidad Católica Los Angeles de Chimbote ULADECH</th></tr>
<tr><th class = 'der' align='left'>Docente contratado Universidad Peruana de Las Américas.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
