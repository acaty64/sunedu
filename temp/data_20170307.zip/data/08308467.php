<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MENDOZA NAVARRO, AIDA LUZ</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias Políticas por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Abogada por la Universidad Nacional Mayor de San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Gestión de Políticas Públicas por la Universidad Nacional Federico Villarreal, Perú.</th></tr>
<tr><th class='der' align='left'>Doctorado en Derecho por la Universidad Nacional Federico Villarreal, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente invitada al Curso de Administración de Archivos: Métodos de Dirección y Gestión para la Maestría en Gestión Documental y Administración de Archivos, Universidad de La Salle, Bogotá-Colombia.</th></tr>
<tr><th class = 'der' align='left'>Docente Invitada del Curso Experto en Archivos de la UNIA-España.</th></tr>
<tr><th class = 'der' align='left'>Coordinadora de la Carrera Profesional de Archivística y Gestión Documental desde el 2010 (Universidad Católica Sedes Sapientiae) Coordinadora de la Carrera Profesional de Archivística y Gestión Documental (Universidad Católica Sedes Sapientiae)</th></tr>
<tr><th class = 'der' align='left'>Miembro, en calidad de colaboradora de InterPARES Trust (Team Latin American), Proyecto Internacional con sede en Vancouver-Canadá.</th></tr>
<tr><th class = 'der' align='left'>Presidenta de Archiveros sin Fronteras-Perú y Secretaria de Archiveros sin Fronteras Internacional con sede en Barcelona-España</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
