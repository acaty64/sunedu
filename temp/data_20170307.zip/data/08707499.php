<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>DE LA ROSA VALVERDE, CECILIA MELCHORA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Magister en Psicología Empresarial por la Universidad Femenina del Sagrado Corazón, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciada en Psicología Empresarial por la Universidad Nacional Federico Villareal, Perú.</th></tr>
<tr><th class='der' align='left'>Diplomado en Neurociencia por la Universidad Inca Garcilaso de la Vega, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae. Docente de las asignaturas Coaching Organizacional, Asertividad y comunicación efectiva, taller de oratoria, Gestión de atención al cliente.</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae- Encargada del área de Calidad Educativa de la Facultad de Ingeniería.</th></tr>
<tr><th class = 'der' align='left'>Universidad Federico Villarreal, Docente de la asignatura Dinámica de Grupos.</th></tr>
<tr><th class = 'der' align='left'>Escuela Nacional Marina Mercante, Asesora Metodológica de Tesis en Administración Marítima.</th></tr>
<tr><th class = 'der' align='left'>Dirección de Instrucción, Marina de Guerra del Perú. Coordinadora Oficina de Calidad e Innovación Educativa. Escuelas de Instrucción Superior y Técnica.</th></tr>
<tr><th class = 'der' align='left'>Dirección de Administración de Personal Marina de Guerra del Perú. (Psicóloga Responsable de Capacitación, Evaluación y Seguimiento de Personal Civil).</th></tr>
<tr><th class = 'der' align='left'>Aracor Lestrove SL. Conferencista. Barcelona España.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
