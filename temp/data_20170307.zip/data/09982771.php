<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CARRASCO LOPEZ, ILIANOV PABLO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Economía por la Universidad Nacional Agraria La Molina, Perú.</th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias de la Educación por la Universidad Nacional de Educación Enrique Guzmán y Valle, La Cantuta, Perú</th></tr>
<tr><th class='der' align='left'>Título en la especialidad de Economía por la Universidad Agraria La Molina, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciado en Educación especialidad Inglés por la Universidad Nacional de Educación Enrique Guzmán y Valle, La Cantuta, Perú</th></tr>
<tr><th class='der' align='left'>Maestría en Administración de Negocios y Finanzas  Internacionales MBA Internacional por la Universidad Católica Sedes Sapientiae, Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Jefe TI (Tecnologías de la Información)  en la Universidad Católica Sedes Sapientiae (UCSS) Area UCSS VIRTUAL</th></tr>
<tr><th class = 'der' align='left'>Docente de educación básica regular en las II.EE. Estados Unidos (Comas), Rosa de Santa María (Breña) y Sagrados Corazones Belén San Isidro.</th></tr>
<tr><th class = 'der' align='left'>Docente Instituto Superior Tecnológico ABACO.</th></tr>
<tr><th class = 'der' align='left'>Docente de Educación Superior en la Universidad Católica Sedes Sapientiae (UCSS) en los cursos   de Economía, Microeconomía, Inglés Técnico (Pre-grado)</th></tr>
<tr><th class = 'der' align='left'>Coordinador Académica de la Facultad de Ingeniería (2008-2012).</th></tr>
<tr><th class = 'der' align='left'>Coordinador Académica de la Facultad de Facultad de Ciencias Económicas sede Huacho.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
