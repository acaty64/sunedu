<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CHAVEZ MEDRANO, VICTOR RICARDO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Psicología por la Universidad Inca Garcilaso de la Vega, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciado en Psicología por la Universidad Inca Garcilaso de la Vega, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Psicología Jurídica y Penitenciaria por el colegio de Abogados de Huánuco, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Criminología por el Colegio de Abogados de Huánuco, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Gestión del Capital Humano por la Universidad San Ignacio de Loyola, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Formulación y Gerencia de Proyectos de Inversión Pública y Desarrollo Local por la Universidad Ricardo Palma, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Metodología de la Investigación Científica por la Universidad Particular Alas Peruanas, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Psicología Educativa por la Universidad César Vallejo, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Docencia Universitaria y Gestión de la Educación por la Universidad Alas Peruanas, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>-	Psicólogo del Instituto Penitenciario DEVIDA  Tarma.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
