<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>HUIMAN SANDOVAL, JOSE ALBERTO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Oceanografía y Pesquería</th></tr>
<tr><th class='der' align='left'>Ingeniero Pesquero. Universidad Nacional Federico Villarreal</th></tr>
<tr><th class='der' align='left'>Diplomado en Sistemas Integrados de la Calidad Ambiental, Seguridad y salud ocupacional. CESAP-Colegio de Ingenieros del Perú, Especialización en Ciencias Naturales-Física-Universidad de Ciencias y Humanidades, Proyectos de Inversión-UNI Universidad</th></tr>
<tr><th class='der' align='left'>Magister en Gestión empresarial. Universidad Nacional Hermilio Valdizán de Huánuco UNHEVAL.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Agroindustrial I&D JHS SRL. Gerente</th></tr>
<tr><th class = 'der' align='left'>JHS Servicios SRL Ingeniería, Agroindustrias, Investigación en C&T. Conferencista y Capacitador Actitudinal.</th></tr>
<tr><th class = 'der' align='left'>Asesor Rectorado Universidad Nacional Federico Villarreal.</th></tr>
<tr><th class = 'der' align='left'>Asesor Vice Rectorado Universidad Nacional José Faustino Sánchez Carrión de Huacho.</th></tr>
<tr><th class = 'der' align='left'>Director de la Escuela de Ingeniería Agroindustrial. Facultad de Ingeniería Industrial y de Sistemas FIIS. Universidad Nacional Federico Villarreal UNFV.</th></tr>
<tr><th class = 'der' align='left'>Director del Instituto de Investigación de la FIIS-UNFV.</th></tr>
<tr><th class = 'der' align='left'>Director de la Escuela de Ingeniería de Acuicultura. Facultad de Oceanografía, Pesquería, Ciencias Alimentarias y Acuicultura FOPCAA-UNFV.</th></tr>
<tr><th class = 'der' align='left'>Directivo del Capítulo de Ingeniería Pesquera-Consejo Departamental de Lima-Colegio de Ingenieros del Perú.</th></tr>
<tr><th class = 'der' align='left'>Jefe de Estación Piscícola Santa Eulalia-FOPCAA-UNFV.</th></tr>
<tr><th class = 'der' align='left'>Jefe de la Oficina de Planificación de la FOPCAA-UNFV</th></tr>
<tr><th class = 'der' align='left'>Vicerrector Académico y Jefe de la Oficina Central de Planificación de la Universidad Nacional de Tumbes.</th></tr>
<tr><th class = 'der' align='left'>Teniente Alcalde de la Municipalidad Distrital de Catacaos-Piura.</th></tr>
<tr><th class = 'der' align='left'>Catedrático en materias de Ingeniería y Ciencias de la Empresa aplicadas a la Acuicultura.</th></tr>
<tr><th class = 'der' align='left'>FOPCAA-UNFV.</th></tr>
<tr><th class = 'der' align='left'>Catedrático en materias de Ingeniería para Cadetes. Escuela Militar de Chorrillos.</th></tr>
<tr><th class = 'der' align='left'>IPAE. Catedrático en materias de Ciencias de la Empresa.</th></tr>
<tr><th class = 'der' align='left'>Universidad Privada San Juan Bautista. Catedrático en Biofísica para Ciencias de la Salud.</th></tr>
<tr><th class = 'der' align='left'>Universidad Privada Sergio Bernales de Cañete. Catedrático en Biofísica para Ciencias de la Salud.</th></tr>
<tr><th class = 'der' align='left'>Catedrático en materias de Ciencias de la Empresa. Universidad Tecnológica del Perú.</th></tr>
<tr><th class = 'der' align='left'>Catedrático en Biofísica para Ciencias de la Salud. Universidad Alas Peruanas UAP.</th></tr>
<tr><th class = 'der' align='left'>Catedrático en materias de ciencias de la empresa. Universidad SISE.</th></tr>
<tr><th class = 'der' align='left'>Catedrático en materias de Ingeniería aplicadas a Planta. Universidad Nacional del Callao UNAC.</th></tr>
<tr><th class = 'der' align='left'>Catedrático en materias de Ingeniería aplicadas a Medio Ambiente y Producción más Limpia.</th></tr>
<tr><th class = 'der' align='left'>Universidad Católica Sedes Sapientiae UCSS.</th></tr>
<tr><th class = 'der' align='left'>Asesor del Rectorado de la Universidad Nacional Federico Villarreal</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
