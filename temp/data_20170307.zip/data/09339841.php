<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CARREÑO MARTINEZ, JUAN ELIAS</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciado en Administración de Empresas por la Universidad Ricardo Palma.</th></tr>
<tr><th class='der' align='left'>Magister en Marketing y Dirección Comercial Escuela de Organizacional Industrial (EOI)</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Jefe de Recursos Humanos. Grupo KOBSA SAC COBROEXPERT. (2016)</th></tr>
<tr><th class = 'der' align='left'>HR Business Partner Senior. FINANCIERA CREDISCOTIA (2013- 2015)</th></tr>
<tr><th class = 'der' align='left'>Administrador de Cuentas Claves - Tarjetas y Créditos Autoconstrucción 	(2009  2013)</th></tr>
<tr><th class = 'der' align='left'>Analista Senior de Segmentos y Gestión de Clientes. Banco del Trabajo	(2008  2009)</th></tr>
<tr><th class = 'der' align='left'>Generalista de Recursos Humanos .BANCO DE CREDITO DEL PERU (2005  2008)</th></tr>
<tr><th class = 'der' align='left'>Jefe de la Unidad de Servicio al Cliente (Area Comercial)	 (1998  1999)</th></tr>
<tr><th class = 'der' align='left'>Asistente Comercial - Banca Personal BANCO SANTANDER  PERU  (1997  1998)</th></tr>
<tr><th class = 'der' align='left'>Marketing - Unidad de Productos Transaccionales	(1995  1996)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
