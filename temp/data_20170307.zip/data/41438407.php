<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>NAVARRO LINARES, JANINA DEL ROCIO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciada en Educación Secundaria- Filosofía y Religión por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma internacional en Doctrina Social de la Iglesia.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Filosofía: Mención Filosofía y Religión por la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ciencias de la Educación y Humanidades en: Antropología Religiosa, Epistemología, Etica Educativa, Filosofía moderna, Metafísica, Seminario de ciencia y fe, Filosofía de la Educación, Teoría de la Educación, Historia de la E</th></tr>
<tr><th class = 'der' align='left'>Coordinadora Académica</th></tr>
<tr><th class = 'der' align='left'>Secretaria del comité interno de autoevaluación de la carrera de Educación Secundaria-Filosofía y religión</th></tr>
<tr><th class = 'der' align='left'>Correctora y jurado de tesis.</th></tr>
<tr><th class = 'der' align='left'>Coordinadora Académica  del Proyecto Internacional La vida en el Universo: su origen, su naturaleza, su sentido</th></tr>
<tr><th class = 'der' align='left'>Ponente internacional y conferencista invitada en VII Congreso Latinoamericano de Ciencia y Religión, organizado por la Universidad de Oxford y CRYF</th></tr>
<tr><th class = 'der' align='left'>Autora de los artículos: La idea de Dios como Misterio en el génesis del método científico de Galileo Galilei. Publicado en Studium Veritatis  N° 18 Revista científica indexada de la UCSS (Latindex). Pasión por el hombre: una visión antropológica de</th></tr>
<tr><th class = 'der' align='left'>Colaboradora en la traducción y en la edición al español del libro Formas de epistemología contemporánea: entre el realismo y anti realismo a través del Fondo Editorial de la UCSS</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
