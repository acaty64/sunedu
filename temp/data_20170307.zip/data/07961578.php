<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>LA ROSA BOTONERO, JAVIER</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias con mención en Ingeniería</th></tr>
<tr><th class='der' align='left'>Ingeniero Electricista</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente Universitario en las Areas de Matemáticas y Estadísticas en la Universidad Católica Sedes Sapientiae.(UCSS)</th></tr>
<tr><th class = 'der' align='left'>Docente Universitario en las áreas de Física y Electricidad en la Universidad Tecnológica del Perú (UTP)</th></tr>
<tr><th class = 'der' align='left'>Ingeniero Residente (Jefe de Obras) en obras eléctricas: Redes Secundarias en la CCHH Yuncan, Ampliación de las redes de la minera Nor Perú (Quiruvilca), Evaluación y valorización del Sistema Eléctrico Electronorte, Obras diversas en baja tensión.</th></tr>
<tr><th class = 'der' align='left'>Consultor de Proyectos: Proyectos de Sistemas de Electrificación Tambo bamba, Proyectos de Sistemas de Electrificación Calca-Anta, Proyectos de Sistemas de Electrificación Bellavista,</th></tr>
<tr><th class = 'der' align='left'>Otros proyectos ante el MEM.</th></tr>
<tr><th class = 'der' align='left'>Proyectos de Edificaciones diversas en Baja Tensión</th></tr>
<tr><th class = 'der' align='left'>Jefe de Mantenimiento: Mantenimiento en las Clínicas del Seguro Social en Lima Metropolitana, Mantenimiento de Tableros de maquinaria Textil y montacargas, Mantenimiento diversos en el área residencial, comercial e industrial</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
