<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MUÑOZ MARTICORENA, WILLIAM</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Economista por la Universidad de Lima, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Simplificación Administrativa por la Universidad de San Martin de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Globalización, Competitividad y Desarrollo Empresarial por la Universidad del Pacífico, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en MBA Especialización en Finanzas y Comercio Internacional por la Università Degli Studi Di Genova, Italia.</th></tr>
<tr><th class='der' align='left'>Maestría en Administración por la ESAN, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente  en las  Maestrías:     Administración Pública (Doble Grado con Universidad Católica Sacro Cuore de Italia) y el MBA Internacional (Doble Grado con Universidad de Génova de Italia). Asesor de tesis y Jurado de sustentaciones de Grado de la Es</th></tr>
<tr><th class = 'der' align='left'>Docente ordinario (Profesor Asociado) de los cursos de: Dirección Estratégica y Gerencia de Proyectos, Asesor de tesis y Jurado de sustentaciones de título. Director de Investigación y consultor en proyectos vinculados con la modernización de la gest</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
