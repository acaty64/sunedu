<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>URIBE PORRAS, CARLOS ALBERTO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Grado de  Bachiller en Derecho y Ciencias Políticas. Universidad de San Martin de Porres. Lima. Perú.</th></tr>
<tr><th class='der' align='left'>Título Profesional de Abogado. Universidad de San Martin de Porres. Lima. Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Ministerio Público. Secigrista del Programa Servicio Civil de Graduando de la Dirección Nacional del Ministerio de Justicia. (Enero a Diciembre 1998).</th></tr>
<tr><th class = 'der' align='left'>Gagel Law Firm-USA. Asistente Paralegal. Part Time, Evaluación de expedientes y calificación de expedientes migratorios. (Octubre 1999 a 2002).</th></tr>
<tr><th class = 'der' align='left'>Empresa Nations Rent  Estados Unidos de Norteamérica. Asistente Manager (Recursos Humanos), encargado de estrategias preventivas de Seguridad Informática de la Empresa, Calificación y validez de información (datos), manejo de licencias de patentes y</th></tr>
<tr><th class = 'der' align='left'>Corporación Aventura Technologies. Abogado-Consultor y Analista en Sistemas de vigilancia, biometría, autenticación y comunicaciones. Encargado del estudio de las impresiones digitales, dactiloscopia documentos copia. (15/07/2006  a la actualidad).</th></tr>
<tr><th class = 'der' align='left'>Ejercicio libre de la profesión, con desempeño en el Area Civil, Comercial y Penal, asesoramiento a empresas y consultoría en temas tecnológicos.  (2007  actualidad).</th></tr>
<tr><th class = 'der' align='left'>Docente de la Facultad de Ingeniería. Universidad Católica Sedes Sapientiae. (2012  a la fecha)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
