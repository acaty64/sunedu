<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>DEL BUSTO BRETONECHE, RAFAEL MARTIN</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciado en Psicología por la Universidad San Martín de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Bioética y Bioderecho por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Expositor en capacitaciones docentes y escuelas para padres, en instituciones educativas de Lima, Huacho, Huaral, Barranca, Chincha, Ica, Huánuco y Huancayo. Consorcio para el Desarrollo Humano para la Familia. (2012  actualidad)</th></tr>
<tr><th class = 'der' align='left'>Miembro titular del Comité de Etica de Investigación en Salud de la Facultad de Ciencias de la Salud. Universidad Católica Sedes Sapientiae(2013- actualidad)</th></tr>
<tr><th class = 'der' align='left'>Coordinador de la Carrera de Psicología Universidad Católica Sedes Sapientiae(2012- actualidad)</th></tr>
<tr><th class = 'der' align='left'>Encargado del Servicio de Psicológica. Universidad Católica Sedes Sapientiae(2009 - actualidad)</th></tr>
<tr><th class = 'der' align='left'>Docente (nombrado en la categoría de Auxiliar desde agosto de 2010) y capacitador. Experiencia docente en los cursos de: Historia de la psicología, Psicología general, Psicología del desarrollo socio afectivo, Psicología del desarrollo cognitivo, Psi</th></tr>
<tr><th class = 'der' align='left'>Coordinador de Tutoría y de Psicología del Centro de Servicios Educativos, psicólogo del Servicio de Orientación Psicológica, catedrático, capacitador y miembro del comité editorial de la revista Riesgo de educar.(Enero 2008  enero 2009).</th></tr>
<tr><th class = 'der' align='left'>Psicólogo, asesor de practicantes e internos de psicología. Centro Parroquial de Salud Mental.( Enero 2003  setiembre 2015)</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
