<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>BALTODANO DIAZ, RAUL IVAN</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Medicina Humana por la Universidad Nacional José Faustino Sánchez Carrión, Lima.</th></tr>
<tr><th class='der' align='left'>Diploma en Ecografía por la Universidad Nacional San Luis Gonzaga, Ica, Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Bioética Médica  y Mala Praxis por la Universidad Nacional San Luis Gonzaga, Ica, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Docencia Universitaria por la Universidad Nacional Enrique Guzmán  y Valle, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Docente de Primeros Auxilios, Anatomía, Fisiología, Its, Patología, Epidemiología, Medicina Preventiva, Salud Pública, Estudio de la Comunidad, Planificación Familiar, Terminología en Salud, Semiología, Bioseguridad por la ESCUELA SUPERIOR DE SALUD </th></tr>
<tr><th class = 'der' align='left'>Docente de Terminología en Salud, Anatomía y Fisiología, Psicología Clínica, Patología, Estudio de la Comunidad, Pediatría, Etica, Semiología, Epidemiología por la ASOCIACION CULTURAL LATINOAMERICANA DE INVESTIGACION Y DESARRROLLO  ACLIDE.</th></tr>
<tr><th class = 'der' align='left'>Docente  de Anatomía,  Fisiología, Patología por el INSTITUTO SUPERIOR DE CIENCIAS DE LA SALUD Y NUTRICION  ISCSAN.</th></tr>
<tr><th class = 'der' align='left'>Docente de Anatomía y Fisiología, Terminología en Salud, Semiología,   Patología I Y Patología II por el INSTITUTO SUPERIOR TECNOLOGICO SAN PABLO.</th></tr>
<tr><th class = 'der' align='left'>Docente de Anatomía, Fisiología, Semiología, Patología I Y II, Bioseguridad, Quiromasaje por el INSTITUTO SUPERIOR TECNOLOGICO SAN IGNACIO DE MONTERRICO -  SIDEM.</th></tr>
<tr><th class = 'der' align='left'>Docente de Anatomía-Histología por la UNIVERSIDAD PRIVADA SERGIO BERNALES.</th></tr>
<tr><th class = 'der' align='left'>Docente de Anatomía  Fisiología  Fisiopatología - Farmacología y Terapéutica - Microbiología y Parasitología, Neurociencia en la Educación Inicial (Curso De Titulación) - Atención Integral del Niño: Salud y Nutrición para la Educación Primaria por</th></tr>
<tr><th class = 'der' align='left'>Coordinador Académico de la Carrera Profesional de Enfermería por la Universidad Católica Sedes  Sapientiae.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
