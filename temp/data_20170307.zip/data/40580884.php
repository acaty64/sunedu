<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>COZ CONTRERAS, SOFIA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciada en Educación Inicial por la Universidad Inca Garcilaso de la Vega, Perú.</th></tr>
<tr><th class='der' align='left'>Licenciada en Psicología por la Universidad de San Martín de Porres, Perú.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Gestión e Innovación Educativa por la Universidad Católica Sedes Sapientiae, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Coordinadora de la carrera de Educación Inicial en la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente de la Universidad Católica Sedes Sapientiae. Categoría Auxiliar Tiempo Completo Nombrado.</th></tr>
<tr><th class = 'der' align='left'>Presidenta del comité interno de acreditación de la carrera de Educación Inicial de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Responsable de las II.EE de la Universidad Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Docente Capacitadora del Centro de Servicios Educativo CESED de la Universidad       Católica Sedes Sapientiae.</th></tr>
<tr><th class = 'der' align='left'>Capacitadora del Programa Nacional de Formación y Capacitación Permanente. Ministerio de Educación.</th></tr>
<tr><th class = 'der' align='left'>Directora de la Institución Educativa Inicial Luigi Giussani.</th></tr>
<tr><th class = 'der' align='left'>Psicóloga del Puesto de Salud Víctor Raúl Haya de la Torre.</th></tr>
<tr><th class = 'der' align='left'>Docente de Aula del nivel inicial del Centro Atención Infantil Alecrim.</th></tr>
<tr><th class = 'der' align='left'>Coordinadora del Area de Cuna del Centro de Atención Infantil Alecrim.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
