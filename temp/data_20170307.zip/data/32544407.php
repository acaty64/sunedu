<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>FARFAN ZEGARRA, HAROLD MARTIN</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Ingeniero Zootecnista. Universidad Nacional de Piura - UNP Perú</th></tr>
<tr><th class='der' align='left'>Estudios concluidos de Maestría en Ingeniería Ambiental y Seguridad Industrial - Universidad Nacional de Piura - UNP Perú</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Consultoría Estudio de Priorización de Zonas y Cadenas Productivas del Distrito de Chalaco, Municipalidad Distrital de Chalaco. Febrero, 2017.</th></tr>
<tr><th class = 'der' align='left'>Consultoría para la capacitación de funcionarios de la oficina de Desarrollo Económico Local de la Municipalidad Distrital del Faique en temas de formulación de proyectos productivos, indicadores económicos y priorización de cadenas productivas. Sept</th></tr>
<tr><th class = 'der' align='left'>Formulador de proyectos PP 0-118 Acceso de Hogares rurales con economía de subsistencia a mercados locales - NE Huancabamba 05 - NEC Huancabamba 02</th></tr>
<tr><th class = 'der' align='left'>Formulador de proyectos PP 0-118 Acceso de Hogares rurales con economía de subsistencia a mercados locales - NE Huancabamba 06 - NEC Huancabamba 02</th></tr>
<tr><th class = 'der' align='left'>Promotor Social para el desarrollo de las actividades de Reposición, Operación y Mantenimiento de Sistemas de Agua y Saneamiento - Romas, en la localidad de Pampas de Socchabamba, distrito de Ayabaca provincia de Ayabaca.</th></tr>
<tr><th class = 'der' align='left'>Promotor Social para el desarrollo de las actividades de Reposición, Operación y Mantenimiento de Sistemas de Agua y Saneamiento - Romas, en la localidad de Pampas de Socchabamba, distrito de Ayabaca provincia de Ayabaca.</th></tr>
<tr><th class = 'der' align='left'>Docente de la Universidad Católica Sede Sapientiae - Chulucanas. Marzo, 2012 - actualmente.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
