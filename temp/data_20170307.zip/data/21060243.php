<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>CORONEL QUINTEROS, EDITH MARIA</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Ciencias Religiosas por la Universidad Católica Boliviana San Pablo de Cochabamba, Bolivia.</th></tr>
<tr><th class='der' align='left'>Diploma en Ciencias Religiosas por la Universidad Católica Boliviana, Cochabamba, Bolivia.</th></tr>
<tr><th class='der' align='left'>Estudios de Maestría en Gestión Educativa y Didáctica por la Universidad Nacional del Centro del Perú, Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Profesora en la Institución Educativa Parroquial Niño Jesús de Praga  Tarma.</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
