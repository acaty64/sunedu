<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align="center">
<thead>
<tr>
<th colspan='2'>
<h1>VOTO ., CARMINE</h1></th>
</th>
</tr>
</thead>
<tbody>
<tr><th colspan='2'><h2>Formación Académica</h2></th></tr>
<tr><th class='izq' align='left'>Grado:</th><th class='der' align='left'>MAESTRO</th></tr>
<tr><th class='izq' align='left'>Especialidad: </th><th class='der' align='left'>RELACIONES INTERNACIONALES</th></tr>
<tr><th class='izq' align='left'>Universidad:</th><th class='der' align='left'>UNIVERSITA DEGLI STUDI DI BARI</th></tr>
<tr><th class='izq' align='left'>País:</th><th class='der' align='left'>ITALIA</th></tr>
<tr><th colspan='2'><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class='izq' align='left'>Centro de Trabajo: </th><th class='der' align='left'>UNIVERSIDAD CATÓLICA SEDES SAPIENTIAE</th></tr>
<tr><th class='izq' align='left'>Categoría: </th><th class='der' align='left'>Contratado</th></tr>
<tr><th class='izq' align='left'>Dedicación:</th><th class='der' align='left'>Tiempo Completo</th></tr>
<tr><th class='izq' align='left'>Semestre:</th><th class='der' align='left'>2016 - I</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
