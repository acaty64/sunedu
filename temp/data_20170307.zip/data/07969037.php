<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>MERINO ZEVALLOS, CARLOS ANTONIO</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Bachiller en Ciencias Económicas. Universidad Nacional Federico Villarreal. Lima- Perú.</th></tr>
<tr><th class='der' align='left'>Título profesional de Economista. Universidad Nacional Federico Villarreal. Lima-Perú.</th></tr>
<tr><th class='der' align='left'>Diploma en Gestión de Proyectos de Inversión Pública.  Universidad Nacional Federico Villarreal. Lima-Perú.</th></tr>
<tr><th class='der' align='left'>Egresado de la Maestría en Administración.  Universidad Nacional Federico Villarreal. Lima-Perú.</th></tr>
<tr><th><h2>Trayectoria Profesional</h2></th></tr>
<tr><th class = 'der' align='left'>Director,  Gerente General  Confederación Nacional de Comerciantes del Perú (CONACO).</th></tr>
<tr><th class = 'der' align='left'>Supervisor General de cuentas de ingresos -  Confederación Nacional de Comerciantes del Perú (CONACO).</th></tr>
<tr><th class = 'der' align='left'>Asesor del Cuerpo Médico ESSALUD  Clínica Ramón Castilla</th></tr>
<tr><th class = 'der' align='left'>Comité de Capacitación, Investigación y Docencia  ESSALUD  Clínica Ramón Castilla</th></tr>
<tr><th class = 'der' align='left'>Gerente General  Omicrón Corporation S.A.C.</th></tr>
<tr><th class = 'der' align='left'>Asesor Comercial, Costos y Presupuestos  Infoamerica S.C.R.L.</th></tr>
<tr><th class = 'der' align='left'>Analista Ocupacional -  Empresa Nacional de Comercialización de insumos (ENCI)</th></tr>
<tr><th class = 'der' align='left'>Vendedor- Representaciones KAHI S.C.R.L.</th></tr>
<tr><th class = 'der' align='left'>Administrador - Representaciones KAHI S.C.R.L.</th></tr>
<tr><th class = 'der' align='left'>Administrador- Subgerente  Business Importaciones S.A. ( BIMSA)</th></tr>
<tr><th class = 'der' align='left'>Asistente de Importaciones- Banco Industrial del Perú</th></tr>
<tr><th class = 'der' align='left'>Asesor de Informática Gerencial- Dirección General de Agroindustria Y Comercialización  Ministerio de Agricultura</th></tr>
<tr><th class = 'der' align='left'>Asesor de Estadística y Planificación  Dirección General de ganadería</th></tr>
<tr><th class = 'der' align='left'>Jefe de Prácticas en diversos cursos- Universidad Nacional Federico Villarreal</th></tr>
<tr><th class = 'der' align='left'>Profesor de diversos cursos de Pre- Grado- FCE- Universidad Nacional Federico Villarreal</th></tr>
<tr><th class = 'der' align='left'>Profesor  de la  Universidad Católica Sedes Sapientiae</th></tr>
<tr><th class = 'der' align='left'>Profesor de la Universidad Privada San Juan Bautista</th></tr>
<tr><th class = 'der' align='left'>Profesor de la Universidad Inca Garcilaso de la Vega</th></tr>
<tr><th class = 'der' align='left'>Profesor de la Universidad Femenina del sagrado Corazón</th></tr>
<tr><th class = 'der' align='left'>Profesor de la Escuela Superior de Administración de Empresas</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
