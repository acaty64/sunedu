<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="estiloUCSS2.css" rel="stylesheet" media="screen">
<title>
</title>
</head>
<body>
<table align='center'>
<thead>
<tr>
<th colspan='2'>
<h1>RODAS MARTINEZ, RICARDO SALOMON</h1>
</th>
</tr>
</thead>
<tbody>
<tr><th><h2>Formación Académica</h2></th></tr>
<tr><th class='der' align='left'>Licenciada en Tecnología Médica por la Universidad Nacional Mayor De San Marcos, Perú.</th></tr>
<tr><th class='der' align='left'>Maestría en Salud Ocupacional y Ambiental por la Universidad Nacional Mayor de San Marcos.</th></tr>
<tr><th class='der' align='left'>Experiencia laboral:</th></tr>
<tr><th class='der' align='left'>SGS Del Perú S.A.C. como Consultor Estudios Salud</th></tr>
<tr><th class='der' align='left'>SGS Del Perú S.A.C. como Ejecutivo de Cuenta  Jefe de Proyecto de Ergonomía</th></tr>
<tr><th class='der' align='left'>Organización Iberoamericana De Seguridad   OIS como Capacitador externo en ergonomía</th></tr>
<tr><th class='der' align='left'>Universidad Católica Sedes Sapientiae  UCSS como Docente del curso de Ergonomía</th></tr>
<tr><th class='der' align='left'>Matfis SAC  como Coordinador Jefe de Ergonomía</th></tr>
<tr><th class='der' align='left'>Instituto Superior Tecnológico Privado Arzobispo Loayza                                                                                                                      como Docente en Terapia Física</th></tr>
</tbody>
</table>
<div class="boton-regresar"><a href="javascript:history.back(-1);" >Regresar</a></div>
</body>
</html>
