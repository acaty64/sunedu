<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>
</title>
</head>
<body>
<table>
<thead>
<tr>
<th witdth = "30%">
</th>
<th witdth = "70%">
</th>
</thead>
<tbody>
<th colspan='2'><h1>RUIDIAS JUAREZ, MARINA</h1></th>
<tr><th colspan='2'><h2>Formación Académica</h2></th></tr>
<tr><th align='left'>Grado:</th><th align='left'>BACHILLER</th></tr>
<tr><th align='left'>Especialidad: </th><th align='left'>CIENCIAS DE LA EDUCACION</th></tr>
<tr><th align='left'>Universidad:</th><th align='left'>UNIVERSIDAD DE PIURA</th></tr>
<tr><th align='left'>País:</th><th align='left'>PERÚ</th></tr>
<tr><th colspan='2'><h2>Trayectoria Profesional</h2></th></tr>
<tr><th align='left'>Centro de Trabajo: </th><th align='left'>UNIVERSIDAD CATÓLICA SEDES SAPIENTIAE</th></tr>
<tr><th align='left'>Categoría: </th><th align='left'>Contratado</th></tr>
<tr><th align='left'>Dedicación:</th><th align='left'>Tiempo Parcial</th></tr>
<tr><th align='left'>Semestre:</th><th align='left'>2016 - I</th></tr>
</tbody>
</table>
</body>
</html>
